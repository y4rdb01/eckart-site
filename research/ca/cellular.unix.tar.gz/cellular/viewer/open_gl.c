/* open_gl.c
   Copyright (C) 1997, 1998  J Dana Eckart
   Copyright (C) 1998, 1999  J Dana Eckart & Jason Karnes
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>

#if OPEN_GL

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "view.h"

static int BIG_ENDIAN;

static char			*open_gl_title;

static struct {
	unsigned int red, green, blue;
	unsigned int composite;
} pixels[MAX_MAP_SIZE];
static unsigned int Black_Pixel, White_Pixel;

static boolean do_alpha = false;

static unsigned int *cell_pixmap;

/* Variables for controlling the main viewing window. */
static int  			mainWindow;
static int			cell_side_x = MAX_CELL_SIDE;
static int			cell_side_y = MAX_CELL_SIDE;
static int			cell_side_z = MAX_CELL_SIDE;
static float			cell_side_ratio = 1.0;
static float			x2max_ratio = 1.0;
static float			y2max_ratio = 1.0;
static float			z2max_ratio = 1.0;
static int 			time_window_height = 0;
static unsigned int		mainWidth = 0, mainHeight = 0;
static int			max_range;

static GLfloat view_rotx = 10.0, view_roty = 15.0, view_rotz = 0.0;
static GLfloat zoom_factor = 1.0;

/* Variables for controlling the neighborhood sub-window. */
static int   	neighborWindow = 0;
static int 	neighborhood = 1;		/* size of the neighborhood. */

/* x, y, z neighborhood viewing co-ordinates. */
static int 	neighbor_x, neighbor_y, neighbor_z;

static unsigned int neighborWidth, neighborHeight;

const int charheight = 20;	/* Based on GLUT_BITMAP_9_BY_15 */

static void DrawString(char *str) {
	int len, i;
	len = strlen(str);
	for(i = 0; i < len; i++)
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, str[i]);
}

static void DrawLine(int x1, int y1, int x2, int y2) {
	glBegin(GL_LINES);
	glVertex2i(x1, y1);
	glVertex2i(x2, y2);
	glEnd();
}

#if COMBINED

/* Variables for controlling the neighborhood sub-window. */
static int          examineWindow = 0;
static unsigned int examineWidth, examineHeight;

/* Display the values of the cell fields. */
static void display_cell_field_values(void) {
	int i;
	char coordinate_string[MAX_STRING_SIZE];

	glutSetWindow(examineWindow);

	/* Write the cooridnates. */
	glColor4ubv((unsigned char*) &White_Pixel);
	glRecti(0, 0, examineWidth, time_window_height-1);

	if (range_dim_given > 1)
		sprintf(coordinate_string, "< %d, %d >",
			neighbor_x + lower[range_dim_1_index],
			neighbor_y + lower[range_dim_2_index]);
	else
		sprintf(coordinate_string, "< %d >",
			neighbor_x + lower[range_dim_1_index]);

	glColor4ubv((unsigned char*) &Black_Pixel);
	glRasterPos2i(time_window_height/2, (int) (0.3 * time_window_height));
	DrawString(coordinate_string);

	/* Clear the contents of the window. */
	glColor4ubv((unsigned char*) &Black_Pixel);
	glRecti(0, time_window_height, examineWidth, examineHeight);

	glColor4ubv((unsigned char*) &White_Pixel);

	/* Draw the horizontal lines. */
	for (i = field_count; i > 0; i--)
		DrawLine(0, i*charheight*2 + time_window_height,
			 examineWidth, i*charheight*2 + time_window_height);

	/* Display the cell field values. */
	for (i = 0; i < field_count; i++) {
		char string[MAX_STRING_SIZE];
		char field_name[MAX_STRING_SIZE];
		char field_name_value[MAX_STRING_SIZE];

		{
			int x, y, z;

			if (range[0] == 1) x = lower[0];
			else x = neighbor_x;

			if (range[1] == 1) y = lower[1];
			else if (range[0] == 1) y = neighbor_x;
			else y = neighbor_y;

			if (range[2] == 1) z = lower[2];
			else z = neighbor_y;

			if (use_floats)
				sprintf(string, "%f",
					cell_field_float_value(i, x, y, z));
			else
				get_string_for_value(string,
						     cell_field_value(i,
								      x, y, z),
						     false);
		}
		strncpy(field_name, &field_names[i*field_name_length],
			field_name_length);
		field_name[field_name_length] = '\0';
		sprintf(field_name_value, "%s: %s", field_name, string);

		glRasterPos2i(charheight*2/3,
			      examineHeight - i*2*charheight - 1.2*charheight);
		DrawString(field_name_value);
	}
	glFlush();
	glutSwapBuffers();
}

/* Create the cell field examination window. */
static void CreateExamineWindow(void) {

	examineWidth = charheight * (field_name_length + MAX_VALUE_WIDTH + 5)/2;
	examineHeight = charheight * field_count * 2;

	examineHeight += time_window_height;	/* For the coordinates. */

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
        glutInitWindowSize(examineWidth, examineHeight);
	examineWindow = glutCreateWindow(open_gl_title);

	if (!examineWindow)
		error("Unable to open a cell field examination window",
		      (char*) NULL);

	glutSetWindow(examineWindow);
	glViewport(0, 0, examineWidth, examineHeight);
	glLoadIdentity();
        gluOrtho2D (0.0, (GLfloat) examineWidth,
                    0.0, (GLfloat) examineHeight);
	glutDisplayFunc(display_cell_field_values);
}
#endif

/* Display the values of the appropriate neighborhood. */
static void display_neighbor_values(void) {
	int i, j;
	char coordinate_string[MAX_STRING_SIZE];

	glutSetWindow(neighborWindow);

	/* Write the cooridnates. */
	glColor4ubv((unsigned char*) &White_Pixel);
	glRecti(0, 0, neighborWidth, time_window_height-1);

	if (range_dim_given > 1)
		sprintf(coordinate_string, "< %d, %d >",
			neighbor_x + lower[range_dim_1_index],
			neighbor_y + lower[range_dim_2_index]);
	else
		sprintf(coordinate_string, "< %d >",
			neighbor_x + lower[range_dim_1_index]);

	glColor4ubv((unsigned char*) &Black_Pixel);
	glRasterPos2i(time_window_height/2, (int) (0.3 * time_window_height));
	DrawString(coordinate_string);

	/* Clear the contents of the window. */
	glColor4ubv((unsigned char*) &Black_Pixel);
	glRecti(0, time_window_height, neighborWidth, neighborHeight);

	glColor4ubv((unsigned char*) &White_Pixel);

	/* Draw the horizontal lines (if need be). */
	if (range_dim_given > 1) for (i = 2*neighborhood; i > 0; i--)
		DrawLine(0, i*charheight*MAX_FIELD_VALUE_WIDTH + time_window_height,
			 neighborWidth, i*charheight*MAX_FIELD_VALUE_WIDTH + time_window_height);

	/* Draw the vertical lines. */
	for (i = 2*neighborhood; i > 0; i--)
		DrawLine(i*charheight*MAX_FIELD_VALUE_WIDTH, time_window_height,
			 i*charheight*MAX_FIELD_VALUE_WIDTH, neighborHeight);

	/* Display the neighbor values. */
	if (range_dim_given == 1)
		for (i = -neighborhood; i <= neighborhood; i++) {
			int x = (neighbor_x + i + range[range_dim_1_index]) %
						range[range_dim_1_index];
			char string[MAX_STRING_SIZE];

			if (use_floats)
				sprintf(string, "%f", cell_float_vals[x]);
			else
				get_string_for_value(string,
						     cell_vals[x], true);

			glColor4ubv((unsigned char*)
				    &pixels[cell_map_vals[x]].composite);
			glRasterPos2i(
				(neighborhood+i)*charheight*MAX_FIELD_VALUE_WIDTH +
					charheight*0.3,
				MAX_FIELD_VALUE_WIDTH*charheight*0.3 +
					time_window_height);
			DrawString(string);
	}
	else for (i = -neighborhood; i <= neighborhood; i++)
		for (j = -neighborhood; j <= neighborhood; j++) {
			int x = (neighbor_x + i + range[range_dim_1_index]) %
						range[range_dim_1_index];
			int y = (neighbor_y + j + range[range_dim_2_index]) %
						range[range_dim_2_index];
			char string[MAX_STRING_SIZE];
			int index = x * range[range_dim_2_index] + y;

			if (use_floats)
				sprintf(string, "%f", cell_float_vals[index]);
			else
				get_string_for_value(string,
						     cell_vals[index], true);

			glColor4ubv((unsigned char*)
				    &pixels[cell_map_vals[x*range[range_dim_2_index]+y]].composite);
			glRasterPos2i(
				(neighborhood+i)*charheight*MAX_FIELD_VALUE_WIDTH +
					charheight*0.3,
				(neighborhood+j)*charheight*MAX_FIELD_VALUE_WIDTH +
					MAX_FIELD_VALUE_WIDTH*charheight*0.3 +
					time_window_height);
			DrawString(string);
		}
	glFlush();
	glutSwapBuffers();
}

/* Resize the neighborhood sub-window. */
static void resize_neighborhood(unsigned char key, int x, int y) {
	if ('0' <= key && key <= '9') {
		neighborhood = key-'0';

		neighborWidth = (2*neighborhood+1) * charheight
							* MAX_FIELD_VALUE_WIDTH;
		neighborHeight = (range_dim_given > 1 ?
					neighborWidth :
				        charheight*MAX_FIELD_VALUE_WIDTH);

		neighborHeight += time_window_height; /* For the coordinates. */

		glutSetWindow(neighborWindow);
		glutReshapeWindow(neighborWidth, neighborHeight);
		glViewport(0, 0, neighborWidth, neighborHeight);
		glLoadIdentity();
        	gluOrtho2D (0.0, (GLfloat) neighborWidth,
	                    0.0, (GLfloat) neighborHeight);

		display_neighbor_values();
	}
}

/* Create the sub-window dedicated to showing the numeric values of a
   neighborhood.
*/
static void CreateNeighborWindow(void) {

	neighborWidth = (2*neighborhood+1) * charheight * MAX_FIELD_VALUE_WIDTH;
	neighborHeight = (range_dim_given > 1 ? neighborWidth :
					        charheight*MAX_FIELD_VALUE_WIDTH);

	neighborHeight += time_window_height;	/* For the coordinates. */

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
        glutInitWindowSize(neighborWidth, neighborHeight);
	neighborWindow = glutCreateWindow(open_gl_title);

	if (!neighborWindow)
		error("Unable to open a neighborhood window", (char*) NULL);

	glutSetWindow(neighborWindow);
	glViewport(0, 0, neighborWidth, neighborHeight);
	glLoadIdentity();
        gluOrtho2D (0.0, (GLfloat) neighborWidth,
                    0.0, (GLfloat) neighborHeight);

	glutDisplayFunc(display_neighbor_values);
	glutKeyboardFunc(resize_neighborhood);
}

/* Do any cleanup for open_gl windows. */
void finish_open_gl(void) {
	glFinish();
}

/* Display the current time step at the bottom of the window. */
static void display_time(void) {
	char time_string[MAX_STRING_SIZE];
	
	if (range_dim_given < 3) {
		/* Clear the time display part of the window. */
		glColor4ubv((unsigned char*) &White_Pixel);
		glRecti(0, 0, mainWidth, time_window_height);

		/* Display the new current time step. */
		glColor4ubv((unsigned char*) &Black_Pixel);
	} else
		glColor4ubv((unsigned char*) &White_Pixel);

	sprintf(time_string, "time = %d", _time_step);
	glRasterPos2i(time_window_height/2, (int) (0.3 * time_window_height));
	DrawString(time_string);
}

/* Does the actual display (with rotations) of 3d displays. */
static void display_3d_open_gl_cells(void) {
	int WIDTH = range[range_dim_1_index];
	int HEIGHT = range[range_dim_2_index];
	int DEPTH = range[range_dim_3_index];
	register int x, y, z;
	register unsigned int *cell_color = cell_pixmap-1;

	if (zoom_factor < 0) zoom_factor = 0.0;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_LIGHTING);

	/* Use an orthographic projection. */
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.5*cell_side_x*WIDTH, 1.5*cell_side_x*WIDTH,
		-1.5*cell_side_y*HEIGHT, 1.5*cell_side_y*HEIGHT,
		-1.5*cell_side_z*DEPTH, 1.5*cell_side_z*DEPTH);
	glScalef(zoom_factor*cell_side_x,
		 zoom_factor*cell_side_y,
		 zoom_factor*cell_side_z);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glRotatef(view_rotx, 1.0, 0.0, 0.0);
	glRotatef(view_roty, 0.0, 1.0, 0.0);
	glRotatef(view_rotz, 0.0, 0.0, 1.0);

	glTranslatef(-0.5 * WIDTH, -0.5 * HEIGHT, -0.5 * DEPTH); 

	for(z = 0; z < DEPTH; z++)
	for(y = 0; y < HEIGHT; y++)
	for(x = 0; x < WIDTH; x++) {

		cell_color++;

		if (*cell_color == Black_Pixel) continue;

		glPushMatrix();
		glTranslatef(x, y , z);
		glColor4ubv((unsigned char*) cell_color);
		glutSolidCube(1.0);
		glPopMatrix();
	}
	glDisable(GL_LIGHTING);
}

/* Display all the cell_map_vals (and the neighborhood cell_vals) in the 
   universe.
*/
void display_open_gl_cells(void) {
	glutSetWindow(mainWindow);

	if (range_dim_given < 3) {
		glPixelZoom((float) cell_side_x, (float) cell_side_y);
		glRasterPos2i(0, time_window_height);
		glDrawPixels(range[range_dim_1_index], 
			     range[range_dim_2_index],
			     GL_RGBA, GL_UNSIGNED_BYTE,
			     cell_pixmap);
	} else {
		glViewport(0, time_window_height + 1,
			   mainWidth, mainHeight - time_window_height);
		display_3d_open_gl_cells();
		glViewport(0, 0, mainWidth, time_window_height);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
        	gluOrtho2D (0.0, (GLfloat) mainWidth,
			    0.0, (GLfloat) time_window_height);
	}
	display_time();

	glFlush();
	glutSwapBuffers();

	/* May need to update other windows too. */
	if (neighborWindow) display_neighbor_values();
#if COMBINED
	if (examineWindow) display_cell_field_values();
#endif
}

/* Update (display) the color of a single cell. */
void update_open_gl(long int x, long int y, long int z, celltype color_index) {
        long int i = x - lower[range_dim_1_index];
        long int j = y - lower[range_dim_2_index];
        long int k = z - lower[range_dim_3_index];

	/* The index to cell_pixmap seems to be "backwards", but it works! */
	cell_pixmap[k*range[range_dim_2_index]*range[range_dim_1_index]+
			j*range[range_dim_1_index]+i] = 
						pixels[color_index].composite;
}

static boolean stopped = false;

static int fieldnum;

/* Gets the data for the next time_step so that it can be displayed. */
static void get_data(void) {
	if (stopped) return;

#if !COMBINED
	if (next_time >= 0) 
#endif
	{
#if COMBINED
#if MAX_CPUS > 1
		cellang_main(output, view, filter, fieldnum, cpus-1);
#else
		cellang_main(output, view, filter, fieldnum);
#endif
#else
		read_cell_block();
#endif

#if COMBINED
		if (1 == report_time_step || 
		    _time_step == next_report_time || 
		    _time_step == next_read_time)
#endif
		{
			display_open_gl_cells();
		}

#if COMBINED
		if (_time_step == next_read_time)
			get_report_time(time_file);
		else if (report_time_step > 0 && _time_step >= next_report_time)
			next_report_time = _time_step + report_time_step;
		_time_step++;
#else
		if (next_time >= 0) _time_step = next_time;
#endif
	
		/* Pause times of 0 or less are ignored. */
		if (pause_time > 0) sleep((unsigned int) pause_time);
	}
}

static int max3dSide;

static void mainWinReshape(int width, int height) {
	/* Don't resize the window if both the width and
	   the height are the same.
	*/
	if (width == mainWidth && height == mainHeight) return;

	/* The window needs to be resized. */
	height -= time_window_height;
	if (range_dim_given < 3) {
		cell_side_x = (width / range[range_dim_1_index] > 
				height / range[range_dim_2_index] ?
				height / range[range_dim_2_index] : 
				width / range[range_dim_1_index]);

		if (cell_side_ratio < 1) {
			if (cell_side_x > MAX_CELL_SIDE) 
				cell_side_x = MAX_CELL_SIDE;

			/* Make sure cell_vals are "visible". */
			if (cell_side_x <= 0) cell_side_x = 1;

			cell_side_y = cell_side_x * cell_side_ratio;
		} else {
			cell_side_y = cell_side_x * cell_side_ratio;

			if (cell_side_y > MAX_CELL_SIDE) 
				cell_side_y = MAX_CELL_SIDE;

			/* Make sure cell_vals are "visible". */
			if (cell_side_y <= 0) cell_side_y = 1;

			cell_side_x = cell_side_y / cell_side_ratio;
		}
	} else {
		int new_x_side, new_y_side, new_z_side;
		int min_pixels = (width < height ? width : height);
		max3dSide = min_pixels/max_range;
		if (max3dSide < 1) max3dSide = 1;

		if (cell_side_x >= cell_side_y && cell_side_x >= cell_side_z) {
			new_x_side = max3dSide;
			new_y_side = cell_side_y * new_x_side / cell_side_x;
			new_z_side = cell_side_z * new_x_side / cell_side_x;
		} else if (cell_side_y >= cell_side_x && cell_side_y >= cell_side_z) {
			new_y_side = max3dSide;
			new_x_side = cell_side_x * new_y_side / cell_side_y;
			new_z_side = cell_side_z * new_y_side / cell_side_y;
		} else {
			new_z_side = max3dSide;
			new_x_side = cell_side_x * new_z_side / cell_side_z;
			new_y_side = cell_side_y * new_z_side / cell_side_z;
		}
		cell_side_x = new_x_side;
		cell_side_y = new_y_side;
		cell_side_z = new_z_side;
	}

	/* Since the size just chosen for the window may
	   not yield an integer number of pixels for the
	   sides of cells, reset the window size to just
	   fit the new cell_side_x and cell_side_y values.
	*/
	if (range_dim_given < 3) {
		mainWidth = range[range_dim_1_index]*cell_side_x;
		mainHeight = range[range_dim_2_index]*cell_side_y
							+ time_window_height;
	} else {
		mainWidth = max3dSide;
		mainHeight = max3dSide + time_window_height;
	}

	glutSetWindow(mainWindow);
/*
DANA - It seems that a reshape should really be done here, but this causes
the viewport to not register with the window.  glutInitWindowSize causes
the correct registration to occur, but allows the window frame to remain
larger than the viewport.  This also throws off mouse location clicks for
the neighborhood and examine windows.
	glutReshapeWindow(mainWidth, mainHeight);
*/
glutInitWindowSize(mainWidth, mainHeight);
        if (range_dim_given < 3) {
		glViewport(0, 0, mainWidth, mainHeight);
		glLoadIdentity();
                gluOrtho2D (0.0, (GLfloat) mainWidth,
                            0.0, (GLfloat) mainHeight);
        }
	glFlush();
}

static void mainWinVisibility(int vis) {
	if (vis == GLUT_VISIBLE) {
		display_open_gl_cells();
		glutIdleFunc(get_data);
	}
}

static void mainWinKeyboard(unsigned char key, int x, int y) {
	switch (key) {
#if COMBINED
               	case 'e':
               	case 'E':
			/* Cell field examination window */
			if (field_count == 1)
				;
			else if (range_dim_given >= 3)
				;
			else if (!examineWindow) {
				CreateExamineWindow();
				display_cell_field_values();
			} else {
				glutDestroyWindow(examineWindow);
				examineWindow = 0;
			}
			break;
#endif
               	case 'n':
               	case 'N':
			/* Neighborhood window */
			if (range_dim_given >= 3)
				;
			else if (!neighborWindow) {
				CreateNeighborWindow();
				display_neighbor_values();
			} else {
				glutDestroyWindow(neighborWindow);
				neighborWindow = 0;
			}
			break;
               	case 'q':
               	case 'Q':
			/* Quit */
			exit_signaled(0);
               	case 's':
               	case 'S':
			/* Stop */
               		stopped = true;
			break;
               	case 'c':
               	case 'C':
			/* Continue */
               		stopped = false;
			break;
               	case ']':
			view_rotz += 5.0;
			glutPostRedisplay();
			break;
               	case '[':
			view_rotz -= 5.0;
			glutPostRedisplay();
			break;
               	case 'z':
			zoom_factor -= 0.1;
			glutPostRedisplay();
			break;
               	case 'Z':
			zoom_factor += 0.1;
			glutPostRedisplay();
			break;
		default:
			break;
	}
}

static void mainWinRotate(int key, int x, int y) {
	switch (key) {
		case GLUT_KEY_UP:
			view_rotx -= 5.0;
			break;
		case GLUT_KEY_DOWN:
			view_rotx += 5.0;
			break;
		case GLUT_KEY_LEFT:
			view_roty -= 5.0;
			break;
		case GLUT_KEY_RIGHT:
			view_roty += 5.0;
			break;
		default:
			return;
	}
	glutPostRedisplay();
}

static void mainWinMouse(int button, int state, int x, int y) {
	if (state == GLUT_UP) return;
	if (range_dim_given == 3) return;

#if COMBINED
	if (neighborWindow || examineWindow) {
#else
	if (neighborWindow) {
#endif
		int old_x = neighbor_x;
		int old_y = neighbor_y;

		neighbor_x = (x/cell_side_x + 
				range[range_dim_1_index]) %
					range[range_dim_1_index];

		if (range_dim_given > 1)
			neighbor_y = (-y/cell_side_y - 1 + 
					range[range_dim_2_index]) %
					range[range_dim_2_index];

		if (neighbor_x < 0 ||
			neighbor_x >= range[range_dim_1_index] ||
			(range_dim_given > 1 &&
				(neighbor_y < 0 || 
                               	 neighbor_y >= range[range_dim_2_index]))) {
			neighbor_x = old_x;
			neighbor_y = old_y;
		}
	}
#if COMBINED
	if (examineWindow) display_cell_field_values();
#endif
	if (neighborWindow) display_neighbor_values();
}

/* Stores the red, green and blue portions that make up a color. */
celltype setcolor_open_gl(unsigned int red,
			  unsigned int green,
			  unsigned int blue,
			  unsigned int alpha,
			  int index) {
	unsigned char new_alpha = (unsigned char) (alpha*255/65535);

	if (new_alpha < 255) do_alpha = true;

	pixels[index].red = (unsigned int) (red*255/65535);
	pixels[index].green = (unsigned int) (green*255/65535);
	pixels[index].blue = (unsigned int) (blue*255/65535);

	if (BIG_ENDIAN)
		pixels[index].composite = (unsigned int) (
					new_alpha |
					(pixels[index].blue << 8) |
					(pixels[index].green << 16) |
					(pixels[index].red << 24)
					);
	else
		pixels[index].composite = (unsigned int) (
					(new_alpha << 24) |
					(pixels[index].blue << 16) |
					(pixels[index].green << 8) |
					pixels[index].red
					);

	return index;
}

/* Set the values for Black_Pixel and White_Pixel. */
static void Black_and_White_Pixels(int max_colors) {
	if (max_colors <= 2 || range_dim_given >= 3) {
		White_Pixel = 0xFFFFFFFF;
		if (BIG_ENDIAN)
			Black_Pixel = 0x000000FF;
		else
			Black_Pixel = 0xFF000000;
	}
	else {
		/* Assume that the darkest pixels are given first and
		   the lightest in color are given last.  In either
		   case, both should be sufficiently different in color
		   to be readable.
		*/
		White_Pixel = pixels[max_colors-1].composite;
		Black_Pixel = pixels[0].composite;
	}
}

static int maxof3 (int i, int j, int k) {
        if (i <= j && i <= k)
                return i;
        else if (j <= i && j <= k)
                return j;
        else
                return k;
}

/* Do all the setup and housekeeping for starting an open_gl window. */
void setup_open_gl(char *map_name, char *display, 
		int first_cell_side_x, int first_cell_side_y,
		int first_cell_side_z, char *title) {
	int max_x_pixels, max_y_pixels;
	long int ncolors;
	char *default_file;

	unsigned int first, last;

	BIG_ENDIAN = big_endian();

	if (BIG_ENDIAN < 0)
		error("Unknown architecture (neither big or little endian)",
			(char*) NULL);

	open_gl_title = title;

	/* The following if should really be handled by using a
	   "glutInitDisplayString(display);" call, but isn't!
	   This code sets up the glut internal variables so
	   that calls to glutGet will work.

	   Perhaps one day, someone will fix it.  Sigh...
	*/
	if (display) {
		int argc = 3;
		char *argv[] = { "dummy", "-display", NULL, NULL };
		argv[2] = display;
		glutInit(&argc, argv);
	} else {
		int argc = 1;
		char *argv[] = { "dummy", NULL };
		glutInit(&argc, argv);
	}

	/* Get the height and width of the screen in pixels. */
	max_x_pixels = glutGet(GLUT_SCREEN_WIDTH);
	max_y_pixels = glutGet(GLUT_SCREEN_HEIGHT);

	cell_side_ratio = (float) first_cell_side_y / (float) first_cell_side_x;

	/* Determine the size of the sides of each displayed cell. */
	if (range_dim_given < 3) {
		cell_side_x = (max_x_pixels / range[range_dim_1_index] > 
					max_y_pixels / range[range_dim_2_index] ?
				max_y_pixels / range[range_dim_2_index] : 
				max_x_pixels / range[range_dim_1_index]);

		if (cell_side_ratio < 1) {
			if (cell_side_x > MAX_CELL_SIDE) 
				cell_side_x = MAX_CELL_SIDE;

			/* Make sure cell_vals are "visible". */
			if (cell_side_x <= 0)
				error("Too many cells to display on screen", 
					(char*) NULL);

			cell_side_y = cell_side_x * cell_side_ratio;
		} else {
			cell_side_y = cell_side_x * cell_side_ratio;

			if (cell_side_y > MAX_CELL_SIDE) 
				cell_side_y = MAX_CELL_SIDE;

			/* Make sure cell_vals are "visible". */
			if (cell_side_y <= 0)
				error("Too many cells to display on screen", 
					(char*) NULL);

			cell_side_x = cell_side_y / cell_side_ratio;
		}
	} else {
		int cell_side;
		int new_x_side, new_y_side, new_z_side;
		int min_pixels = (max_x_pixels < max_y_pixels ?
						max_y_pixels : max_x_pixels);

		max_range = range[range_dim_1_index];
		if (max_range < range[range_dim_2_index])
			max_range = range[range_dim_2_index];
		if (max_range < range[range_dim_3_index])
			max_range = range[range_dim_3_index];

		cell_side = first_cell_side_x;
		if (cell_side < first_cell_side_y)
			cell_side = first_cell_side_y;
		if (cell_side < first_cell_side_z)
			cell_side = first_cell_side_z;

		max3dSide = min_pixels/max_range;

		if (cell_side < max3dSide) max3dSide = cell_side;
		if (max3dSide < 1) max3dSide = 1;

		cell_side_x = first_cell_side_x;
		cell_side_y = first_cell_side_y;
		cell_side_z = first_cell_side_z;
		if (cell_side_x >= cell_side_y && cell_side_x >= cell_side_z) {
			new_x_side = max3dSide;
			new_y_side = cell_side_y * new_x_side / cell_side_x;
			new_z_side = cell_side_z * new_x_side / cell_side_x;
		} else if (cell_side_y >= cell_side_x && cell_side_y >= cell_side_z) {
			new_y_side = max3dSide;
			new_x_side = cell_side_x * new_y_side / cell_side_y;
			new_z_side = cell_side_z * new_y_side / cell_side_y;
		} else {
			new_z_side = max3dSide;
			new_x_side = cell_side_x * new_z_side / cell_side_z;
			new_y_side = cell_side_y * new_z_side / cell_side_z;
		}
		cell_side_x = new_x_side;
		cell_side_y = new_y_side;
		cell_side_z = new_z_side;

		max3dSide *= max_range;
	}

	time_window_height = 1.5*charheight;

	if (range_dim_given < 3) {
		/* Go with the prefered size if possible. */
		if (cell_side_x > first_cell_side_x)
			cell_side_x = first_cell_side_x;
		if (cell_side_y > first_cell_side_y)
			cell_side_y = first_cell_side_y;

		mainWidth = range[range_dim_1_index]*cell_side_x;
		mainHeight = range[range_dim_2_index]*cell_side_y
						+ time_window_height;
	} else {
		mainWidth = max3dSide;
		mainHeight = max3dSide + time_window_height;
	}

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
        glutInitWindowSize(mainWidth, mainHeight);
        mainWindow = glutCreateWindow(open_gl_title);

	if (!mainWindow) error("Unable to open a window", (char*) NULL);

	/* If a map file was given, read it; otherwise use the default. */
	if (!map_name) {
		default_file = "c-map";

		map_name = (char*) malloc((unsigned int) (strlen(LIB_DIR) + 
						strlen(default_file) + 2));
		if (!map_name) error("Out of memory", (char*) NULL);

		sprintf(map_name, "%s%s", LIB_DIR, default_file);
	}
	ncolors = file_size(map_name);

	if (ncolors > 256*256*256)
		error("Too many colors requested", (char*) NULL);

	fprintf(stderr, "Using %d colors...\n", ncolors);
	read_map(map_name, ncolors <= 2);
	Black_and_White_Pixels(ncolors);

	/* Create a pixel map. */
	cell_pixmap = (unsigned int*)
			calloc(range[range_dim_1_index]
				*range[range_dim_2_index]
				*range[range_dim_3_index],
			       sizeof(unsigned int));

	/* Get a more accurate looking cursor. */
	glutSetCursor(GLUT_CURSOR_CROSSHAIR);

	/* Assign intial values for the cursor location to be used for
	   neighborhood value viewing within a sub-window.
	*/
	neighbor_x = range[range_dim_1_index]/2;
	if (range_dim_given > 1)
		neighbor_y = range[range_dim_2_index]/2;
	if (range_dim_given > 2)
		neighbor_z = range[range_dim_3_index]/2;

	/* On an SGI, the window header bar can only get so small, and
	   this prevents the data from taking less room than the bar does.
	*/
	if (MAX_FIELD_VALUE_WIDTH == 1) MAX_FIELD_VALUE_WIDTH++;

	/* Optimize the graphics performance a little bit. */
	glShadeModel(GL_FLAT);
	glStencilMask(GL_FALSE);
	glDisable(GL_DITHER);
	if (range_dim_given > 2) glDepthMask(GL_TRUE);
	else glDepthMask(GL_FALSE);

	if (range_dim_given >= 3) {

		/* Setup a light source to get shading and thus a better
		   3D effect.
		*/
  		glEnable(GL_CULL_FACE);
  		glEnable(GL_LIGHT0);
		glEnable(GL_DEPTH_TEST);

		/* Allow colored materials. */
		glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
		glEnable(GL_COLOR_MATERIAL);

		if (do_alpha) {
			/* For opacity, so that you can see through
			   things in 3D.
			*/
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		}
	}

        if (range_dim_given < 3) {
        	glLoadIdentity();
		glViewport(0, 0, mainWidth, mainHeight);
                gluOrtho2D (0.0, (GLfloat) mainWidth,
                            0.0, (GLfloat) mainHeight);
        }

	glutSetWindow(mainWindow);
	glutDisplayFunc(display_open_gl_cells);
	glutReshapeFunc(mainWinReshape);
	glutVisibilityFunc(mainWinVisibility);
	glutKeyboardFunc(mainWinKeyboard);
	glutMouseFunc(mainWinMouse);
	if (range_dim_given >= 3) glutSpecialFunc(mainWinRotate);

	glFlush();
}

/* Start displaying the cell_vals. */
void display_open_gl(int field) {

	/* Place the colors for the initial values for each cell. */
	register long int i, j, k;

	fieldnum = field;

        if (range_dim_given == 1)
                for (i = 0; i < range[range_dim_1_index]; i++)
                        update_open_gl(i, 0, 0, cell_map_vals[i]);
        else if (range_dim_given == 2)
                for (i = 0; i < range[range_dim_1_index]; i++)
                for (j = 0; j < range[range_dim_2_index]; j++)
                        update_open_gl(i, j, 0,
                                        cell_map_vals[i*range[range_dim_2_index]+j]);
        else if (range_dim_given == 3)
                for (i = 0; i < range[range_dim_1_index]; i++)
                for (j = 0; j < range[range_dim_2_index]; j++)
                for (k = 0; k < range[range_dim_3_index]; k++)
                        update_open_gl(i, j, k,
                                        cell_map_vals[i*range[range_dim_2_index]
*range[range_dim_3_index]+j*range[range_dim_3_index]+k]);

	/* Do the initial display of the cells. */
	display_open_gl_cells();

	/* Display cell_vals for the rest of time. */
	glutMainLoop();
}
#endif
