/* view.c
   Copyright (C) 1992, 1993, 1994 J Dana Eckart
   Copyright (C) 1995  J Dana Eckart, Michael Sharov
   Copyright (C) 1997, 1998, 1999  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#if COMBINED
#include <sys/types.h>
#if MAX_CPUS > 1
#include <sys/ipc.h>
#include <sys/shm.h>
#endif
#endif
#include "view.h"
#include "open_gl.h"
#include "boolean.h"

/* The cellular universe which contains the colors/characters that
   are and correspond to the cell values which are read.
*/
celltype *cell_vals = NULL;
float *cell_float_vals = NULL;
maptype *cell_map_vals = NULL;

/* The number of dimensions specified to display. */
int dim_given = 0;

#if !COMBINED
boolean use_floats = false;

/* Contains the current time. */
unsigned long int _time_step = 0;

/* Contains the time of the next block of cell value entries. */
long int next_time = 0;
#else
extern void set_seed(long int);
extern void init_cells(void);
extern void init_display(void);
#if MAX_CPUS > 1
/* Declarations for linking with the (possibly multi-threaded) automata. */
extern void init_shared(void);
#endif
#endif

/* The default amount of time to pause between displaying time steps. */
long int pause_time = 0;

/* Contains the current entry number within a particular block of
   cell value entries.  It's only purpose is in error messages to
   better indicate their location within the input.
*/
long int entry = 0;

/* The values of the following variables determine which method of
   display has been chosen.
*/
int open_gl_option = false;
#if COMBINED
int output = false, view = false, filter = false;
#endif

/* Global variable set in "main", which is the name of this program. */
char *command = NULL;

#if COMBINED && MAX_CPUS > 1
extern int master_id;
#if P_THREADS
#include <pthread.h>
#endif
#endif

/* Performs the necessary actions when a signal is received. */
void exit_signaled(int exit_status) {

#if COMBINED && MAX_CPUS > 1
        /* Only one thread should do the cleanup. */
        if (cpus > 1)
#if P_THREADS
		if (pthread_self() != master_id)
                	pthread_exit((void*) exit_status);
#endif
#endif

	/* Do whichever windowing cleanup is necessary. */
#if OPEN_GL
	if (open_gl_option) finish_open_gl();
#endif

	exit(exit_status);
}

/* Prints out the error message in a standard format and exits.  This
   format is intended for use when the problem is with other than the
   input.
*/
void error(char *format, char *string) {
	char error_msg[MAX_STRING_SIZE];
	sprintf(error_msg, format, string);
	fprintf(stderr, "%s: %s.\n", command, error_msg);
	exit_signaled(1);
}

/* Prints out the error message in a standard format and exits.  This
   format is intended for use when there is a problem with the input.
*/
void input_error(char *format, char *string) {
	char error_msg[MAX_STRING_SIZE];
	sprintf(error_msg, format, string);
	fprintf(stderr, "%s; time %ld, entry %ld: %s.\n",
		command, _time_step, entry, error_msg);
	exit_signaled(1);
}

/* Array of ranges and associated colors (i.e. the map). */
struct {
	union {
		long int lower;
		float float_lower;
	} lb;
	union {
		long int upper;
		float float_upper;
	} ub;
	maptype color;
		
} map[MAX_MAP_SIZE];

/* Number of map entries given. */
long int max_map_entry = 0;

/* Direct_map is true iff all of the map values are contiguous (and strictly
   increasing) with no ranges specified.  In this case, the map_offset then
   gives the offset from 0 in which to find the values color.
*/
boolean direct_map = true;
long int map_offset;


/* Read in the color map from the map_name file. */
void read_map(char *map_name, boolean black_and_white) {
	FILE *map_file = fopen(map_name, "r");

	if (!map_file)
		error("Unable to open map file '%s'", map_name);

	/* Read in all the map entries from the file. */
	while (1) {
		int c;
		long int lower, upper;
		float float_lower, float_upper;
		int count;
		int red, blue, green, alpha;

		/* Read the next entry, but if there are no more, quit. */
		if (use_floats)
			count = fscanf(map_file, " %f", &float_lower);
		else
			count = fscanf(map_file, " %ld", &lower);

		if (0 == count || EOF == count)
			break;
		if (use_floats)
			count = fscanf(map_file, "..%f", &float_upper);
		else
			count = fscanf(map_file, "..%ld", &upper);

		if (0 == count) {
			if (use_floats)
				float_upper = float_lower;
			else
				upper = lower;
		} else if (EOF == count)
			error("Map entry %d is incomplete",
			      (char*) max_map_entry+1); 
		else
			direct_map = false;

		/* Make sure the values are contiguous (and increasing)
		   for a direct_map.
		*/
		if (!use_floats && direct_map && max_map_entry > 0 &&
				lower+1 != map[max_map_entry-1].lb.lower)
			direct_map = false;

		/* Get the map_offset for a direct_map. */
		if (direct_map && max_map_entry == 0)
			map_offset = -lower;

		/* Make sure not too many entries are used. */
		if (max_map_entry >= MAX_MAP_SIZE)
			error("More than %d color map entries used",
			      (char*) MAX_MAP_SIZE); 

		/* Set the new map entry value range. */
		if (use_floats) {
			map[max_map_entry].lb.float_lower = float_lower;
			map[max_map_entry].ub.float_upper = float_upper;
		} else {
			map[max_map_entry].lb.lower = lower;
			map[max_map_entry].ub.upper = upper;
		}

		if (black_and_white) {
			/* A black/white display. */
			int tmp_int;
			count = fscanf(map_file, " %d", &tmp_int);

			/* Check for legality of map entry. */
			if (1 != count)
				error("Entry %d of b&w map file is illegal",
				      (char*) max_map_entry);

#if OPEN_GL
			alpha = 65535;
			if (tmp_int == 1)
				red = green = blue = 0;
			else
				red = green = blue = 65535;
#endif

#if OPEN_GL
			if (open_gl_option) 
				map[max_map_entry].color = 
					setcolor_open_gl(red, green, blue,
							 alpha, max_map_entry);
#endif

		}
		else {
			/* A color display. */
			count = fscanf(map_file, " %d %d %d",
					&red, &green, &blue);

			/* Check for legality of map entry. */
			if (3 != count)
				error("Entry %d of color map file is illegal",
				      (char*) max_map_entry);

			/* Check to see if there is another number (an alpha
			   entry) remaining on the line.  If not, assume
			   alpha has a value of 65535.
			*/
			while ((c = getc(map_file)) == ' ' || c == '\t');
			if (c == '\n' || c == EOF) {
				alpha = 65535;
				ungetc(c, map_file);
			} else {
				ungetc(c, map_file);
				fscanf(map_file, "%d", &alpha);
			}

#if OPEN_GL
			if (open_gl_option) 
				map[max_map_entry].color = 
					setcolor_open_gl(red, green, blue,
							 alpha, max_map_entry);
#endif

		}

		max_map_entry++;

		/* Skip to the end of the line. */
		while ((c = getc(map_file)) != '\n' && c != EOF);
		if (EOF == c) break;
	}
	fclose(map_file);
}

/* Maps the given (cell) value to the desired color/character display value. */
maptype map_value(long int value) {
	int i;

	if (!direct_map) {
		for (i = 0; i < max_map_entry; i++)
			if (map[i].lb.lower <= value &&
						value <= map[i].ub.upper)
				return map[i].color;
	} else if (value+map_offset < max_map_entry)
		return map[value+map_offset].color;
	
	/* If an appropriate map value wasn't found, then complain
	   and die.
	*/
	input_error("No color/character for cell value %d", (char*) value);
	return 0;
}

maptype map_float_value(float value) {
	char error_string[MAX_STRING_SIZE];
	int i;

	for (i = 0; i < max_map_entry; i++)
		if (map[i].lb.float_lower <= value &&
						value <= map[i].ub.float_upper)
			return map[i].color;
	
	/* If an appropriate map value wasn't found, then complain
	   and die.
	*/
	sprintf(error_string, "No color/character for cell value %f", value);
	input_error(error_string, (char*) NULL);
	return 0;
}

/* The following variables are the lower and upper bounds of the dimensions
   given on the command line.  The range of each dimension is then calculated.
*/
int lower[MAX_DIMS], upper[MAX_DIMS], range[MAX_DIMS];

/* The indices of the above arrays which correspond to the dimensions
   which contain a non-zero range (i.e. lower and upper bounds differ).
*/
int range_dim_1_index = -1;
int range_dim_2_index = -1;
int range_dim_3_index = -1;

/* Total number of dimensions with non-trivial ranges. */
int range_dim_given = 0;

/* Indicates the cell field value to use. */
int field;

/* Actually makes the call to the display code to display the value if
   different from its current value.
*/
void map_and_display(int index,
		     long int dim_index_1,
		     long int dim_index_2,
		     long int dim_index_3, maptype map_val) {

	/* No need to (re)set a cell map value to the same thing. */
	if (cell_map_vals[index] == map_val) return;

	/* Set the cell map value. */
	cell_map_vals[index] = map_val;

	/* Update the appropriate display. */
#if OPEN_GL
	if (open_gl_option) 
		update_open_gl(dim_index_1, dim_index_2, dim_index_3, map_val);
#endif
}

/* Prepares the everything for the call to the specific display utility to
   display the cell (two versions).
*/
static void set_cell(long int dim_index_1,
		     long int dim_index_2,
		     long int dim_index_3, long int cell_value) {
	maptype map_val;

	int index = (dim_index_1-lower[range_dim_1_index])
			* range[range_dim_2_index] * range[range_dim_3_index] +
	      	    (dim_index_2 - lower[range_dim_2_index])
			* range[range_dim_3_index] +
		     dim_index_3 - lower[range_dim_3_index];

	/* No need to (re)set a cell value to the same thing. */
	if (cell_vals[index] == cell_value) return;

	/* Set the cell value. */
	cell_vals[index] = cell_value;

	map_and_display(index, dim_index_1, dim_index_2, dim_index_3,
			map_value(cell_value));
}

static void set_float_cell(long int dim_index_1,
		           long int dim_index_2,
		           long int dim_index_3, float cell_value) {

	int index = (dim_index_1-lower[range_dim_1_index])
			* range[range_dim_2_index] * range[range_dim_3_index] +
	      	    (dim_index_2 - lower[range_dim_2_index])
			* range[range_dim_3_index] +
		     dim_index_3 - lower[range_dim_3_index];

	/* No need to (re)set a cell value to the same thing. */
	if (cell_float_vals[index] == cell_value) return;

	/* Set the cell value. */
	cell_float_vals[index] = cell_value;

	map_and_display(index, dim_index_1, dim_index_2, dim_index_3,
			map_float_value(cell_value));
}

/* Check that the indices are in range and should be displayed.  If the index
   values describe a position to be displayed, return a 1, return a 0 otherwise.
*/
int check_indices(long int *dim_index_1,
		  long int *dim_index_2,
		  long int *dim_index_3) {

	/* Only consider the desired dimensional projections. 
	   If either the index is out of range or is not the
	   desired value, then skip to the next line of input
	   and return.
	*/
	if (
#if COMBINED
	    dim_given &&
#endif
	    ((range[0] == 1 && *dim_index_1 != lower[0])
		||
	     (range[1] == 1 && *dim_index_2 != lower[1])
		||
	     (range[2] == 1 && *dim_index_3 != lower[2])
		||
	     (range[0] > 1 && 
			(*dim_index_1 < lower[0] || *dim_index_1 > upper[0]))
		||
	     (range[1] > 1 && 
			(*dim_index_2 < lower[1] || *dim_index_2 > upper[1]))
		||
	     (range[2] > 1 && 
			(*dim_index_3 < lower[2] || *dim_index_3 > upper[2])))
	)
		return 0;

	/* We need to "fix" the dimensional indices to shift them down if
	   one or more describe trivial ranges.  This only needs to be done
	   if dimensions were given on the command line.
	*/
	if (dim_given) {
		long int dim[3];
		int i;

		dim[0] = *dim_index_1;
		dim[1] = *dim_index_2;
		dim[2] = *dim_index_3;
		
		*dim_index_1 = *dim_index_2 = *dim_index_3 = 0;
		for (i = 0; i < 3; i++)
			if (range[i] > 1)
				if (i == range_dim_1_index)
					*dim_index_1 = dim[i];
				else if (i == range_dim_2_index)
					*dim_index_2 = dim[i];
				else if (i == range_dim_3_index)
					*dim_index_3 = dim[i];
	}

	return 1;
}

/* Set the cell value and have it displayed (two versions). */
void set_cell_entry(long int dim_index_1,
		    long int dim_index_2,
		    long int dim_index_3, long int cell_value) {

	if (check_indices(&dim_index_1, &dim_index_2, &dim_index_3))
		set_cell(dim_index_1, dim_index_2, dim_index_3, cell_value);
}

void set_float_cell_entry(long int dim_index_1,
		          long int dim_index_2,
		          long int dim_index_3, float cell_value) {

	if (check_indices(&dim_index_1, &dim_index_2, &dim_index_3))
		set_float_cell(dim_index_1, dim_index_2, dim_index_3, cell_value);
}

#if !COMBINED
/* Reads in a single cell and value entry from standard input.  If
   the dimensional indices fall outside of the desired display range
   the entry is ignored.
*/
void read_cell_entry(void) {
	int i, c = ' ';
	long int cell_value;
	float cell_float_value;
 	long int dim_index_1 = 0, dim_index_2 = 0, dim_index_3 = 0;
	boolean value_given;

	/* Read in the (up to 3) indices for the dimensional ranges. */
	scanf(" [");
	for (i = 0; i < dim_given; i++) {
		long int index;

		/* Read the index value. */
		if (scanf(" %ld", &index) != 1)
			input_error("Too few dimensions in input", 
				    (char*) NULL);

		/* Only consider the desired dimensional projections. 
		   If either the index is out of range or is not the
		   desired value, then skip to the next line of input
		   and return.
		*/
		if (range[i] == 1 && index != lower[i]) {
			while (getchar() != '\n');
			return;
		}
		else if (range[i] > 1 && 
				(index < lower[i] || index > upper[i])) {
			while (getchar() != '\n');
			return;
		}

		/* Remember the indices of range projected dimensions. */
		if (i == range_dim_1_index) dim_index_1 = index;
		else if (i == range_dim_2_index) dim_index_2 = index;
		else if (i == range_dim_3_index) dim_index_3 = index;

		if (i < dim_given - 1) scanf(" ,");
	}
	scanf(" ]");

	/* Read in the cell field value, if given.  Skip over unwanted items. */
	scanf(" =");
	value_given = false;
	for (i = 0; i < field-1; i++) {

		if (use_floats)
			scanf(" %f", &cell_float_value);
		else
			scanf(" %ld", &cell_value);

		/* Ignore spaces and tabs. */
		while ((c = getchar()) == '\t' || c == ' ');

		if (c == ',') continue;

		if (c == EOF) break;
		ungetc(c, stdin);
		if (c == '\n') break;
	}

	if (c != '\n' && c != EOF)
		 if ((use_floats && 1 == scanf(" %f", &cell_float_value))
			||
			(!use_floats && 1 == scanf(" %ld", &cell_value)))
		value_given = true;

	if (value_given)
		if (use_floats)
			set_float_cell(dim_index_1, dim_index_2, dim_index_3,
				       cell_float_value);
		else
			set_cell(dim_index_1, dim_index_2, dim_index_3,
				 cell_value);

	/* Ignore the remaining values, if any. */
	while ((c = getchar()) != '\n' && c != EOF);
}

/* Read an entire block of cell entries.  When complete, the value
   of next_time will either be strictly greater than the current
   _time_step (old value of next_time) or it will equal -1 (indicating
   that the input is exhausted).
*/
void read_cell_block(void) {
	entry = 0;
	while (next_time == _time_step) {
		int count;

		/* Assume that a time specification is next on the input.
		   If it isn't (and the input is non-empty), then read a 
		   cell entry instead.  If a new time specification is
		   present, make sure it is legal.
		*/
		count = scanf(" %ld ", &next_time);
		if (0 == count) {
			entry++;
			read_cell_entry();
		}
		else if (EOF == count) {
			/* End of input. */
			next_time = -1;
			break;
		}
		else if (next_time < _time_step)
			/* Check legality of new _time_step. */
			input_error("Time went backwards at %d", (char*) _time_step);
	}
}
#endif

/* Determine if the architecture is big (return 1) or little endian (return 0),
   and return -1 for any other architecture (e.g. middle endian).  This is
   based on code found somewhere on the net, though unfortunately I have noone
   to attribute it to.
*/
#include <assert.h>
int big_endian() {
	long test = 0x11223344;
	char *ptr;

	assert (4 == sizeof(long));
	ptr = (char *)&test;

	if ((0x11 == *ptr) && (0x22 == ptr[1] ) && (0x33 == ptr[2]) && 
							(0x44 == ptr[3]))
		return 1;
	else if ((0x44 == *ptr) && (0x33 == ptr[1]) && (0x22 == ptr[2]) && 
							(0x11 == ptr[3]))
		return 0;
	else 
		return -1;
}

#if COMBINED
extern int max_value_width[];
extern int field_count;
#endif
int MAX_VALUE_WIDTH = 4;
/* Holds the maximum magnitude value that can be displayed in MAX_VALUE_WIDTH
   characters.
*/
int max_value = 1;

int MAX_FIELD_VALUE_WIDTH = 4;
/* Holds the maximum magnitude value that can be displayed in
   MAX_FIELD_VALUE_WIDTH characters.  This is used for a specific field
   whereas MAX_VALUE_WIDTH/max_value is for the collection of fields.
*/
int max_field_value = 1;

/* Make sure the value to be printed will fit.  If it won't then display
   hyphens in place of the value.  The thrid argument (neighwin) is true
   only when the value is to be used in a neighborhood window.
*/
void get_string_for_value(char* string, celltype value, boolean neighwin) {
	if (neighwin) {
		if (-max_field_value <= value && value <= max_field_value)
			sprintf(string, "%ld", value);
		else {
			int i;
			string[0] = '\0';
			for (i = 0; i < MAX_FIELD_VALUE_WIDTH; i++)
				strcat(string, "-");
		}
	} else {
		if (-max_value <= value && value <= max_value)
			sprintf(string, "%ld", value);
		else {
			int i;
			string[0] = '\0';
			for (i = 0; i < MAX_VALUE_WIDTH; i++)
				strcat(string, "-");
		}
	}
}

/* Returns the number of lines in the file denoted by file_name. */
int file_size(char *file_name) {
	int c, lines = 0;
	FILE *file = fopen(file_name, "r");

	if (!file)
		error("Unable to open map file '%s'", file_name);

	/* Count the lines in the file. */
	while ((c = getc(file)) != EOF) if ('\n' == c) lines++;

	fclose(file);
	return lines;
}

/* Start displaying stuff! */
void start_automata(void) {
#if OPEN_GL
	if (open_gl_option) display_open_gl(field-1);
#endif
#if COMBINED
#if MAX_CPUS > 1
	cellang_main(output, view, filter, 0, cpus-1);
#else
	cellang_main(output, view, filter, 0);
#endif
#endif
}

/* Print out the correct usage. */
void usage(char *command) {
	fprintf(stderr, 
#if COMBINED
		"usage: [ ... | ] %s [-r timefile] [-c codefile] [-seed n] [-p n] [-s (n|n,n|n,n,n)]\n\t[-map mapfile] [-f n] ( -o | -ogl [-display connection])]\n\t[-F] [-title string] [-dim [n|n..n]{,n|,n..n}]\n",
#else
		"usage: [ ... | ] %s [-p n] [-s (n|n,n|n,n,n)] [-map mapfile] [-f n]\n\t[-float] -ogl [-display connection]\n\t -dim [n|n..n]{,n|,n..n}\n",
#endif
		command); 
	exit(1);
}

/* The main driver for everything. */
int main(int argc, char *argv[]) {
#if COMBINED
	extern FILE *time_file;
#endif
	int i, cell_size_x = 1, cell_size_y = 1, cell_size_z = 1;
	maptype value_for_0;
	char *map_name = NULL;
#if OPEN_GL
	char *display = NULL;
#endif
#if OPEN_GL
	char *title;
#endif

	field = 1;	/* Look at the first cell field value by default. */

#if OPEN_GL
	title = 
#endif
	command = argv[0];

	/* Check for proper usage and options. */
	i = 0;
	while (++i <= argc-1)
		if (!strcmp(argv[i], "-title")) {
#if OPEN_GL
			title = argv[++i];
#endif
#if !OPEN_GL
			fprintf(stderr,
				"%s: The -title option is not supported by this installation.\n",
				argv[0]);
			exit(1);
#endif
		}
#if COMBINED
		else if (!strcmp(argv[i], "-seed")) {
			set_seed(atoi(argv[++i]));
		}
#endif
#if !COMBINED
		else if (!strcmp(argv[i], "-float")) {
			use_floats = true;
		}
#endif
		else if (!strcmp(argv[i], "-ogl")) {
			open_gl_option = true;
#if !OPEN_GL
			fprintf(stderr, 
				"%s: The -ogl option is not supported by this installation.\n", 
				argv[0]);
			exit(1);
#endif
		}
#if OPEN_GL
		else if (!strcmp(argv[i], "-display"))
			display = argv[++i];
#endif
		else if (!strcmp(argv[i], "-f")) {
			field = atoi(argv[++i]);
			if (field < 1)
				error("Field must be integer > 0",
					(char*) NULL);
		}
#if COMBINED
		else if (!strcmp(argv[i], "-o"))
			output = true;
		else if (!strcmp(argv[i], "-F"))
			filter = true;
#endif
		else if (!strcmp(argv[i], "-p")) {
			if (sscanf(argv[++i], "%ld", &pause_time) != 1)
				error("Pause time must be an integer",
					(char*) NULL);
		}
#if COMBINED
		else if (!strcmp(argv[i], "-r"))
			time_file = fopen(argv[++i], "r");
#endif
		else if (!strcmp(argv[i], "-s")) {
			int sides = sscanf(argv[++i], 
					"%d,%d,%d",
					&cell_size_x, &cell_size_y, &cell_size_z);
			if (sides < 1)
				error("Cell size(s) must be integer",
					(char*) NULL);
			if (sides == 1) cell_size_z = cell_size_y = cell_size_x;
			if (cell_size_x < 1) cell_size_x = 1;
			if (cell_size_y < 1) cell_size_y = 1;
			if (cell_size_z < 1) cell_size_z = 1;
		}
		else if (!strcmp(argv[i], "-map"))
			if (i == argc-1)
				usage(command);
			else
				map_name = argv[++i];
		else if (!strcmp(argv[i], "-dim")) {
			int count;
			char *dim_token;
			if (i == argc-1)
				usage(command);

			/* Give dim, lower and upper reasonable defaults. */
			for (count = 0; count < MAX_DIMS; count++)
				lower[count] = upper[count] = 0;

			/* Read/parse the dimensions. */
			dim_token = strtok(argv[++i], ",");
			while (dim_token) {
				if (!strchr(dim_token, '.'))
					lower[dim_given] = upper[dim_given]
							= atoi(dim_token);
				else {
					if (2 != sscanf(dim_token, 
							" %d..%d ", 
							&lower[dim_given],
							&upper[dim_given]))
						usage(command);

					if (range_dim_1_index < 0)
						range_dim_1_index = dim_given;
					else if (range_dim_2_index < 0)
						range_dim_2_index = dim_given;
					else
						range_dim_3_index = dim_given;
				}
				dim_given++;
				dim_token = strtok((char*) NULL, ",");
			}

			/* Establish default ranges if necessary. */
			if (range_dim_1_index < 0) 
				range_dim_1_index = MAX_DIMS - 1;
			if (range_dim_2_index < 0) 
				range_dim_2_index = MAX_DIMS - 1;
			if (range_dim_3_index < 0) 
				range_dim_3_index = MAX_DIMS - 1;
		}
		else
			fprintf(stderr, "%s: Unknown option '%s' ignored.\n",
				command, argv[i]);

	/* Can't give more than one of these options. */
	if (open_gl_option > 1)
		usage(command);

	/* If no option was explicitly given, then use the default. */
	if (!(open_gl_option)
#if COMBINED
	    && !output && !filter
#endif
	)

#if OPEN_GL
	/* Can only request a paritcular display for open_gl. */
	if (display && !(open_gl_option))
		error("Must use the -display option with the -ogl option",
			(char*) NULL);
#endif

	if (0 == dim_given)
#if COMBINED
	/* Display upto the first two dimensions in their entirety unless
	   otherwise specified on the command line.
	*/
		init_display();
#else
	/* Check that dimensions were described. */
		usage(command);
#endif

	if (use_floats) direct_map = false;

	/* Determine and check ranges. */
	for (i = 0; i < MAX_DIMS; i++) {
		range[i] = upper[i] - lower[i] + 1;
		if (range[i] <= 0) {
			char msg[MAX_STRING_SIZE];
			sprintf(msg, 
				"Dimension %d has decreasing range of indices",
				i+1);
			error(msg, (char*) NULL);
		}
		else if (range[i] > 1)
			range_dim_given++;
	}

	/* Determine if too many ranges were given. */
#if OPEN_GL
	if (open_gl_option) {
		if (range_dim_given > 3)
			error("A maximum of 3 dimension ranges can be given with -ogl",
				(char*) NULL);
	} else
#endif
	if (!open_gl_option && range_dim_given > 2)
		error("A maximum of 2 dimension ranges can be given", (char*) NULL);

#if COMBINED
	if (open_gl_option)
		view = true;
#endif

#if !WINTEL
	/* Set the signal so things can be cleaned up when the program
	   is terminated.
	*/
        signal(SIGHUP, exit_signaled);
        signal(SIGINT, exit_signaled);
        signal(SIGQUIT, exit_signaled);
        signal(SIGILL, exit_signaled);
        signal(SIGTRAP, exit_signaled);
        signal(SIGABRT, exit_signaled);
#if !COMBINED
        signal(SIGFPE, exit_signaled);
#endif
        signal(SIGKILL, exit_signaled);
        signal(SIGBUS, exit_signaled);
        signal(SIGSEGV, exit_signaled);
        signal(SIGPIPE, exit_signaled);
        signal(SIGTERM, exit_signaled);
        signal(SIGURG, exit_signaled);
#endif

#if COMBINED
	MAX_FIELD_VALUE_WIDTH = max_value_width[field-1];

	MAX_VALUE_WIDTH = max_value_width[0];
	for (i = 1; i < field_count; i++)
		if (MAX_VALUE_WIDTH < max_value_width[i])
			MAX_VALUE_WIDTH = max_value_width[i];
#endif
	/* Calculate the max_field_value corresponding to the
	   MAX_FIELD_VALUE_WIDTH.
	*/
	for (i = 0; i < MAX_FIELD_VALUE_WIDTH; i++) max_field_value *= 10;

	/* Calculate the max_value corresponding to the MAX_VALUE_WIDTH. */
	for (i = 0; i < MAX_VALUE_WIDTH; i++) max_value *= 10;

#if OPEN_GL
	if (open_gl_option)
		setup_open_gl(map_name, display,
				cell_size_x, cell_size_y, cell_size_z, title);
#endif

#if COMBINED
	if (view) {
#endif
		/* Allocate the space for the cell_vals and cell_map_vals. */
		if (use_floats)
			cell_float_vals = (float*) calloc((unsigned int) 
						(range[range_dim_1_index] * 
						 range[range_dim_2_index] *
						 range[range_dim_3_index]), 
					   (unsigned int) sizeof(float));
		else
			cell_vals = (celltype*) calloc((unsigned int) 
						(range[range_dim_1_index] * 
						 range[range_dim_2_index] *
						 range[range_dim_3_index]), 
					   (unsigned int) sizeof(celltype));

		cell_map_vals = (maptype*) calloc((unsigned int) 
					(range[range_dim_1_index] * 
						range[range_dim_2_index] *
						range[range_dim_3_index]), 
				   (unsigned int) sizeof(maptype));

		if (((!cell_vals && !use_floats) || (!cell_float_vals && use_floats))
		    || !cell_map_vals)
			error("Insufficient memory", (char*) NULL);
#if COMBINED
	}
#endif

#if COMBINED
	if (view) {
#endif
	/* Initialize cell_vals to 0, cell_map_vals to map_value(0). */
	if (use_floats)
		value_for_0 = map_float_value(0);
	else
		value_for_0 = map_value(0);

	for(i = range[range_dim_1_index]*range[range_dim_2_index]*range[range_dim_3_index]-1;i >= 0; i--) {
		if (use_floats)
         		cell_float_vals[i] = 0;
		else
         		cell_vals[i] = 0;

         	cell_map_vals[i] = value_for_0;
	}
#if COMBINED
	}
#endif

#if !COMBINED
	/* Read the first time from the input. */
	i = scanf("%ld", &next_time);
	if (0 == i)
		input_error("Missing time specification", (char*) NULL);
	else if (EOF == i)
		/* End of input. */
		next_time = -1;
	else if (next_time < 0)
		/* Check legality of new _time_step. */
		input_error("Time must be >= 0", (char*) NULL);
#endif

#if COMBINED
        /* Initialize the cell universe. */
	init_cells();

#if MAX_CPUS > 1
	if (cpus > 1) create_threads();
	else
#endif
#endif
	start_automata();

	return 0;
}
