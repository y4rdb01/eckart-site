/******************************************************
      The MicroVector Library.   

  (c) 1994 Micah Beck and Antonio Castellanos.
      May not be redistributed in any modified form.
******************************************************/

#include <stdlib.h>
#include <stdio.h>

#define UV_INLINE
#define UV_OWNER
#include "uvector.h"

/** Table of masks **/
/*
uvec uv_ones[UV_SIZE+1];
*/

/*****************************************************************************
	Field Manipulation
*****************************************************************************/

uvec uv_fmask	(int w) 		{ return UV_FMASK(w); }
uvec uv_fval	(uvec v, int w)		{ return UV_FVAL(v, w); }

uvec uvo_fmask	(int w) 		{ return UVO_FMASK(w); }
uvec uvo_fval	(uvec v, int w)		{ return UVO_FVAL(v, w); }
uvec uvo_fsign	(uvec v, int w)		{ return UVO_FSIGN(v, w); }
uvec uvo_fsext	(uvec v, int w)		{ return UVO_FSEXT(v, w); }

uvec uv_fget	(uvec v, int w, int i)	{ return UV_FGET(v, w, i); }
uvec uv_fset	(uvec v, int w, int i, uvec a)
					{ return UV_FSET(v, w, i, a);}

int  uvo_fget	(uvec v, int w, int i)	{ return UVO_FGET(v, w, i); }
uvec uvo_fset	(uvec v, int w, int i, uvec a)
					{ return UVO_FSET(v, w, i, a);}

/*****************************************************************************
	Simple Microvectors
*****************************************************************************/

/** 	Bit-wise AND **/
uvec
uv_and(uvec u, uvec v, int w)
{
    return UV_AND(u, v, w);
}

/** 	Bit-wise OR **/
uvec
uv_or(uvec u, uvec v, int w)
{
    return UV_OR(u, v, w);
}

/** 	Bit-wise XOR **/
uvec
uv_xor(uvec a, uvec v, int w)
{
    return UV_XOR(a, v, w);
}

/** 	Bit-wise complement **/
uvec
uv_compl(uvec v, int w)
{
    return UV_COMPL(v, w);
}

/** 	Logical complement **/
uvec
uv_not(uvec v, int w)
{
    return (v ^ (~uv_ones[w]));
}

/** 	Add two integer vectors **/
uvec
uv_plus(uvec a, uvec v, int w)
{
    return UV_PLUS(a, v, w);
}

/** 	Subtract two integer vectors **/
uvec
uv_minus(uvec u, uvec v, int w)
{
    return UV_MINUS(u, v, w);
}


/**	Left shift an overflow vector one bit position **/
uvec
uv_lshift(uvec v, int w)
{
    return (v << 1) & (~uv_ones[w]);
}

/**	Right shift an overflow vector one bit position **/
uvec
uv_rshift(uvec v, int w)
{
    return (v & uv_ones[w]) >> 1;
}

/**	Right arithmetic shift an overflow vector one bit position **/
uvec
uv_rshifta(uvec v, int w)
{
    return ((v & uv_ones[w]) >> 1) | ((v & uv_ones[w]) << (w - 2));
}

/** 	Convert a scalar to a simple vector **/
uvec
uv_s2vec(uvec s, int w)
{
	return s * uv_ones[w];
}

/** 	Multiply a simple integer vector by an integer constant. **/
uvec
uv_smul(uvec s, uvec v, int w)
{
	return UV_SMUL(v, s, w);
}

/** 	Sign of simple vector **/
uvec
uv_sign(uvec v, int w)
{
    return (((uvec)(v) >> ((w)-1)) & uv_ones[w]);
}


/** 	Componentwise equality of vectors **/
uvec
uv_equal(uvec u, uvec v, int w)
{
    int i;
    uvec e = 0;

    e = ~(u ^ v);
    for (i = 1; i < UV_SIZE/w; i++)  {
 	e = e & (e >> i);	
    }
    return e & uv_ones[w];
}

/*****************************************************************************
	Unpacked operations
*****************************************************************************/

/** 	Multiply two simple integer vectors **/
uvec
uv_mul(uvec u, uvec v, int w)
{
  register int i;
  register uvec p;

  for (i = 0; i < UV_LENGTH(w); i++)
	UV_SET(p, w, i, UV_FVAL(UV_FGET(u, w, i)*UV_FGET(v, w, i), w));

  return p;
}

/** 	Multiply two simple floating point vectors **/
uvec
uv_xmul(uvec u, uvec v, int w, int f)
{
  register int i;
  register uvec p;

  for (i = 0; i < UV_LENGTH(w); i++)
    UV_SET(p, w, i,
	UV_FVAL((UV_FGET(u, w, i)*UV_FGET(v, w, i)) >> f , w));

  return p;
}

/** 	Multiply a fixed point vector by a fixed point constant. **/
uvec
uv_xsmul(uvec s, uvec v, int w, int f)
{
    return ((UV_SMUL(s, v, w) & ~(uv_ones[w] * UV_FMASK(f)) >> f));
}

/*****************************************************************************
	Overflow Microvectors
*****************************************************************************/


/** 	Zero buffer bit of overflow vector **/
uvec
uvo_val(uvec v, int w)
{
    return (v & (uv_ones[w] * UVO_FMASK(w)));
}

/** 	Bit-wise AND **/
uvec
uvo_and(uvec u, uvec v, int w)
{
    return UV_AND(u, v, w);
}

/** 	Bit-wise OR **/
uvec
uvo_or(uvec u, uvec v, int w)
{
    return UV_OR(u, v, w);
}

/** 	Bit-wise XOR **/
uvec
uvo_xor(uvec u, uvec v, int w)
{
    return UV_XOR(u, v, w);
}

/** 	Bit-wise complement **/
uvec
uvo_compl(uvec v, int w)
{
    return UV_COMPL(v, w);
}

/** 	Logical complement **/
uvec
uvo_not(uvec v, int w)
{
    return uv_not(v, w);
}


/**	Add two overflow vectors  **/
uvec
uvo_plus(uvec u, uvec v, int w)
{
    return uvo_val(uv_plus(u, v, w), w);
}

/**	Componentwise negative of a overflow vector **/
uvec
uvo_neg(uvec v, int w)
{
/*
     return uvo_val(~v + uv_ones[w], w);

     Due to a bug found by me, J Dana Eckart, Micah Beck sent the
     following change.
*/
     return uvo_val(uvo_val(~v, w) + uv_ones[w], w);
}

/**	Subtract two overflow vectors **/
uvec
uvo_minus(uvec u, uvec v, int w)
{
    return uvo_plus(u, uvo_neg(v, w), w);
}

/**	Left shift an overflow vector one bit position **/
uvec
uvo_lshift(uvec v, int w)
{
    return uvo_val(v << 1, w);
}

/**	Right shift an overflow vector one bit position **/
uvec
uvo_rshift(uvec v, int w)
{
    return uv_rshift(v, w);
}

/**	Right arithmetic shift an overflow vector one bit position **/
uvec
uvo_rshifta(uvec v, int w)
{
    return uv_rshifta(v, w);
}

 
/** 	Sign of overflow vector **/
uvec
uvo_sign(uvec v, int w)
{
    return (((uvec)(v) >> ((w-2)) & uv_ones[w]));
}

/** 	Componentwise equality of overflow vectors **/
uvec
uvo_equal(uvec u, uvec v, int w)
{
    uv_equal(u, v, w);
}

/** 	Componentwise greater-than between overflow vectors **/
uvec
uvo_gt(uvec u, uvec v, int w)
{
    return (uvo_minus(v, u, w) >> (w-2)) & uv_ones[w];
}

/** 	Componentwise equality less-than between overflow vectors **/
uvec
uvo_lt(uvec u, uvec v, int w)
{
    uvec my_uvec = 0;

    return (uvo_minus(u, v, w) >> (w-2)) & uv_ones[w];
}

/*****************************************************************************
	Unpacked operations
*****************************************************************************/

/** 	Multiply two integer overflow vectors **/
uvec
uvo_mul(uvec u, uvec v, int w)
{
  register int i;
  register uvec p;

  for (i = 0; i < UV_LENGTH(w); i++)
	UVO_SET(p, w, i, UVO_FGET(u, w, i)*UVO_FGET(v, w, i));

  return p;
}

/** 	Multiply two fixed overflow vectors **/
uvec
uvo_xmul(uvec u, uvec v, int w, int f)
{
  register int i;
  register uvec p;

  for (i = 0; i < UV_LENGTH(w); i++)
	UVO_SET(p, w, i, (UVO_FGET(u, w, i)*UVO_FGET(v, w, i)) >> f);

  return p;
}

/** 	Convert a scalar to an overflow vector **/
uvec
uvo_s2vec(uvec s, int w)
{
	return s * uv_ones[w];
}

/** 	Multiply an overflow vector by a scalar. **/
uvec
uvo_smul(uvec s, uvec v, int w)
{
    return uvo_val(uv_smul(s, UV_EVENS(v, w), 2*w), w)
		| (uvo_val(uv_smul(s, UV_ODDS(v, w), 2*w), w) << w);

/*   return uvo_mul(v, uvo_s2vec(s, w), w);*/
}

/** 	Multiply a fixed point overflow vector by a fixed point scalar. **/
uvec
uvo_xsmul(uvec s, uvec v, int w, int f)
{
    return uvo_val(uv_xsmul(s, UV_EVENS(v, w), 2*w, f) >> f, w)
		| (uvo_val(uv_xsmul(s, UV_ODDS(v, w), 2*w, f) >> f, w) << w);

/*   return uvo_xmul(v, uvo_s2vec(s, w), w, f);*/
}

/** 	Divide two overflow vectors **/
uvec
uvo_div(uvec u, uvec v, int w)
{
  register int i, t;
  register uvec d;

  for (i = 0; i < UV_SIZE/w; i++)
   if ((t = UVO_FSEXT(UVO_FGET(v, w, i), w)) != 0)
	UVO_SET(d, w, i, UVO_FSEXT(UVO_FGET(u, w, i), w)/t);

  return d;
}

/** 	Divide two overflow vectors **/
uvec
uvo_xdiv(uvec u, uvec v, int w, int f)
{
  register int i, t;
  register uvec d;

  for (i = 0; i < UV_SIZE/w; i++)
    if ((t = UVO_FSEXT(UVO_FGET(v, w, i), w)) != 0)
	UVO_SET(d, w, i, UVO_FSEXT(UVO_FGET(u, w, i), w)/t);

  return d;
}

/** 	Divide an overflow vector by a scalar. **/
uvec
uvo_sdiv(uvec u, int s, int w)
{
    return uvo_div(u, s * uv_ones[w], w);
}


/** 	Divide a fixed point overflow vector by a fixed point scalar. **/
uvec
uvo_xsdiv(uvec u, int s, int w, int f)
{
    return uvo_xdiv(u, uv_ones[w] * s, w, f);
}

/** One-sided conditional expression **/
uvec
uv_cond(uvec b, uvec v, int w)
{
    return (b * UV_FMASK(w)) & v;
}

/** Two-sided conditional expression **/
uvec
uv_if(uvec b, uvec t, uvec f, int w)
{
    return uv_cond(b, t, w) | uv_cond(uv_not(b, w), f, w);
}

/*****************************************************************************
	Stored microvectors and microvector arrays with replicated boundary
*****************************************************************************/

/** Sets the value of a stored vector **/
void
uvp_set(uvec *vp, int w, int i, uvec v)
{
  UVP_SET(vp, w, i, v);
}

/** Sets the value of an array value **/
void
uva_set2(uvec *vp, int w, int i, int j, uvec v)
{
   UVA_SET2(vp, w, i, j, v);
}

/*****************************************************************************
	Blocked data distribution
*****************************************************************************/

/** Returns a field from a boundary array **/
uvec
uvb_bget(uvec *vp, int l, int w, int i, int b)
{
  return UVB_BGET(vp, l, w, i, b);
}

/** Returns a field from a simple array **/
uvec
uva_bget(uvec *vp, int l, int w, int i)
{
  return UVA_BGET(vp, l, w, i);
}

/** Sets a field in a boundary array **/
void
uvb_bset(uvec *vp, int l, int w, int i, uvec v, int b)
{
     UVB_BSET(vp, l, w, i, v, b);
}

/** Sets a field in a boundary array **/
void
uva_bset(uvec *vp, int l, int w, int i, uvec v)
{
     UVA_BSET(vp, l, w, i, v);
}

/** Replicate the boundary **/
void
uva_bwrap(uvec *vp, int l, int w, int b)
{
  int i;

  for (i = 0; i < b; i++)
  {
    vp[i] =       (vp[l-(2*b)+i] << w)
		| (vp[l-(2*b)+i] >> ((sizeof(uvec) * 8) - w));

    vp[l-b+i] =   (vp[b+i]       >> w)  
		| (vp[b+i]       << ((sizeof(uvec) * 8) - w));
  }
}

/*****************************************************************************
	Scattered data distribution
*****************************************************************************/

/** Returns a field from a boundary array **/
uvec
uva_sget(uvec *vp, int w, int i)
{
  return UVA_SGET(vp, w, i);
}

/** Returns a field from a simple array **/
void
uva_sset(uvec *vp, int w, int i, uvec v)
{
     UVA_SSET(vp, w, i, v);
}

/** Replicate the boundary **/
void
uva_swrap(uvec *vp, int l, int w, int b)
{
  int i;

  for (i = 0; i < b; i++)
  {
    vp[i] =  vp[l-(2*b)+i];

    vp[l-b+i] = vp[b+i];
  }
}

