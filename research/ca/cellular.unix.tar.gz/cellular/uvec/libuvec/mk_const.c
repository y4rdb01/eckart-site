/************************************************
  The MicroVector Library.
  This programs automatically generates all
  the constant macros necessary for an architecture.

  (c) 1994 Micah Beck and Antonio Castellanos.
      May not be redistributed in any modified form.
*************************************************/
#include <stdio.h>

int
main(argv, argc)
int argc;
char *argv[];
{
  int i, j, w;
  unsigned long int x;

  fprintf(stdout, "/* This macro was file automatically generated. */\n\n");

  /*
   * Generate shift-and-and macros
   */

  fprintf(stdout,  "#define UV_SHAND1(A)	(A)\n");
  for (i = 1; i < sizeof(long)*8; i++)
	fprintf(stdout, "#define UV_SHAND%d(A)	((A >> %d) & UV_SHAND%d(A))\n",
		i+1, i, i);

  fprintf(stdout, "\n");

  /*
   * Generate one vector macros
   */
  for (w = 1; w <=(sizeof(long)*4); w++)
  {
        x = 0;
    	for (i = 0; i + w <=  sizeof(long)*8; i += w)
		x = (x << w) | 1;

    	fprintf(stdout, "#define UV_ONES%d		0x%0lx\n", w, x);
  }
  fprintf(stdout, "#define UV_ONES%d		0x1\n",	sizeof(long)*8, x);

   /*
    *  Generate the uv_ones[] vector of masks
    */

  fprintf(stdout, "\n\n#ifdef UV_OWNER\n\n");
  fprintf(stdout, "uvec uv_ones[] = { 0\n");
  for(i=1;i<=sizeof(long int)*4;i++) {
    fprintf(stdout, "\t, UV_ONES%d\n", i);
  }
  fprintf(stdout, "};\n\n");
  fprintf(stdout, "#endif\n");

  return 0;
}
