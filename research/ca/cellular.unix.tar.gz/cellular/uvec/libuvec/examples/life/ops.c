/********************************************
      MicroVector Library Test Program.
********************************************/
#include <stdio.h>
#include "uvector.h"

/** 	Print a simple integer vector. **/
void
uv_print(uvec v, int w)
{
    int i;

    for (i = UV_LENGTH(w)-1 ; i >= 0; i--)

	printf("%3d  ", UV_FGET(v, w, i));
    printf("\n");
}

/** 	Print a signed overflow vector **/
void
uvo_print(uvec v, int w)
{
    int i;

    for (i = UV_LENGTH(w) - 1; i >= 0; i--)
	printf("%d  ", UVO_FSEXT(UVO_FGET(v, w, i), w));
    printf("\n");
}

/** 	
	UVEC SUPPORT - Prints the contents of a fixef-point signed 
	overflow vector.
**/
void
uvo_fprint(uvec v, int w, int f)
{
    int i;
    uvec temp;

    for (i = UV_LENGTH(w) - 1; i >= 0; i--)
	printf("%f ", UV_X2F(UVO_FSEXT(UVO_FGET(v, w, i), w), f));
    printf("\n");
}

int
main()
{
   int i;
   uvec a = 0, b = 0, c = 0, d = 0;
   uvec u = 0, v = 0, w = 0, x = 0;
   /** Create some unsigned MicroVectors to test **/

   UV_SET(a, 4, 0, 1);
   UV_SET(a, 4, 1, 2);
   UV_SET(a, 4, 2, 3);
   UV_SET(a, 4, 3, 3);
   UV_SET(a, 4, 4, 1);
   UV_SET(a, 4, 5, 2);
   UV_SET(a, 4, 6, 4);
   UV_SET(a, 4, 7, 8);

   UV_SET(b, 4, 0, 1);
   UV_SET(b, 4, 1, 2);
   UV_SET(b, 4, 2, 3);
   UV_SET(b, 4, 3, 4);
   UV_SET(b, 4, 4, 2);
   UV_SET(b, 4, 5, 7);
   UV_SET(b, 4, 6, 3);
   UV_SET(b, 4, 7, 1);

   UV_SET(c, 4, 0, 10);
   UV_SET(c, 4, 1, 8);
   UV_SET(c, 4, 2, 3);
   UV_SET(c, 4, 3, 5);
   UV_SET(c, 4, 4, 15);
   UV_SET(c, 4, 5, 12);
   UV_SET(c, 4, 6, 9);
   UV_SET(c, 4, 7, 11);

/** Test of signed width = 4 (range 0 < n < 15) **/

        printf("Testing the MicroVector Library\n\n");
	printf("Unsigned: (width = 4 bits)\n");
        printf("	a =  "); uv_print(a, 4);	
        printf("	b =  "); uv_print(b, 4);	
        printf("	c =  "); uv_print(c, 4);
	printf("\n");

        printf("	 a  +  b = \t"); 
	uv_print(UV_PLUS(a, b, 4), 4);	
        printf("(!!)   a  -  b = \t"); 
	uv_print(UV_MINUS(a, b, 4), 4);	
        printf("	 c  -  a = \t"); 
	uv_print(UV_MINUS(c, a, 4), 4);	
        printf("	 a  =  b = \t"); 
	uv_print(UV_EQUAL(a, b, 4), 4);	
        printf("	 a  =  c = \t");  
	uv_print(d = UV_EQUAL(a, c, 4), 4);	
        printf("	 compl(a=c) = \t");  
	uv_print(UV_COMPL(d, 4), 4);	
        printf("	 not(a=c) = \t");  
	uv_print(UV_NOT(d, 4), 4);	
        printf("	 a  *  b = \t");  
	uv_print(UV_MUL(a, b, 4), 4);	

/** Test of unsigned width = 8 bits (range -63< n < +63) **/

   UVO_SET(u, 8, 0, UVO_FVAL(25, 8));
   UVO_SET(u, 8, 1, UVO_FVAL(-2, 8));
   UVO_SET(u, 8, 2, UVO_FVAL(-3, 8));
   UVO_SET(u, 8, 3, UVO_FVAL(7, 8));

   UVO_SET(v, 8, 0, UVO_FVAL(-11, 8));
   UVO_SET(v, 8, 1, UVO_FVAL(23, 8));
   UVO_SET(v, 8, 2, UVO_FVAL(-1, 8));
   UVO_SET(v, 8, 3, UVO_FVAL(-24, 8));

   UVO_SET(w, 8, 0, UVO_FVAL(2, 8));
   UVO_SET(w, 8, 1, UVO_FVAL(1, 8));
   UVO_SET(w, 8, 2, UVO_FVAL(-3, 8));
   UVO_SET(w, 8, 3, UVO_FVAL(-2, 8));

	printf("\nSigned: (width = 8 bits)\n");
        printf("	u =  ");	
	uvo_print(u, 8);
        printf("	v =  ");	
	uvo_print(v, 8);
        printf("	w =  ");	
	uvo_print(w, 8);
	printf("\n");

        printf("	 u  +  v = \t");
	uvo_print(UVO_PLUS(u, v, 8), 8);	
        printf("	 u  -  v = \t"); 
	uvo_print(UVO_MINUS(u, v, 8), 8);	
        printf("	 -u = \t");
	uvo_print(x = UVO_NEG(u, 8), 8);	
        printf("	 --u = \t");
	uvo_print(UVO_NEG(x, 8), 8);	
        printf("	 (u == w) = \t"); 
	uvo_print(x = UVO_EQUAL(u, w, 8), 8);	
        printf("	 !(u == v) = \t");  
	uvo_print(UVO_NOT(x, 8), 8);	
        printf("	 (u > v) = \t");  
	uvo_print(UVO_GT(u, v, 8), 8);	
        printf("	 (u < v) = \t");  
	uvo_print(UVO_LT(u, v, 8), 8);	
        printf("	 (u * w) = \t");  
	uvo_print(UVO_MUL(u, w, 8), 8);	
        printf("	 (w * 5) = \t");  
	uvo_print(UVO_SMUL(5, w, 8), 8);	
        printf("	 left shift(w) = \t");  
	uvo_print(UVO_LSHIFT(w, 8), 8);	
        printf("	 (v / w) = \t");
	uvo_print(UVO_DIV(v, w, 8), 8);	
        printf("	 (v / 4) = \t");
	uvo_print(UVO_SDIV(v, 4, 8), 8);	
        printf("	 right shift(v) = \t");
	uvo_print(UVO_RSHIFT(v, 8), 8);	
        printf("	 right shift arith(v) = \t");
	uvo_print(UVO_RSHIFTA(v, 8), 8);	
	printf("         fix(u, 2) = \t"); 
        uvo_fprint(u, 8, 2);
	printf("         fix(v, 1) = \t"); 
        uvo_fprint(v, 8, 1);

        return 0;}


