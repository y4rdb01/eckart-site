#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

main(argc, argv)
int argc;
char *argv[];
{
  int i, j, k, qq;
  long tstart, tend;

  int m = atoi(argv[1]);
  int q = atoi(argv[2]);

  float (*a)[m] = (float (*)[])malloc(m*m*sizeof(float));
  float (*b)[m] = (float (*)[])malloc(m*m*sizeof(float));
  float (*t)[m];

  for (i = 0; i < m; i++)
    for (j = 0; j < m; j++)
      a[i][j] = (i == j) ? 2 : 0;

  tstart = time(0);

  for (qq = 0; qq < q; qq++)
  {
    for (i = 0; i < m; i++)
    {
      register float *bp = b[i];

      for (k = 0; k < m; k++)
      {
	register float x = a[i][k];
	register float *ap = a[k];

	for (j = 0; j < m; j++)
            *bp += x * ap[j];
      }
    }
    t = a;
    a = b;
    b = t;
  }

  tend = time(0);
  fprintf(stderr, "mmulf: %dx%d  Time = %d seconds\n", m, m, tend-tstart);

#ifdef PRINT
  printf("a[0][0] = %f\n", a[0][0]);
#endif

  return 0;
}
