/*************************************************
  MicroVectorized Fixed-point Matrix Multiplication
*************************************************/
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include "uvector.h"

main(argc, argv)
int argc;
char *argv[];
{
  int i, j, k1, k2, qq;
  long tstart, tend;

  int m = atoi(argv[1]);
  int w = atoi(argv[2]);
  int q = atoi(argv[3]);
  int n = UV_SIZE/w;
  int mm = m/n;

  uvec (*a)[mm] = (uvec (*)[])malloc(m*mm*sizeof(uvec));
  uvec (*b)[mm] = (uvec (*)[])malloc(m*mm*sizeof(uvec));
  uvec (*t)[mm];

  for (i = 0; i < m; i++)
    for (k1 = 0; k1 < mm; k1++)
      for (k2 = 0; k2 < n; k2++)
      	UVA_SET2(a[i], 8, k1, k2,
		UVO_FVAL(UV_I2X((i == (k1*n + k2)) ? 2 : 0, 2), 8));

  tstart = time(0);

  for (qq = 0; qq < q; qq++)
  {
    for (i = 0; i < m; i++)
      for (j = 0; j < mm; j++)
	b[i][j] = 0;

    for (i = 0; i < m; i++)
      for (k1 = 0; k1 < mm; k1++)
        for (k2 = 0; k2 < n; k2++)
        {
	  register int x = UVO_FGET(a[i][k1], 8, k2);
	  register uvec *ap = a[k1*n+k2];
	  register uvec *bp = b[i];

      	  for (j = 0; j < mm; j++)
            bp[j] = UVO_PLUS(bp[j], UVO_XSMUL(x, ap[j], 8, 2), 8);

	}

    t = a;
    a = b;
    b = t;
  }

  tend = time(0);
  fprintf(stderr, "UV_SIZE: %d\n", UV_SIZE);
  fprintf(stderr, "mmulx: %dx%d  Time = %d seconds\n", m, m, tend-tstart);

#ifdef PRINT
  printf("a[0][0] = %f\n", UV_X2F(UVO_FSEXT(UVO_FGET(a[0][0], 8, 0), 8), 2));
#endif

 return 0;
}
