/****************************************
    Packed Matrix Multiplication 
****************************************/
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include "uvector.h"

main(argc, argv)
int argc;
char *argv[];
{
  int i, j, k1, k2, qq;
  long tstart, tend;

  int m = atoi(argv[1]);
  int w = atoi(argv[2]);
  int q = atoi(argv[3]);
  int n = UV_SIZE/w;
  int mm = m/n;

  uvec (*a)[mm] = (uvec (*)[])malloc(m*mm*sizeof(uvec));
  uvec (*b)[mm] = (uvec (*)[])malloc(m*mm*sizeof(uvec));
  uvec (*t)[mm];

  for (i = 0; i < m; i++)
    for (k1 = 0; k1 < mm; k1++)
      for (k2 = 0; k2 < n; k2++)
      	UVA_SET2(a[i], w, k1, k2, (i == (k1*n + k2)) ? 2 : 0);

  tstart = time(0);

  for (qq = 0; qq < q; qq++)
  {
    for (i = 0; i < m; i++)
      for (j = 0; j < mm; j++)
	b[i][j] = 0;

    for (i = 0; i < m; i++)
      for (k1 = 0; k1 < mm; k1++)
        for (k2 = 0; k2 < n; k2++)
        {
	  register int x = UV_FGET(a[i][k1], w, k2);
	  register uvec *ap = a[k1*n+k2];
	  register uvec *bp = b[i];
	  register uvec at, bt;
	  register int jj;

      	  for (j = 0; j < mm; j++)
	  {
	    at = ap[j];
	    bt = bp[j];
	    for (jj = 0; jj < n; jj++)
              UV_SET(bt, w, jj, x*UV_FGET(at, w, jj) + UV_FGET(bt, w, jj));
	    bp[j] = bt;
	  }
        }

    t = a;
    a = b;
    b = t;
  }

  tend = time(0);
  fprintf(stderr, "UV_SIZE: %d\n", UV_SIZE);
  fprintf(stderr, "mmulp: %dx%d  Time = %d seconds\n", m, m, tend-tstart);

#ifdef PRINT
  printf("a[0][0] = %d\n", UV_FGET(a[0][0], w, 0));
#endif

 return 0;
}
