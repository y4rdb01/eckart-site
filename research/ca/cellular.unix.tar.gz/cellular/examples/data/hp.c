/* hp.c
   Copyright (C) 1993, 1994  J Dana Eckart

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* Generate the input data used by hp.  A single command line argument
   indicates the size of each of two dimensions of the cell universe.
*/

#include <stdio.h>
#include <stdlib.h>
#include "my_rand.h"

int main(int argc, char *argv[]) {
	int max_size, x, y;

	/* Check usage. */
	if (argc == 1) {
                fprintf(stderr, "%s: size of automaton must be given.\n",
                        argv[0]);
                return 1;
        } else if (argc > 2)
		fprintf(stderr, "%s: extra options ignored.\n", argv[0]);

	max_size = atoi(argv[1]);

	printf("0\n");

	for (x = 0; x < max_size; x++)
		for (y = 0; y < max_size; y++) {
			int status = my_random()%3;

			printf("[%d, %d] = ", x, y);

			/* The "state" and "health" fields. */
			if (status == 0 /* well */)
				printf("0, 0");
			else if (status == 2 /* ill */)
				printf("2, 100");
			else /* infected */
				printf("1, %ld", my_random()%99 + 1);

			printf("\n");
		}

	return 0;
}
