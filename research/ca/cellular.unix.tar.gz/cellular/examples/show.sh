#!/bin/sh
#  show.sh
#  Copyright (C) 1992, 1993, 1994, 1995, 1997, 1998  J Dana Eckart
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 1, or (at your option)
#  any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with CELLULAR; see the file COPYING.  If not, write to the 
#  Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

# Compile and run with the appropriate data file (if needed/available)
# a Cellang program contained within the filename given.
#

# Location of cellview
#
BIN=YOUR_BIN
OPEN_GL=YOUR_OPEN_GL
DEFAULT_DIM_SIZE=YOUR_DEFAULT_DIM_SIZE
WD=`dirname $0`

# Check the usage
#
USAGE="usage: `basename $0` filename [ display ]"

if (test $# -eq 0)
then
	echo "The available examples are:"
	echo " "
	echo "     life     -- the game of life (with gun and eater)"
	echo "     parity   -- a black & white parity picture"
	echo "     srdp     -- scissors, rock, dynamite, paper"
	echo "     hp       -- the hodge-podge machine"
	echo "     wirewrld -- wire world"
	echo "     firefly  -- firefly (pulse-coupled oscillator) simulation"
	echo "     ff3d     -- 3D firefly (OpenGL only)"
	echo "     travel   -- simple demonstration of agents"
	echo "     pinball  -- an impossible pinball game using agents"
	echo "     sort     -- a parallel bubble sort"
	echo "     mgas     -- gas diffusion (margolus neighborhood)"
	echo "     hpp      -- gas sound pulse (hpp lattice gas)"
	echo "     fhp      -- gas sound pulse (fhp lattice gas)"
	echo "     immis    -- two immiscible fluids (fhp lattice gas)"
	echo " "
	exit 0
elif (test $# -gt 2)
then
	echo $USAGE
	exit 1
fi

# Find the executable
#
NAME=$1

# Make sure the viewer can handle it.
#
if (test "$NAME" = "ff3d" -a "$OPEN_GL" != "1")
then
	echo "`basename $0`: 'ff3d' requires OpenGL"
	exit 1
fi

#
# The following if test should use -x, but that option doesn't work on ULTRIX.
#
if (test ! -r $WD/bin/$NAME)
then
	if (test ! -r $WD/src/$NAME)
	then
		echo "`basename $0`: file '$WD/src/$NAME' not found"
	else
		echo "`basename $0`: file '$WD/src/$NAME' not compiled"
	fi
	exit 1
fi

echo "displaying results of '$1' ..."

TITLE="-title $1"

# Determine the type of display; preference being given to first to OPEN_GL.
#
if (test $# -eq 2)
then
	if (test "$OPEN_GL" = "1")
	then
		WIN="-ogl -display $2:0"
	else
		echo "Sorry, but the Open GL option appears to be UNsupported."
		exit 1
	fi
elif (test "$OPEN_GL" = "1")
then
	WIN=-ogl
else
	echo "Sorry, but NO windowing system appears to be supported."
	exit 1
fi

# Use the proper color map.
#
if (test -r $WD/map/$NAME)
then
	MAP="-map $WD/map/$NAME"
else
	MAP=""
fi

# Display the proper field value.
#
if (test "$NAME" = "mgas")
then
	FIELD="-f 3"
elif (test "$NAME" = "sort" -o "$NAME" = "fhp")
then
	FIELD="-f 2"
else
	FIELD="-f 1"
fi

# Display the proper proportion for cells.
# 
if (test "$NAME" = "sort")
then
	SIZE="-s 7,100"
elif (test "$NAME" = "ff3d")
then
	SIZE="-s 10"
	DEFAULT_DIM_SIZE=30
else
	SIZE="-s 3"
fi

# Run the program(s).
#
if (test "$1" = "parity" -o "$1" = "life" -o "$1" = "travel" -o "$1" = "pinball")
then

	echo "avcam -c $WD/bin/$NAME $WIN $SIZE $FIELD $MAP $TITLE < $WD/data/$NAME"

	exec $BIN/avcam -c $WD/bin/$NAME $WIN $SIZE $FIELD $MAP $TITLE < $WD/data/$NAME
else

	echo "$WD/data/$NAME $DEFAULT_DIM_SIZE | avcam -c $WD/bin/$NAME $WIN $SIZE $FIELD $MAP $TITLE"

	$WD/data/$NAME $DEFAULT_DIM_SIZE | \
		exec $BIN/avcam -c $WD/bin/$NAME $WIN $SIZE $FIELD $MAP $TITLE
fi
