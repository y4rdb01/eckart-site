
# line 2 "parse"
/* parse
   Copyright (C) 1992, 1993, 1994, 1995, 1997, 1998, 1999  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "semantic.h"
#include "scanner.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The following prevent warnings/errors for some compilers. */
int yyparse(void);
int yyerror(char*);
# define AGENT 257
# define AT 258
# define CONST 259
# define DIMENSIONS 260
# define IF 261
# define THEN 262
# define ELSIF 263
# define ELSE 264
# define EXIT 265
# define END 266
# define FOR 267
# define FORALL 268
# define WHEN 269
# define OTHERWISE 270
# define OF 271
# define ASSIGN 272
# define PLUS 273
# define MINUS 274
# define TIMES 275
# define DIVIDE 276
# define MOD 277
# define EQUAL 278
# define LESSER 279
# define GREATER 280
# define LESSEQ 281
# define GREATEQ 282
# define NOTEQ 283
# define AND 284
# define OR 285
# define NOT 286
# define SUCC 287
# define PRED 288
# define LEFTPAREN 289
# define RIGHTPAREN 290
# define LEFTBRACKET 291
# define RIGHTBRACKET 292
# define COMMA 293
# define DOTS 294
# define DOT 295
# define COLON 296
# define IDENTIFIER 297
# define NUMERICLITERAL 298
# define STRINGLITERAL 299

#include <inttypes.h>

#ifdef __STDC__
#include <stdlib.h>
#include <string.h>
#else
#include <malloc.h>
#include <memory.h>
#endif

#include <values.h>

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
#ifndef yyerror
#if defined(__cplusplus)
	void yyerror(const char *);
#endif
#endif
#ifndef yylex
	int yylex(void);
#endif
	int yyparse(void);
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#endif

#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
#ifndef YYSTYPE
#define YYSTYPE int
#endif
YYSTYPE yylval;
YYSTYPE yyval;
typedef int yytabelem;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#if YYMAXDEPTH > 0
int yy_yys[YYMAXDEPTH], *yys = yy_yys;
YYSTYPE yy_yyv[YYMAXDEPTH], *yyv = yy_yyv;
#else	/* user does initial allocation */
int *yys;
YYSTYPE *yyv;
#endif
static int yymaxdepth = YYMAXDEPTH;
# define YYERRCODE 256

# line 422 "parse"


boolean syntax_error;	/* True iff a syntax error was encountered. */

/* The number of dimensions to expect from the "-s" option if present. 
   A value of 0 indicates that the "-s" option wasn't given.
*/
int dims_expected = 0;

/* The size to use for each dimension of the universe. */
int dim_size[MAX_SUPPORTED_DIMENSIONS];

/* The number of cpus to generate code for. */
int cpus = DEFAULT_CPUS;

/* Keep track of the number of trace indices given and their values. */
int trace_count = 0;
int trace_point[MAX_SUPPORTED_DIMENSIONS];

/* Determine if a field was specified for display.  If so, it contains
   the field specified.
*/
int field_given = 0;

/* The number of bits to use when compiling for use with microvectors.  A
   value of 0 indicates that the option was not specified.
*/
int mv_bits = 0;
boolean mv_signed = false;

/* A range check is generated for array indices to make sure they are
   within bounds iff rng_chk is true.  NOT checking is the default.
*/
boolean rng_chk = false;

/* True iff a filter object code file is to be compiled into the CA. */
boolean filter = false;

/* A unique number (probably the process if) to make file names unique. */
int pid = 0;

/* Print out the correct usage. */
void usage(char *command) {
	fprintf(stderr, "usage: %s [-C] [-cpus n] [-mv n[u|s]] [-s (n|n,...,n)]\n",
		command); 
	exit(1);
}

/* Indicates whether or not floating point operations should be used in
   Cellular Automata computations.
*/
boolean use_floats = false;

int main(int argc, char *argv[]) {
	int i = 0;

	/* Check for proper usage and options. */
	while (++i <= argc-1)
		if (strcmp(argv[i], "-C") == 0)
			rng_chk = true;
		else if (strcmp(argv[i], "-F") == 0)
			filter = true;
		else if (strcmp(argv[i], "-cpus") == 0) {
			cpus = atoi(argv[++i]);
			if (cpus < 1) {
				fprintf(stderr, 
					"%s: Number of CPUs must be > 0.\n", 
					argv[0]);
				exit(1);
			}
		}
		else if (strcmp(argv[i], "-mv") == 0) {
			char c;
			int count = sscanf(argv[++i], "%d%c", &mv_bits, &c);
			if (count < 1) {
				fprintf(stderr, 
					"%s: Invalid microvector specification.\n", 
					argv[0]);
				exit(1);
			}
			if (count == 2 && c == 's')
				mv_signed = true;
			else if (count == 2 && c != 'u') {
				fprintf(stderr, 
					"%s: '%c' is an invalid microvector sign indicator.\n", 
					argv[0], c);
				exit(1);
			}
			if (mv_bits < 1) {
				fprintf(stderr, 
					"%s: Number of microvector bits must be > 0.\n", 
					argv[0]);
				exit(1);
			}
		}
		else if (strcmp(argv[i], "-pid") == 0)
			pid = atoi(argv[++i]);
		else if (strcmp(argv[i], "-s") == 0) {
			char *trace_token = strtok(argv[++i], ",");
			
			do {
				dim_size[dims_expected++] = atoi(trace_token);

				if (dim_size[dims_expected-1] < 0) {
					fprintf(stderr, 
						"%s: Dimension size must be > 0.\n", 
						argv[0]);
					exit(1);
				}
			} while ((trace_token = strtok((char*) NULL, ",")) != NULL);
		}
		else if (strcmp(argv[i], "-trace") == 0) {
			char *trace_token = strtok(argv[++i], ",");
			
			do {
				trace_point[trace_count++] = atoi(trace_token);
			} while ((trace_token = strtok((char*) NULL, ",")) != NULL);
		}
		else if (strcmp(argv[i], "-f") == 0) {
			field_given = atoi(argv[++i]);
			if (field_given < 1) {
				fprintf(stderr, 
					"%s: Field must be integer > 0.\n", 
					argv[0]);
				exit(1);
			}
		}
		else if (strcmp(argv[i], "-float") == 0) {
			use_floats = true;
		} else
			usage(argv[0]);

	/* Array index range checking cannot be done with microvectors. */
	if (rng_chk && mv_bits > 0) {
		fprintf(stderr, 
			"%s: Range checking is not available with microvectors.\n",
			argv[0]);
		exit(1);
	}

	/* Setup the default dimension size(s). */
	for (i = 0; i < MAX_SUPPORTED_DIMENSIONS; i++)
		if (dims_expected == 0)
			dim_size[i] = DEFAULT_DIM_SIZE;
		else if (dims_expected == 1)
			dim_size[i] = dim_size[0];

	/* Check the validity of the trace option, if given. */
	if (trace_count > 0) for (i = 0; i < trace_count; i++)
		if (trace_point[i] < 0 || trace_point[i] >= dim_size[i]) {
			fprintf(stderr, 
				"%s: Trace index %d is larger than the dimension size.\n",
				argv[0], trace_point[i]);
			exit(1);
		}

	syntax_error = false;
	start_up();

	/* Read and compile the user's program. */
	startscan();
	yyparse();

	/* If no errors occurred, then finishup. */
	if (!scan_error && !syntax_error && !semantic_error) {
		finish_up();
		return 0;
	}
	/* Indicate an error. */
	else
		return 1;
}

#include "error.h"

int yyerror(char *s) {
	syntax_error = true;
	error_prefix();
	fprintf(stderr, "%s\n", s);
	return true;
}
static const yytabelem yyexca[] ={
-1, 0,
	0, 3,
	-2, 5,
-1, 1,
	0, -1,
	-2, 0,
-1, 92,
	287, 90,
	288, 90,
	-2, 175,
-1, 109,
	294, 32,
	-2, 34,
-1, 172,
	292, 89,
	293, 89,
	-2, 90,
-1, 174,
	292, 89,
	293, 89,
	-2, 90,
-1, 214,
	292, 89,
	293, 89,
	-2, 90,
	};
# define YYNPROD 202
# define YYLAST 420
static const yytabelem yyact[]={

    54,    44,   285,    10,   266,   233,    56,    14,    59,    39,
    40,    12,    11,    12,    12,    11,    32,    55,    37,   100,
     9,    32,    58,    96,   282,    56,   225,    59,   143,   216,
    61,   283,   228,    12,    11,    36,    10,   110,    31,   179,
     6,    51,    28,   175,   171,    58,    30,    19,    56,    29,
    59,    39,    40,     9,   272,   248,    12,    11,    93,    35,
   226,    32,    39,    40,    12,   109,   220,    10,    42,   210,
    17,   203,   139,   136,    41,    12,    11,   186,    12,    59,
    62,   169,   107,   124,     9,   104,    12,    11,   155,    18,
   126,   166,   167,   267,   176,    73,    74,   127,   129,    87,
    88,    89,   185,   152,   137,    68,   108,   292,    98,    10,
    39,    40,    34,   305,   306,   131,   156,    32,    77,    79,
    80,    81,    82,    78,   296,   297,     9,   261,   231,   194,
   195,    10,    64,   154,   101,    37,   260,   254,    66,   130,
   222,   301,   290,   287,    37,   230,   132,   238,     9,   150,
   188,   199,    36,   227,     8,   289,   192,   116,    33,     6,
   286,    36,   115,    94,   158,   151,   204,   135,   223,   178,
   212,   170,   129,   242,   163,   197,    35,   114,   142,   205,
   128,   218,    38,    57,    85,    35,   224,    83,   206,   131,
    65,    71,    48,    49,    46,   213,   236,    47,    50,    52,
     2,   240,   246,   113,    13,   209,    22,     3,   244,   244,
     3,   168,    95,   130,   122,    97,   121,    37,    92,    53,
   161,   112,    86,   160,   224,   243,   243,    76,    75,   262,
   224,    84,   224,   159,    36,    37,    72,    45,   182,   157,
   310,   304,   268,   193,   177,   134,   133,    99,    60,   270,
    90,   271,    36,    91,   198,    10,   269,   237,    35,    70,
   276,    10,    37,   145,   102,   224,   307,   117,   295,   141,
   235,    32,     9,   208,   118,   207,    35,   119,     9,    36,
   120,   125,   164,   174,    37,   173,   162,   156,   123,   214,
    32,   229,   172,    37,   255,   140,   253,   180,   303,   105,
   138,    36,   103,    35,    63,   278,    69,   308,   153,    67,
    36,   251,   309,   311,   165,   181,    43,    27,   288,   302,
    26,    25,    24,    23,    21,    35,   184,   258,    20,   265,
   183,   187,   259,   190,    35,   275,   300,   299,   148,   147,
   189,   196,   111,    84,   219,   215,   202,   293,   201,   149,
   146,   200,   211,   144,   106,   217,    16,   234,   232,   191,
     5,     4,   221,    15,   257,     7,     1,     0,     0,     0,
   263,     0,   256,     0,   239,   298,     0,     0,   294,   291,
     0,     0,   245,   249,   247,   250,   241,     0,   252,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   264,     0,   284,     0,     0,   281,     0,     0,     0,   273,
     0,     0,     0,   280,     0,   277,   279,     0,     0,   274 };
static const yytabelem yypact[]={

  -100,-10000000,  -286,  -100,-10000000,-10000000,  -284,-10000000,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,  -202,  -219,  -102,  -211,  -218,-10000000,
  -219,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,  -264,  -284,
-10000000,  -209,-10000000,  -139,-10000000,  -286,-10000000,-10000000,-10000000,-10000000,
-10000000,  -129,-10000000,  -167,-10000000,-10000000,  -189,  -160,  -163,  -176,
-10000000,  -241,-10000000,  -283,-10000000,-10000000,  -264,  -272,-10000000,-10000000,
  -219,  -277,-10000000,  -206,  -222,-10000000,  -286,-10000000,-10000000,   -96,
  -105,-10000000,  -264,-10000000,-10000000,-10000000,  -264,-10000000,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,  -264,-10000000,  -264,-10000000,-10000000,-10000000,
-10000000,-10000000,  -208,  -200,-10000000,-10000000,  -284,  -211,  -120,-10000000,
   -90,  -217,  -264,-10000000,  -220,  -272,-10000000,  -266,  -286,-10000000,
-10000000,   -92,  -169,  -136,-10000000,  -284,  -219,-10000000,-10000000,-10000000,
-10000000,-10000000,  -272,-10000000,-10000000,  -196,-10000000,  -210,  -249,-10000000,
  -286,-10000000,-10000000,-10000000,  -211,-10000000,-10000000,  -254,-10000000,-10000000,
-10000000,-10000000,-10000000,  -211,-10000000,-10000000,-10000000,  -266,  -214,  -284,
-10000000,-10000000,-10000000,-10000000,  -264,  -140,-10000000,  -212,  -112,  -189,
  -163,  -176,-10000000,  -221,  -264,  -196,-10000000,-10000000,-10000000,-10000000,
  -223,  -211,-10000000,-10000000,-10000000,-10000000,  -265,   -96,-10000000,  -264,
  -272,  -226,-10000000,  -266,-10000000,  -233,  -232,  -261,  -214,  -121,
  -143,  -294,-10000000,-10000000,  -264,-10000000,-10000000,  -117,  -112,  -264,
-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,  -196,  -286,  -286,  -237,
-10000000,  -249,-10000000,-10000000,-10000000,-10000000,  -211,-10000000,  -254,  -130,
-10000000,-10000000,   -92,  -233,  -214,-10000000,  -131,  -144,  -284,  -233,
-10000000,  -233,-10000000,-10000000,  -211,  -179,-10000000,-10000000,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,  -238,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,  -286,  -272,-10000000,-10000000,-10000000,  -284,
  -286,  -211,  -261,   -92,  -233,  -262,-10000000,-10000000,   -98,  -123,
  -219,  -107,-10000000,-10000000,-10000000,  -124,  -214,  -164,-10000000,-10000000,
-10000000,-10000000,-10000000,  -211,  -145,-10000000,  -284,-10000000,-10000000,  -219,
-10000000,-10000000,  -211,  -125,  -262,-10000000,  -264,-10000000,  -156,-10000000,
-10000000,-10000000,-10000000,-10000000,-10000000,  -264,-10000000,  -179,-10000000,-10000000,
   -98,-10000000 };
static const yytabelem yypgo[]={

     0,   366,   200,   365,   363,    47,   206,   361,   360,     0,
    94,   154,   359,   358,   357,    24,    41,    17,   356,   354,
   178,   353,   350,   349,   102,   140,   149,   347,   342,   340,
   339,   338,   335,   333,   168,   332,    43,   331,   153,   330,
   328,   324,   323,   322,   321,   320,   317,   316,   309,   134,
   308,   306,   177,   304,   302,   300,   299,   163,   297,   296,
   295,   174,   294,   180,   292,   170,   289,   283,   282,     1,
   195,   281,   188,   179,   275,   173,   273,   270,     4,   268,
   266,   264,   169,   259,   175,   257,   256,   254,   251,   249,
   248,   247,   246,   245,   244,    88,   243,   242,     2,   241,
   240,   239,   183,   237,   194,   191,   236,   233,   197,   228,
   227,   192,   187,   182,   223,   193,   184,   222,   220,   198,
   199,   219,   218,   216,   215,   171,   214,   212,   211,   205,
   202 };
static const yytabelem yyr1[]={

     0,     4,     1,     1,     2,     2,     6,     6,     7,    12,
     8,    13,    14,    13,    15,    15,    10,    10,    10,    11,
    11,    18,     3,    19,    19,    19,    23,    27,    19,    28,
    29,    19,    30,    22,    31,    32,    22,    33,    26,    26,
    25,    25,    34,    35,    34,    24,    37,    24,    20,    39,
    21,    36,    38,    38,    17,     5,     5,    40,    40,    40,
    40,    40,    40,    47,    41,    48,    51,    48,    53,    46,
    54,    56,    54,    58,    55,    60,    62,    55,    59,    59,
    64,    63,    66,    63,    67,    63,    68,    61,    65,    65,
    71,    70,    73,    73,    74,    72,    76,    72,    75,    75,
    77,    50,    50,    80,    79,    79,    78,    78,    81,    49,
    82,    82,    83,    86,    42,    84,    84,    88,    87,    89,
    85,    85,    43,    90,    91,    91,    93,    92,    92,    44,
    94,    45,    52,    97,    96,    96,    96,    98,    98,   100,
    99,    99,    95,   101,    95,    69,   103,   107,   105,   105,
   104,   109,   109,   108,   114,   112,   112,   111,   118,   116,
   116,   115,   115,   119,   119,   122,   120,   120,   120,   120,
   124,   102,   123,   123,   126,   126,   125,   125,    57,    57,
   127,   129,   128,   128,   130,   130,     9,   106,   106,   121,
   110,   110,   110,   110,   110,   110,   113,   113,    16,   117,
   117,   117 };
static const yytabelem yyr2[]={

     0,     1,     9,     0,     4,     0,     2,     2,     9,     1,
    18,     3,     1,     6,     6,     1,     5,     2,     3,     2,
     3,     1,    10,     5,     5,     4,     1,     1,    16,     1,
     1,     8,     1,     5,     1,     1,    12,     1,    11,     1,
     4,     0,     4,     1,     8,    13,     1,     9,     5,     1,
     6,     7,     6,     0,     3,     4,     0,     2,     2,     2,
     2,     2,     2,     1,     6,     6,     1,     4,     1,     6,
     4,     1,     4,     1,     8,     1,     1,    10,     5,     0,
     1,     6,     1,     8,     1,     6,     1,     5,     2,     0,
     1,     7,     4,     0,     1,     7,     1,     7,     3,     3,
     1,     8,     1,     1,     8,     3,     6,     1,     1,     6,
     6,     0,     1,     1,    18,     4,     0,     1,    10,     1,
     6,     0,     9,     4,     4,     1,     1,     5,     3,     3,
     1,    12,     6,     1,     8,     3,     1,     6,     1,     1,
     8,     3,     3,     1,     5,     2,     4,     1,     8,     0,
     4,     5,     0,     4,     1,     8,     0,     4,     1,     8,
     0,     2,     5,     2,     5,     1,     6,     3,     6,     4,
     1,    11,     4,     2,     7,     0,     6,     0,     2,     0,
     6,     1,     6,     1,     5,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     2,     3,
     3,     3 };
static const yytabelem yychk[]={

-10000000,    -1,    -2,    -6,    -7,    -8,   259,    -3,   -11,   -17,
    -9,   298,   297,    -2,    -9,    -4,   -18,   272,   291,    -5,
   -40,   -41,    -6,   -42,   -43,   -44,   -45,   -46,   261,   268,
   265,   257,    -9,   260,   -10,   -16,   -17,    -9,  -113,   273,
   274,   292,    -5,   -47,   -69,  -103,  -104,  -108,  -111,  -115,
  -119,   -16,  -120,  -121,    -9,   -17,   289,  -102,   286,   291,
   -90,    -9,   289,   -53,   271,   -11,   267,   -48,   272,   -51,
   -83,  -105,  -106,   284,   285,  -109,  -110,   278,   283,   279,
   280,   281,   282,  -112,  -113,  -116,  -117,   275,   276,   277,
  -119,  -120,  -122,   -69,   -57,  -127,   295,  -124,    -5,   -91,
   296,   -49,   -81,   -54,   291,   -56,   -19,   -17,   -16,    -9,
   259,   -28,   -11,   -49,   -52,   258,   262,  -104,  -108,  -111,
  -115,  -123,  -126,   -70,   291,   -71,   290,    -9,   -63,    -9,
   -16,   -17,   266,   -92,   -93,   257,   290,   -69,   -55,   292,
   -60,   -57,   -20,   294,   -21,   -11,   -22,   -30,   -31,   -23,
   -26,   257,   272,   -50,   269,   -95,    -9,  -101,    -5,  -107,
  -114,  -118,   -57,   -61,   -68,   -72,   287,   288,  -128,   291,
  -125,   293,   -64,   -11,   -67,   -36,   -10,   -94,   -82,   293,
   -58,   -61,   -10,   -39,   -20,   -24,   291,   -37,    -9,   -29,
   -33,   -12,   -69,   -96,   269,   270,  -102,   -84,   -87,   263,
  -105,  -112,  -116,   292,   -69,   -73,   -72,   -74,   -76,  -129,
   292,   -63,   -65,   -70,   -66,   -65,   294,   -52,   -69,   -57,
   292,   -20,   -25,   -34,    -9,   259,   292,   -38,   293,   -24,
   266,   271,   -13,   299,   -14,   -77,   -69,   -85,   264,   -84,
   -69,   -73,   -75,   -17,    -9,   -75,  -130,   -61,   292,  -125,
   -65,   -10,   -82,   -59,   267,   -62,   -26,   -25,   -24,   -35,
   267,   271,    -9,   -25,   -34,   -10,   -78,   272,   -97,   -86,
   -89,   -88,   292,   -11,   -57,   -32,    -9,   -11,   -36,   -38,
   -26,   -25,   -15,   293,   -49,   -98,   258,   266,    -5,   262,
   266,   -24,   271,   -27,   -10,   -79,   269,   270,   -95,    -5,
   -36,   266,   -15,   -69,   -99,   269,   270,   -80,   -69,   -78,
  -100,   -98 };
static const yytabelem yydef[]={

    -2,    -2,     0,     5,     6,     7,     0,     1,    21,    19,
    20,    54,   186,     4,     0,    56,     0,     0,     0,     2,
    56,    57,    58,    59,    60,    61,    62,    63,     0,     0,
   129,     0,    68,     0,     8,     0,    17,    18,   198,   196,
   197,     0,    55,    66,   112,   145,   149,   152,   156,   160,
   161,     0,   163,     0,   165,   167,     0,   179,   189,   170,
    56,   125,   108,    71,    29,    16,     0,    64,   108,     0,
     0,   146,     0,   187,   188,   150,     0,   190,   191,   192,
   193,   194,   195,   153,     0,   157,     0,   199,   200,   201,
   162,   164,    -2,     0,   169,   178,     0,     0,     0,   123,
   126,     0,     0,    69,    75,   179,    22,     0,     0,    -2,
    26,    39,     0,   102,    67,   143,    56,   147,   151,   154,
   158,   166,   179,   173,    86,     0,   168,   183,   177,    80,
     0,    84,   122,   124,     0,   128,   130,   111,    70,    73,
    86,    72,    23,     0,    24,    49,    25,     0,    46,     0,
    30,    37,     9,    65,     0,   136,   142,     0,   116,   149,
   156,   160,   172,     0,     0,    93,    94,    96,   180,   181,
     0,     0,    -2,    82,    -2,   127,     0,     0,   109,     0,
   179,     0,    48,     0,    33,    41,     0,    53,    46,     0,
     0,    12,   100,   132,     0,   135,   144,   121,   116,     0,
   148,   155,   159,   174,    87,    91,    93,     0,     0,    86,
   171,   177,    81,    88,    -2,    85,     0,   131,   111,    79,
    76,    50,    39,    41,    46,    43,     0,     0,     0,    41,
    31,     0,    10,    11,     0,   107,   133,   113,   119,   115,
   117,    92,    95,    98,    99,    97,   182,     0,   185,   176,
    83,    51,   110,    74,     0,   179,    35,    40,    42,     0,
     0,     0,    53,    39,    41,    15,   101,   108,   138,     0,
    56,     0,   184,    78,    77,     0,    46,     0,    47,    52,
    27,    38,    13,     0,     0,   134,   143,   114,   120,    56,
    36,    44,     0,     0,    15,   106,     0,   105,     0,   118,
    45,    28,    14,   103,   137,     0,   141,   107,   139,   104,
   138,   140 };
typedef struct
#ifdef __cplusplus
	yytoktype
#endif
{ char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"AGENT",	257,
	"AT",	258,
	"CONST",	259,
	"DIMENSIONS",	260,
	"IF",	261,
	"THEN",	262,
	"ELSIF",	263,
	"ELSE",	264,
	"EXIT",	265,
	"END",	266,
	"FOR",	267,
	"FORALL",	268,
	"WHEN",	269,
	"OTHERWISE",	270,
	"OF",	271,
	"ASSIGN",	272,
	"PLUS",	273,
	"MINUS",	274,
	"TIMES",	275,
	"DIVIDE",	276,
	"MOD",	277,
	"EQUAL",	278,
	"LESSER",	279,
	"GREATER",	280,
	"LESSEQ",	281,
	"GREATEQ",	282,
	"NOTEQ",	283,
	"AND",	284,
	"OR",	285,
	"NOT",	286,
	"SUCC",	287,
	"PRED",	288,
	"LEFTPAREN",	289,
	"RIGHTPAREN",	290,
	"LEFTBRACKET",	291,
	"RIGHTBRACKET",	292,
	"COMMA",	293,
	"DOTS",	294,
	"DOT",	295,
	"COLON",	296,
	"IDENTIFIER",	297,
	"NUMERICLITERAL",	298,
	"STRINGLITERAL",	299,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"program : const_decl_list declare_cells",
	"program : const_decl_list declare_cells statement_list",
	"program : /* empty */",
	"const_decl_list : const_declare const_decl_list",
	"const_decl_list : /* empty */",
	"const_declare : simple_const",
	"const_declare : array_const",
	"simple_const : CONST identifier ASSIGN const_integer",
	"array_const : CONST identifier LEFTBRACKET RIGHTBRACKET FOR const_number ASSIGN",
	"array_const : CONST identifier LEFTBRACKET RIGHTBRACKET FOR const_number ASSIGN const_array_values",
	"const_array_values : STRINGLITERAL",
	"const_array_values : /* empty */",
	"const_array_values : const_integer rest_const_integer",
	"rest_const_integer : COMMA const_integer rest_const_integer",
	"rest_const_integer : /* empty */",
	"const_integer : unary_add const_number",
	"const_integer : number",
	"const_integer : identifier",
	"const_number : number",
	"const_number : identifier",
	"declare_cells : const_number",
	"declare_cells : const_number DIMENSIONS OF fields_or_range",
	"fields_or_range : number rest_range",
	"fields_or_range : unary_add rest_signed_range",
	"fields_or_range : identifier const_or_field",
	"fields_or_range : CONST",
	"fields_or_range : CONST identifier array_or_list rest_fields agent_fields",
	"fields_or_range : CONST identifier array_or_list rest_fields agent_fields END",
	"fields_or_range : /* empty */",
	"fields_or_range : agent_fields",
	"fields_or_range : agent_fields END",
	"const_or_field : /* empty */",
	"const_or_field : rest_range",
	"const_or_field : /* empty */",
	"const_or_field : array_or_list rest_fields agent_fields",
	"const_or_field : array_or_list rest_fields agent_fields END",
	"agent_fields : AGENT",
	"agent_fields : AGENT OF field rest_fields",
	"agent_fields : /* empty */",
	"rest_fields : field rest_fields",
	"rest_fields : /* empty */",
	"field : identifier array_or_list",
	"field : CONST",
	"field : CONST identifier array_or_list",
	"array_or_list : LEFTBRACKET RIGHTBRACKET FOR const_number OF range",
	"array_or_list : /* empty */",
	"array_or_list : rest_ident_list OF range",
	"rest_range : DOTS const_integer",
	"rest_signed_range : const_number",
	"rest_signed_range : const_number rest_range",
	"range : const_integer DOTS const_integer",
	"rest_ident_list : COMMA identifier rest_ident_list",
	"rest_ident_list : /* empty */",
	"number : NUMERICLITERAL",
	"statement_list : statement statement_list",
	"statement_list : /* empty */",
	"statement : assign_or_agent_statement",
	"statement : const_declare",
	"statement : if_statement",
	"statement : forall_statement",
	"statement : exit_statement",
	"statement : agent_statement",
	"assign_or_agent_statement : assignable",
	"assign_or_agent_statement : assignable assign_or_agent",
	"assign_or_agent : ASSIGN expr_list rest_assign",
	"assign_or_agent : /* empty */",
	"assign_or_agent : place_agent",
	"assignable : identifier",
	"assignable : identifier alias_or_ident",
	"alias_or_ident : LEFTBRACKET declare_or_use",
	"alias_or_ident : /* empty */",
	"alias_or_ident : field_ref_option",
	"declare_or_use : RIGHTBRACKET",
	"declare_or_use : RIGHTBRACKET field_ref_option array_decl_option",
	"declare_or_use : /* empty */",
	"declare_or_use : array_index RIGHTBRACKET",
	"declare_or_use : array_index RIGHTBRACKET field_ref_option",
	"array_decl_option : FOR const_number",
	"array_decl_option : /* empty */",
	"index : identifier",
	"index : identifier shift_option",
	"index : unary_add const_number",
	"index : unary_add const_number shift_option",
	"index : number",
	"index : number shift_option",
	"array_index : /* empty */",
	"array_index : expression",
	"shift_option : do_shifts",
	"shift_option : /* empty */",
	"do_shifts : /* empty */",
	"do_shifts : shift rest_shifts",
	"rest_shifts : shift rest_shifts",
	"rest_shifts : /* empty */",
	"shift : SUCC",
	"shift : SUCC shift_amount",
	"shift : PRED",
	"shift : PRED shift_amount",
	"shift_amount : number",
	"shift_amount : identifier",
	"rest_assign : WHEN expression",
	"rest_assign : WHEN expression assign_list",
	"rest_assign : /* empty */",
	"rest_when : WHEN expression",
	"rest_when : WHEN expression assign_list",
	"rest_when : OTHERWISE",
	"assign_list : ASSIGN expr_list rest_when",
	"assign_list : /* empty */",
	"expr_list : /* empty */",
	"expr_list : expression rest_expr_list",
	"rest_expr_list : COMMA expression rest_expr_list",
	"rest_expr_list : /* empty */",
	"if_statement : IF expression",
	"if_statement : IF expression THEN statement_list elsif_list else",
	"if_statement : IF expression THEN statement_list elsif_list else END",
	"elsif_list : elsif elsif_list",
	"elsif_list : /* empty */",
	"elsif : ELSIF expression",
	"elsif : ELSIF expression THEN statement_list",
	"else : ELSE",
	"else : ELSE statement_list",
	"else : /* empty */",
	"forall_statement : FORALL index_var statement_list END",
	"index_var : identifier range_option",
	"range_option : COLON agent_or_range",
	"range_option : /* empty */",
	"agent_or_range : /* empty */",
	"agent_or_range : range",
	"agent_or_range : AGENT",
	"exit_statement : EXIT",
	"agent_statement : AGENT LEFTPAREN expr_list RIGHTPAREN",
	"agent_statement : AGENT LEFTPAREN expr_list RIGHTPAREN place_agent",
	"place_agent : AT associated_cell rest_place",
	"rest_place : WHEN expression",
	"rest_place : WHEN expression place_list",
	"rest_place : OTHERWISE",
	"rest_place : /* empty */",
	"place_list : AT associated_cell place_when",
	"place_list : /* empty */",
	"place_when : WHEN expression",
	"place_when : WHEN expression place_list",
	"place_when : OTHERWISE",
	"associated_cell : identifier",
	"associated_cell : /* empty */",
	"associated_cell : relative_index",
	"expression : expression_1",
	"expression_1 : expression_2 rest_expr_1",
	"rest_expr_1 : binary_boolean expression_2",
	"rest_expr_1 : binary_boolean expression_2 rest_expr_1",
	"rest_expr_1 : /* empty */",
	"expression_2 : expression_3 rest_expr_2",
	"rest_expr_2 : binary_relation expression_3",
	"rest_expr_2 : /* empty */",
	"expression_3 : expression_4 rest_expr_3",
	"rest_expr_3 : binary_add expression_4",
	"rest_expr_3 : binary_add expression_4 rest_expr_3",
	"rest_expr_3 : /* empty */",
	"expression_4 : expression_5 rest_expr_4",
	"rest_expr_4 : binary_mult expression_5",
	"rest_expr_4 : binary_mult expression_5 rest_expr_4",
	"rest_expr_4 : /* empty */",
	"expression_5 : expression_6",
	"expression_5 : unary_add expression_6",
	"expression_6 : primary",
	"expression_6 : unary_boolean primary",
	"primary : identifier",
	"primary : identifier index_or_other",
	"primary : number",
	"primary : LEFTPAREN expression RIGHTPAREN",
	"primary : relative_index field_ref_option",
	"relative_index : LEFTBRACKET",
	"relative_index : LEFTBRACKET index rest_index_list RIGHTBRACKET",
	"index_or_other : array_option field_ref_option",
	"index_or_other : do_shifts",
	"array_option : LEFTBRACKET array_index RIGHTBRACKET",
	"array_option : /* empty */",
	"rest_index_list : COMMA index rest_index_list",
	"rest_index_list : /* empty */",
	"field_ref_option : field_ref",
	"field_ref_option : /* empty */",
	"field_ref : DOT identifier name_or_array",
	"name_or_array : LEFTBRACKET",
	"name_or_array : LEFTBRACKET array_field",
	"name_or_array : /* empty */",
	"array_field : array_index RIGHTBRACKET",
	"array_field : RIGHTBRACKET",
	"identifier : IDENTIFIER",
	"binary_boolean : AND",
	"binary_boolean : OR",
	"unary_boolean : NOT",
	"binary_relation : EQUAL",
	"binary_relation : NOTEQ",
	"binary_relation : LESSER",
	"binary_relation : GREATER",
	"binary_relation : LESSEQ",
	"binary_relation : GREATEQ",
	"binary_add : PLUS",
	"binary_add : MINUS",
	"unary_add : binary_add",
	"binary_mult : TIMES",
	"binary_mult : DIVIDE",
	"binary_mult : MOD",
};
#endif /* YYDEBUG */
# line	1 "/usr/ccs/bin/yaccpar"
/*
 * Copyright (c) 1993 by Sun Microsystems, Inc.
 */

#pragma ident	"@(#)yaccpar	6.15	97/12/08 SMI"

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#define YYNEW(type)	malloc(sizeof(type) * yynewmax)
#define YYCOPY(to, from, type) \
	(type *) memcpy(to, (char *) from, yymaxdepth * sizeof (type))
#define YYENLARGE( from, type) \
	(type *) realloc((char *) from, yynewmax * sizeof(type))
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-10000000)

/*
** global variables used by the parser
*/
YYSTYPE *yypv;			/* top of value stack */
int *yyps;			/* top of state stack */

int yystate;			/* current state */
int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



#ifdef YYNMBCHARS
#define YYLEX()		yycvtok(yylex())
/*
** yycvtok - return a token if i is a wchar_t value that exceeds 255.
**	If i<255, i itself is the token.  If i>255 but the neither 
**	of the 30th or 31st bit is on, i is already a token.
*/
#if defined(__STDC__) || defined(__cplusplus)
int yycvtok(int i)
#else
int yycvtok(i) int i;
#endif
{
	int first = 0;
	int last = YYNMBCHARS - 1;
	int mid;
	wchar_t j;

	if(i&0x60000000){/*Must convert to a token. */
		if( yymbchars[last].character < i ){
			return i;/*Giving up*/
		}
		while ((last>=first)&&(first>=0)) {/*Binary search loop*/
			mid = (first+last)/2;
			j = yymbchars[mid].character;
			if( j==i ){/*Found*/ 
				return yymbchars[mid].tvalue;
			}else if( j<i ){
				first = mid + 1;
			}else{
				last = mid -1;
			}
		}
		/*No entry in the table.*/
		return i;/* Giving up.*/
	}else{/* i is already a token. */
		return i;
	}
}
#else/*!YYNMBCHARS*/
#define YYLEX()		yylex()
#endif/*!YYNMBCHARS*/

/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
#if defined(__STDC__) || defined(__cplusplus)
int yyparse(void)
#else
int yyparse()
#endif
{
	register YYSTYPE *yypvt = 0;	/* top of value stack for $vars */

#if defined(__cplusplus) || defined(lint)
/*
	hacks to please C++ and lint - goto's inside
	switch should never be executed
*/
	static int __yaccpar_lint_hack__ = 0;
	switch (__yaccpar_lint_hack__)
	{
		case 1: goto yyerrlab;
		case 2: goto yynewstate;
	}
#endif

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

#if YYMAXDEPTH <= 0
	if (yymaxdepth <= 0)
	{
		if ((yymaxdepth = YYEXPAND(0)) <= 0)
		{
			yyerror("yacc initialization error");
			YYABORT;
		}
	}
#endif

	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */
	goto yystack;	/* moved from 6 lines above to here to please C++ */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			long yyps_index = (yy_ps - yys);
			long yypv_index = (yy_pv - yyv);
			long yypvt_index = (yypvt - yyv);
			int yynewmax;
#ifdef YYEXPAND
			yynewmax = YYEXPAND(yymaxdepth);
#else
			yynewmax = 2 * yymaxdepth;	/* double table size */
			if (yymaxdepth == YYMAXDEPTH)	/* first time growth */
			{
				char *newyys = (char *)YYNEW(int);
				char *newyyv = (char *)YYNEW(YYSTYPE);
				if (newyys != 0 && newyyv != 0)
				{
					yys = YYCOPY(newyys, yys, int);
					yyv = YYCOPY(newyyv, yyv, YYSTYPE);
				}
				else
					yynewmax = 0;	/* failed */
			}
			else				/* not first time */
			{
				yys = YYENLARGE(yys, int);
				yyv = YYENLARGE(yyv, YYSTYPE);
				if (yys == 0 || yyv == 0)
					yynewmax = 0;	/* failed */
			}
#endif
			if (yynewmax <= yymaxdepth)	/* tables not expanded */
			{
				yyerror( "yacc stack overflow" );
				YYABORT;
			}
			yymaxdepth = yynewmax;

			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register const int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
			skip_init:
				yynerrs++;
				/* FALLTHRU */
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:
# line 85 "parse"
{ begin_rules(); } break;
case 2:
# line 86 "parse"
{ end_rules(); } break;
case 8:
# line 99 "parse"
{ declare_simple_const(); } break;
case 9:
# line 103 "parse"
{ declare_array_const(); } break;
case 11:
# line 106 "parse"
{ push(yytext); read_from_file(); } break;
case 12:
# line 107 "parse"
{ push_mark(); } break;
case 15:
# line 111 "parse"
{ array_value(); } break;
case 16:
# line 114 "parse"
{ mk_signed_int(); } break;
case 18:
# line 116 "parse"
{ get_simple_const(); } break;
case 20:
# line 120 "parse"
{ get_simple_const(); } break;
case 21:
# line 123 "parse"
{ set_dimensions(); } break;
case 23:
# line 127 "parse"
{ declare_default_field(); } break;
case 24:
# line 128 "parse"
{ declare_default_field(); } break;
case 26:
# line 130 "parse"
{ begin_decl_cells(); set_const_field(); } break;
case 27:
# line 132 "parse"
{ non_empty(); } break;
case 29:
# line 133 "parse"
{ begin_decl_cells(); } break;
case 30:
# line 133 "parse"
{ non_empty(); } break;
case 32:
# line 136 "parse"
{ get_simple_const(); } break;
case 33:
# line 137 "parse"
{ declare_default_field(); } break;
case 34:
# line 138 "parse"
{ begin_decl_cells(); } break;
case 35:
# line 139 "parse"
{ non_empty(); } break;
case 37:
# line 142 "parse"
{ set_agent(); end_decl_cells(); begin_decl_agent(); } break;
case 38:
# line 143 "parse"
{ end_decl_agent(); } break;
case 39:
# line 144 "parse"
{ end_decl_cells(); } break;
case 43:
# line 152 "parse"
{ set_const_field(); } break;
case 45:
# line 156 "parse"
{ declare_array_field(); } break;
case 46:
# line 157 "parse"
{ push_mark(); swap_top_2(); } break;
case 47:
# line 158 "parse"
{ declare_fields(); } break;
case 48:
# line 161 "parse"
{ make_range(); } break;
case 49:
# line 164 "parse"
{ mk_signed_int(); } break;
case 51:
# line 167 "parse"
{ make_range(); } break;
case 54:
# line 174 "parse"
{ process_literal(yytext); } break;
case 63:
# line 189 "parse"
{ end_lhs(); } break;
case 66:
# line 193 "parse"
{ copy_agent(); } break;
case 68:
# line 196 "parse"
{ assignable_base(); } break;
case 71:
# line 200 "parse"
{ confirm_simple(); } break;
case 73:
# line 203 "parse"
{ confirm_array(true); } break;
case 75:
# line 205 "parse"
{ confirm_array(false); } break;
case 76:
# line 207 "parse"
{ do_array_index(); } break;
case 78:
# line 210 "parse"
{ declare_array_variable(); } break;
case 80:
# line 214 "parse"
{ get_simple_const_or_index(); } break;
case 82:
# line 216 "parse"
{ mk_signed_int(); convert_to_uvector(); } break;
case 84:
# line 217 "parse"
{ convert_to_uvector(); } break;
case 86:
# line 220 "parse"
{ start_array_index(); } break;
case 87:
# line 220 "parse"
{ end_array_index(); } break;
case 90:
# line 227 "parse"
{ process_literal("0"); convert_to_uvector(); } break;
case 91:
# line 228 "parse"
{ do_mod_index(); } break;
case 94:
# line 235 "parse"
{ push("+"); } break;
case 95:
# line 235 "parse"
{ binary_op(); } break;
case 96:
# line 236 "parse"
{ push("-"); } break;
case 97:
# line 236 "parse"
{ binary_op(); } break;
case 98:
# line 239 "parse"
{ convert_to_uvector(); } break;
case 99:
# line 240 "parse"
{ get_simple_const_or_index(); } break;
case 100:
# line 246 "parse"
{ jump_if(); do_assign(); } break;
case 102:
# line 247 "parse"
{ do_assign(); end_assign(); } break;
case 103:
# line 250 "parse"
{ jump_elsif(); do_assign(); } break;
case 105:
# line 252 "parse"
{ start_else(); do_assign(); end_if(); end_assign(); } break;
case 107:
# line 256 "parse"
{ end_if(); end_assign(); } break;
case 108:
# line 259 "parse"
{ push_mark(); } break;
case 112:
# line 266 "parse"
{ jump_if(); } break;
case 113:
# line 267 "parse"
{ end_if(); } break;
case 117:
# line 274 "parse"
{ jump_elsif(); } break;
case 119:
# line 277 "parse"
{ start_else(); } break;
case 122:
# line 281 "parse"
{ end_forall(); } break;
case 125:
# line 288 "parse"
{ begin_forall(); implicit_bounds(); } break;
case 126:
# line 291 "parse"
{ begin_forall(); } break;
case 127:
# line 291 "parse"
{ set_index_bounds(); } break;
case 128:
# line 292 "parse"
{ begin_forall_agent(); } break;
case 129:
# line 295 "parse"
{ exit_forall(); } break;
case 130:
# line 299 "parse"
{ create_agent(); } break;
case 133:
# line 305 "parse"
{ jump_if(); put_agent(); } break;
case 135:
# line 306 "parse"
{ put_agent(); } break;
case 136:
# line 307 "parse"
{ put_agent(); } break;
case 138:
# line 311 "parse"
{ start_else(); free_agent(); end_if(); } break;
case 139:
# line 314 "parse"
{ jump_elsif(); put_agent(); } break;
case 141:
# line 315 "parse"
{ start_else(); put_agent(); end_if(); } break;
case 142:
# line 318 "parse"
{ get_cell_variable(); } break;
case 143:
# line 319 "parse"
{ trace_relative_index(); } break;
case 144:
# line 319 "parse"
{ now2next(); } break;
case 147:
# line 329 "parse"
{ binary_op(); } break;
case 151:
# line 335 "parse"
{ binary_op(); } break;
case 154:
# line 341 "parse"
{ binary_op(); } break;
case 158:
# line 347 "parse"
{ binary_op(); } break;
case 162:
# line 352 "parse"
{ unary_op(); } break;
case 164:
# line 356 "parse"
{ unary_op(); } break;
case 165:
# line 359 "parse"
{ get_const_or_variable(); } break;
case 167:
# line 360 "parse"
{ convert_to_uvector(); } break;
case 170:
# line 365 "parse"
{ push_mark(); } break;
case 171:
# line 367 "parse"
{ cell_reference(); } break;
case 174:
# line 374 "parse"
{ do_array_index(); } break;
case 181:
# line 389 "parse"
{ push_array_attr(); } break;
case 183:
# line 390 "parse"
{ field_reference(); } break;
case 184:
# line 393 "parse"
{ field_array_index(); } break;
case 185:
# line 394 "parse"
{ field_array_reference(); } break;
case 186:
# line 397 "parse"
{ push(yytext); } break;
case 187:
# line 400 "parse"
{ push("&&"); } break;
case 188:
# line 401 "parse"
{ push("||"); } break;
case 189:
# line 403 "parse"
{ push("!"); } break;
case 190:
# line 405 "parse"
{ push("=="); } break;
case 191:
# line 406 "parse"
{ push("!="); } break;
case 192:
# line 407 "parse"
{ push("<"); } break;
case 193:
# line 408 "parse"
{ push(">"); } break;
case 194:
# line 409 "parse"
{ push("<="); } break;
case 195:
# line 410 "parse"
{ push(">="); } break;
case 196:
# line 412 "parse"
{ push("+"); } break;
case 197:
# line 413 "parse"
{ push("-"); } break;
case 199:
# line 417 "parse"
{ push("*"); } break;
case 200:
# line 418 "parse"
{ push("/"); } break;
case 201:
# line 419 "parse"
{ push("%"); } break;
# line	531 "/usr/ccs/bin/yaccpar"
	}
	goto yystack;		/* reset registers in driver code */
}

