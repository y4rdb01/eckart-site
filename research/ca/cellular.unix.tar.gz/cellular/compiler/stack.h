/* stack.h
   Copyright (C) 1992, 1993, 1997  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* The following define the different stack_entry kinds. */

#define StackMark		1
#define StackExpr      		2
#define StackToken		3
#define StackError	        4
#define StackRange	        5
#define StackArrayAlias	        6
#define StackIndexVar	        7

typedef struct attr_rec_list_fubar {
	attr_rec *attribute;
	struct attr_rec_list_fubar *next;
} attr_rec_list;

typedef struct {
	char *addr;	 	/* Reference name of the expression. */
	char *field; 		/* Field name of the expression.  This
				   is used for doing the implicit variable 
				   declarations to keep the field separate 
				   from the variable until its type can be 
				   inferred.
				*/
	boolean assignable; 	/* True iff assignable. */
	boolean constant; 	/* True iff the expression is a constant. */
	boolean pre_declared; 	/* True iff identifier was previous declared. */
	boolean unstructured;	/* True iff expr_entry is NOT structured. */
	boolean agent;		/* True iff expr_entry is an agent value. */
	boolean array;		/* True iff the expr_entry is an array alias. */
	boolean free_array;	/* Only used when the expr_entry is an array.
				   True iff the array is unindexed.
				*/
	boolean free_field;	/* Only used when the expr_entry is an array 
				   and a field was referenced.  True iff the
				   field was an unindexed array.
				*/
	boolean index;		/* True iff the expr_entry is an array index. */
	int lower;		/* Lower bound for array/index variable range. */
	int size;		/* Number of elements in the array or range. */

	attr_rec *attribute;    /* Pointer to the attribute of an index 
				   variable, if the expression involves one.
				*/
	attr_rec_list *attr_list; /* Pointers to the attribute records of the
				     array alias and its constituents.  Used
				     to properly set their "structure" values
				     after they have been declared. 
				  */

	/* The following fields are included soley to implement the trace
	   option feature.
	*/
	char *var_tname, *var_index_tname, *field_tname, *field_index_tname;

	/* The following field is used only by microvectors to allow
	   cell_reference to distinguish between scalar and vector values.
	*/
	boolean vector;

} expr_entry;

typedef struct {
	union {
		long int lower_bound;
		float float_lower_bound;
	} lb;
	union {
		long int upper_bound;
		float float_upper_bound;
	} ub;
} range_entry;

typedef struct {
	boolean agent;		/* True iff the index is "agent". */
	char *name;		/* Name of an index variable. */
	attr_rec *attribute;	/* Attribute record of an index variable. */
} index_var_entry;

typedef struct {
	int kind;
	union {
		expr_entry		expr;
		char			*token;
		range_entry		range;
		index_var_entry		index;
	} data;
} stack_entry;
