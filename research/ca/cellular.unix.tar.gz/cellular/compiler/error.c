/* error.c
   Copyright (C) 1992  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <malloc.h>
#include "error.h"

/************************************************************************/

/* SUPPORT ROUTINE
      ACTION - Malloc's the desired amount of space, issuing an
	       error message if the space is not forthcoming.
*/
char* mymalloc(unsigned int size) {
	char *pointer = (char*) malloc((unsigned long int) size);
	if (!pointer) error("Out of memory", (char*) NULL);
	return pointer;
}

/************************************************************************/

/* SUPPORT ROUTINE
      ACTION - Free's the desired previously malloc'ed space.  No space
	       is freed if the supplied pointed is NULL.
*/
void myfree(void *pointer) {
	if (pointer) free(pointer);
}
