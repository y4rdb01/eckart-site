/***********************************************
   Byte-arithmetic Game of Life.
***********************************************/

#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>

#define DEAD 0
#define ALIVE 1
#define OUT_FILE "lifeb.out"

static Initialize(int, FILE *);
static WrapMap(int);
static WriteMap (int, int, FILE *);

char    *map;                           /* Current Generation             */
char    *newmap;                        /* Next Generation                */
char    *t;

main (argc, argv)
int argc;
char *argv[];
{
	FILE            *fp;    /* pointer to initialization data file */
	FILE            *out;   /* pointer to output data file         */
	int             dimension, generations, i;
	long            tstart, tend;
	int             row, col, count;

/** Check Usage  **/

	if (argc != 4)
	{
		fprintf(stderr,"Usage: blife <initfile> <size> <gens>\n");
		exit(1);
	}

/** Open Initialization file  **/

	dimension = atoi(argv[2]);
	generations = atoi(argv[3]);
	if ( (fp = fopen(argv[1], "r") ) == NULL)
	{
	    fprintf(stderr, "Error:  Cannot open intialization file...\n");
	    exit(1);
	}

/** Initialization of the grid **/

	fprintf(stdout, "blife: Initializing...\n");
	Initialize (dimension, fp);
	fclose(fp);

/** Set the timer  **/

    tstart = time(0);

/** Loop for all generations  **/

    fprintf(stdout, "blife: Computing...\n");
    for (i = 0; i < generations; i++)
    {
	WrapMap(dimension);

/** Computation **/

	for (row = 1; row < dimension+1; row++)
	{
	   for (col = 1; col < dimension+1; col++)
	    {
		count = *(map+((dimension+2) * (row-1) + col-1)) + 
			*(map+((dimension+2) * (row+1) + col+1)) + 
			*(map+((dimension+2) * (row+1) + col-1)) + 
			*(map+((dimension+2) * (row-1) + col+1)) + 
			*(map+((dimension+2) * (row  ) + col+1)) + 
			*(map+((dimension+2) * (row  ) + col-1)) + 
			*(map+((dimension+2) * (row-1) + col  )) + 
			*(map+((dimension+2) * (row+1) + col  ));

		switch(count)
		{
		    case 2:
			*(newmap+((dimension+2)*row+col)) = 
				*(map+((dimension+2)*row+col));
			break;

		    case 3:
			*(newmap+((dimension+2)*row+col)) = ALIVE;
			break;

		    case 0:
		    case 1:
		    case 4:
		    case 5:
		    case 6:
		    case 7:
		    case 8:
			*(newmap+((dimension+2)*row+col)) = DEAD;
			break;
		}
	     }
	   }

	   t = map;
	   map = newmap;
	   newmap = t;
   } 

/** Stop the timers  **/

  tend = time(0);
  fprintf(stdout, "blife: Time = %d seconds\n", tend-tstart);

/** Writes the final map to a file **/

   fprintf(stdout, "blife: Writing map to %s...\n", OUT_FILE);
   WriteMap (generations, dimension, 0);
   exit(0);
}

/** Initializes the map   **/

static Initialize(dimension, fp)
int dimension;
FILE *fp;
{
	int     row, col, state, gen;
	char    dummy;

/** Allocates memory for both grids plus the boundaries  **/

     map = (char *)malloc((dimension+2)*(dimension+2));
     newmap = (char *)malloc((dimension+2)*(dimension+2));

     if (!map || !newmap) 
     {
	fprintf(stderr, "Allocation error...\n");
	exit(1);
     }

/**  Sets everything to DEAD  **/

	for (row = 0; row < dimension+2; row++)
	    for (col = 0; col < dimension+2; col++)
		*(map+((dimension+2)*row+col)) = DEAD;

/** Loads the map from the init file  **/

       fscanf(fp, "%d%c", &gen, &dummy);
       while (fscanf(fp, "%c%d%c%d%c%c%c%c%d%c", &dummy, &row, &dummy, &col,
		&dummy, &dummy, &dummy, &dummy, &state, &dummy) != EOF)

	{
	    if ((row > dimension-1) || (col > dimension-1))
		fprintf(stderr, "Value out of range...\n");
            else if (state == ALIVE)
		    *(map+((dimension+2)*(row+1)+(col+1))) = ALIVE;
	    else
		    *(map+((dimension+2)*(row+1)+(col+1))) = DEAD;
	}
}

/** Wraps the overlap in the map for toroidal effect  **/

static WrapMap(dimension)
int dimension;
{
    int row,col;

/** wrap columns **/

    for (row = 1; row < dimension+1; row++)
	 *(map+((dimension+2)*row+0)) = 
			*(map+((dimension+2)*row+dimension));

    for (row = 1; row < dimension+1; row++)
	 *(map+((dimension+2)*row+(dimension+1))) = 
			*(map+((dimension+2)*row+1));

/** wrap rows **/

    for (col = 1; col < dimension+1; col++)
	 *(map+((dimension+2)*0+col)) = 
			*(map+((dimension+2)*dimension+col));

    for (col = 1; col < dimension+1; col++)
	 *(map+((dimension+2)*(dimension+1)+col)) = 
			*(map+((dimension+2)*1+col));

/** diagonals  **/

    *(map+((dimension+2)*0+0)) = 
				*(map+((dimension+2)*dimension+dimension));
    *(map+((dimension+2)*0+(dimension+1))) = 
				*(map+((dimension+2)*dimension+1));
    *(map+((dimension+2)*(dimension+1)+0)) = 
				*(map+((dimension+2)*1+dimension));
    *(map+((dimension+2)*(dimension+1)+(dimension+1))) = 
				*(map+((dimension+2)*1+1));
}

/** Writes the result **/

static WriteMap (generations, dimension, out)
int generations;
int dimension;
FILE *out;
{
	int     row, col;

/** Opens the file to write the output  **/

	if (!out)
	if ((out = fopen(OUT_FILE, "w")) == NULL)
	{
		fprintf(stderr, "Cannot open output file...\n");
		exit(1);
	}

/** Writes the grid to the file  **/

	fprintf(out, "%d\n", generations);

	for (row=1;row<dimension+1;row++)
	{
	   for (col=1;col<dimension+1;col++)
	   {
		if (*(map+((dimension+2)*row+col)) != DEAD)
			fprintf(out, "[%d, %d] = 1\n", row-1, col-1);
	   }
	}
}
