/*********************************************
   Microvectorized Game of Life.
**********************************************/

#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
#include "uvector.h"

#define WIDTH           4
#define BORDER          1

#define DEAD 0
#define ALIVE 1
#define OUT_FILE "life4.out"

int row_len;	/** The number of microvectors per row **/

static Initialize(int, FILE*);
static WriteMap (int, int, FILE*);

uvec    **map;                  /* Current Generation             */
uvec    **newmap;               /* Next Generation                */
uvec    **t;

main (argc, argv)
int argc;
char *argv[];
{
	FILE            *fp;    /* pointer to initialization data file */
	FILE            *out;   /* pointer to output data file         */
	int             dimension, generations, i, ii, j, g;
	long            tstart, tend;
	int             row;

/** Check Usage  **/

	if (argc != 4)
	{
		fprintf(stderr,"Usage: uvlife <initfile> <size> <gens>\n");
		exit(1);
	}

/** Open Initialization file  **/

	dimension = atoi(argv[2]);
	row_len = (dimension/((sizeof(uvec)*8)/WIDTH)) + (2*BORDER);
	generations = atoi(argv[3]);
	if ( (fp = fopen(argv[1], "r") ) == NULL)
	{
	    fprintf(stderr, "Error:  Cannot open intialization file...\n");
	    exit(1);
	}

        fprintf(stderr, "UV_SIZE: %d\n", UV_SIZE);
	fprintf(stderr, "uvlife: Initializing...\n");
	Initialize (dimension, fp);
	fclose(fp);

/** Set the timers  **/

    tstart = time(0);

/** Loop for all generations  **/

    fprintf(stderr, "uvlife: Computing...\n");
    for (g = 0; g < generations; g++)
    {

	/** Swap the overlap **/

	bcopy(map[dimension],   map[0], row_len * sizeof(uvec));
	bcopy(map[1], map[dimension+1], row_len * sizeof(uvec));

	for (i = 0; i < dimension+2; i++)
		UVA_BWRAP(map[i], row_len, WIDTH, BORDER);

	{ register int row;
	for (row = 1; row < dimension+1; row++)
	{
	  register int i;
	  for (i = 1; i <= row_len; i++)
	  {
	    uvec count = 0, mask2 = uv_ones[WIDTH]*2, mask3 = uv_ones[WIDTH]*3;

	    count = UV_PLUS(map[row][i-1], map[row][i+1], 4);
	    count = UV_PLUS(count, map[row-1][i-1], 4);
	    count = UV_PLUS(count, map[row+1][i-1], 4);
	    count = UV_PLUS(count, map[row-1][i], 4);
	    count = UV_PLUS(count, map[row+1][i], 4);
	    count = UV_PLUS(count, map[row-1][i+1], 4);
	    count = UV_PLUS(count, map[row+1][i+1], 4);

            newmap[row][i] = UV_IF(UV_EQUAL(count, UV_S2VEC(2, 4), 4), 
	 	map[row][i], UV_IF(UV_EQUAL(count, UV_S2VEC(3, 4), 4), 
		UV_S2VEC(1, 4), 0, 4), 4);

	}
      }
      }

    /** Swith the map and newmap for next generation **/

      t = map;
      map = newmap;
      newmap = t;

   } /** Compute generations  **/

/** Stop the timer  **/

  tend = time(0);
  fprintf(stderr, "uvlife: Time = %d seconds\n", tend-tstart); 

/** Writes the final map to a file **/

   fprintf(stderr, "uvlife: Writing map to %s...\n", OUT_FILE);
   WriteMap (generations, dimension, 0);

   exit(0);
}

/** Initializes the map   **/

static Initialize(dimension, fp)
int dimension;
FILE *fp;
{
	int     row, col, state, gen;
	char    dummy;

/** Allocates memory for both grids plus the boundaries  **/

	map    = (uvec **)calloc(dimension+2, sizeof(uvec *));
	newmap = (uvec **)calloc(dimension+2, sizeof(uvec *));
	
	if (!map || !newmap) 
	{
	  fprintf(stderr, "Allocation error...\n");
	  exit(1);
	}

	for (row = 0; row <= dimension + 1; row++)
	{
	  map[row]      = (uvec *)calloc(row_len, sizeof(uvec));
	  newmap[row]   = (uvec *)calloc(row_len, sizeof(uvec));

	  if (!map[row] || !newmap[row]) 
	  {
	    fprintf(stderr, "Allocation error...\n");
	    exit(1);
	  }

	}

/** Loads the map from the init file  **/

       fscanf(fp, "%d%c", &gen, &dummy);
       while (fscanf(fp, "%c%d%c%d%c%c%c%c%d%c", &dummy, &row, &dummy, &col,
		&dummy, &dummy, &dummy, &dummy, &state, &dummy) != EOF)
       {
		UVB_BSET(map[row+1], row_len, WIDTH, col+1, state, BORDER);
       }
}

/** Writes the result  **/

static WriteMap (generations, dimension, out)
int generations;
int dimension;
FILE *out;
{
	int     row, col;

/** Opens the file to write the output  **/

	if (!out)
	if ((out = fopen(OUT_FILE, "w")) == NULL)
	{
		fprintf(stderr, "Cannot open output file...\n");
		exit(1);
	}

/** Writes the grid to the file  **/

	fprintf(out, "%d\n", generations);
	for (row=1; row < dimension+1; row++)
	   for (col=1; col < dimension+1; col++)
	   {
		if (UVB_BGET(map[row], row_len, WIDTH, col, BORDER) == ALIVE) 
			fprintf(out, "[%d, %d] = 1\n", row-1, col-1);
	   }
}
