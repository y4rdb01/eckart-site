/****************************************************
      The MicroVector Library.   

  (c) 1994 Micah Beck and Antonio Castellanos.
      May not be redistributed in any modified form.
/*****************************************************/

typedef unsigned long int uvec;	        /** Microvector type **/

/** Constants **/

#include "uv_const.h"

/** Global Definitions **/

#define UV_SIZE 		(sizeof(uvec) * 8)
#define UV_LENGTH(W) 		(UV_SIZE/(W))

extern uvec uv_ones[];	/** Table of masks **/

#ifdef UV_INLINE

/** Macro versions of ALMOST ALL library functions **/

/* Field value manipulaation functions */
#define UV_FMASK(W)		((uvec)-1 >> (UV_SIZE - (W)))
#define UV_FVAL(V, W)		((uvec)(V) & UV_FMASK(W))

#define UV_FGET(V, W, I)   	UV_FVAL((V) >> (W)*(I), W)
#define UV_FSET(V, W, I, A)    (((A) << (I*W)) | (V & (~(UV_FMASK(W) << (I*W)))))

#define UVO_FMASK(W)		UV_FMASK((W)-1)
#define UVO_FVAL(V, W)		UV_FVAL(V, (W)-1)
#define UVO_FSIGN(V, W)		(((uvec)(V) >> ((W)-2)) & 1)
#define UVO_FSEXT(V, W)	    ((int)(V | ((~UV_FMASK((W)-1)) * UVO_FSIGN(V, W))))

#define UVO_FGET(V, W, I)	UV_FGET(V, W, I)
#define UVO_FSET(V, W, I, A)  	UV_FSET(V, W, I, A)

#define UV_EVENS(V, W)		((V) & (uv_ones[2*(W)] * UV_FMASK(W)))
#define UV_ODDS(V, W)		UV_EVENS((V) >> (W), W)

/** Simple Microvector Operations **/

#define UV_AND(U, V, W)		((U) & (V))
#define UV_OR(U, V, W)		((U) | (V))
#define UV_XOR(U, V, W)		((U) ^ (V))
#define UV_COMPL(V, W) 		(~(V))
#define UV_NOT(V, W)		((V) ^ UV_ONES##W)

#define UV_PLUS(U, V, W)  	((U) + (V))
#define UV_MINUS(U, V, W)  	((U) - (V))
#define UV_LSHIFT(V, W)		(((V) << 1) & (~UV_ONES##W))
#define UV_RSHIFT(V, W)		(((V) & (~UV_ONES##W)) >> 1)
#define UV_RSHIFTA(V, W)	((((V) & (~UV_ONES##W)) >> 1) \
					| ((V) & (UV_ONES##W << ((W)-1))))

#define UV_SMUL(S, V, W)	((V) * (S))
#define UV_S2VEC(S, W)		(S * UV_ONES##W)

#define UV_SIGN(V, W)		(((uvec)(V) >> ((W)-1)) & UV_ONES##W)
#define UV_EQUAL(U, V, W) 	(UV_SHAND##W(~((U)^(V))) & UV_ONES##W)

/** Overflow Microvector Operations **/

#define UVO_VAL(V, W)		((V) & (UV_ONES##W * UVO_FMASK(W)))

#define UVO_AND(U, V, W)	UV_AND(U, V, W)
#define UVO_OR(U, V, W)		UV_OR(U, V, W)
#define UVO_XOR(U, V, W)	UV_XOR(U, V, W)
#define UVO_COMPL(V, W)		UVO_VAL(~(V), W)
#define UVO_NOT(V, W)		UV_NOT(V, W)

#define UVO_PLUS(U, V, W)	UVO_VAL(UV_PLUS(U, V, W), W)
/*
#define UVO_NEG(V, W)		UVO_VAL((~(V)) + UV_ONES##W, W)

     Due to a bug found by me, J Dana Eckart, Micah Beck sent the
     following change.
*/
#define UVO_NEG(V, W)           UVO_VAL(UVO_VAL(~(V), W) + UV_ONES##W, W)
#define UVO_MINUS(U, V, W)	UVO_PLUS(U, UVO_NEG(V, W), W)
#define UVO_LSHIFT(V, W) 	UVO_VAL((V) << 1, W)
#define UVO_RSHIFT(V, W)	UV_RSHIFT(V, W)
#define UVO_RSHIFTA(V, W)	((((V) & (~UV_ONES##W)) >> 1) \
				    | ((V) & (UV_ONES##W << ((W)-2))))

#define UVO_S2VEC(S, W)		UV_S2VEC(S, W)
#define UVO_SMUL(S, V, W)	\
	(UVO_VAL(UV_SMUL(S, UV_EVENS(V, W), 2*W), W) \
		| (UVO_VAL(UV_SMUL(S, UV_ODDS(V, W), 2*W), W) << (W)))
#define UVO_XSMUL(S, V, W, F)  	\
	(UVO_VAL(UV_SMUL(S, UV_EVENS(V, W), 2*W) >> (F), W) \
		| (UVO_VAL(UV_SMUL(S, UV_ODDS(V, W), 2*W) >> (F), W) << (W)))

#define UVO_SIGN(V, W)		(((uvec)(V) >> ((W)-2)) & UV_ONES##W)
#define UVO_EQUAL(U, V, W)	UV_EQUAL(U, V, W)
#define UVO_GT(U, V, W)		UVO_SIGN(UVO_MINUS(V, U, W), W)
#define UVO_LT(U, V, W)		UVO_SIGN(UVO_MINUS(U, V, W), W)

/** Conditionals **/
#define UV_COND(B, V, W)	((B * UV_FMASK(W)) & V)
#define UV_IF(B, T, F, W)    (UV_COND(B, T, W) | UV_COND(UV_NOT(B, W), F, W))

/** Stored Microvectors **/
#define UVP_SET(VP, W, I, V)		(*(VP) = UV_FSET(*(VP), W, I, V))
#define UVA_SET2(VP, W, I, J, V)   	((VP)[I] = UV_FSET((VP)[I], W, J, V))

/** Block Distribution **/

#define UVB_BGET(VP, L, W, I, B) \
	UV_FGET((VP)[(((I)-(B)) % ((L) - 2*(B))) + (B)], \
	       (W), ((I)-(B)) / ((L) - 2*(B)))

#define UVA_BGET(VP, L, W, I) 		UVB_BGET(VP, L, W, I, 0)
		
#define UVB_BSET(VP, L, W, I, V, B) \
     UVA_SET2(VP, W, (((I)-(B)) % (L - 2*B)) + B, ((I-B) / (L - 2*B)), V)

#define UVA_BSET(VP, L, W, I, V) 	UVB_BSET(VP, L, W, I, V, 0)

/** Scattered Distribution **/

#define UVA_SGET(VP, W, I) \
		UV_FGET((VP)[I / UV_LENGTH(W)], W, I % UV_LENGTH(W))

#define UVA_SSET(VP, W, I, V) \
		UVA_SET2(VP, W, I / UV_LENGTH(W), I % UV_LENGTH(W), V)

#else INLINE		/** Redefine here the name of all library functions **/

#define UV_FMASK	uv_fmask
#define UV_FVAL		uv_fval

#define UV_FGET		uv_fget
#define UV_FSET		uv_fset

#define UVO_FMASK	uvo_fmask
#define UVO_FVAL	uvo_fval
#define UVO_FSIGN	uvo_fsign
#define UVO_FSEXT	uvo_fsext

#define UVO_FGET	uvo_fget
#define UVO_FSET	uvo_fset

#define UV_AND		uv_and
#define UV_OR		uv_or
#define UV_XOR		uv_xor
#define UV_COMPL	uv_compl
#define UV_NOT		uv_not

#define UV_PLUS		uv_plus
#define UV_MINUS	uv_minus
#define UV_LSHIFT	uv_lshift
#define UV_RSHIFT	uv_rshift
#define UV_RSHIFTA	uv_rshifta

#define UV_S2VEC	uv_s2vec
#define UV_SMUL		uv_smul

#define UV_SIGN		uv_sign
#define UV_EQUAL	uv_equal

#define UVO_VAL		uvo_val

#define UVO_AND		uvo_and
#define UVO_OR		uvo_or
#define UVO_XOR		uvo_xor
#define	UVO_COMPL	uvo_compl
#define UVO_NOT		uvo_not

#define UVO_PLUS	uvo_plus
#define UVO_NEG		uvo_neg
#define UVO_MINUS	uvo_minus
#define UVO_LSHIFT	uvo_lshift
#define UVO_RSHIFT	uvo_rshift
#define UVO_RSHIFTA	uvo_rshifta

#define UVO_S2VEC	uvo_s2vec
#define UVO_SMUL	uvo_smul
#define UVO_XSMUL	uvo_xsmul

#define UVO_SIGN	uvo_sign
#define UVO_EQUAL	uvo_equal
#define UVO_GT		uvo_gt
#define UVO_LT		uvo_lt

#define UV_COND		uv_cond
#define UV_IF		uv_if

#define UVP_SET		uvp_set
#define UVA_SET2	uva_set2

#define UVB_BGET	uvb_bget
#define UVA_BGET	uva_bget
#define UVB_BSET	uvb_bset
#define UVA_BSET	uva_bset

#define UVA_SGET	uva_sget
#define UVA_SSET	uva_sset

#endif INLINE

/** Some operations always use functions or macros**/

#define UV_MUL			uv_mul
#define UV_XMUL			uv_xmul
#define UVO_MUL			uvo_mul
#define UVO_XMUL		uvo_xmul
#define UVO_DIV			uvo_div
#define UVO_SDIV		uvo_sdiv
#define UVO_XDIV		uvo_xdiv
#define UVO_XSDIV		uvo_xdiv

#define UV_SET(V, W, I, A)	(V = UV_FSET(V, W, I, A))
#define UVO_SET(V, W, I, A)	(V = UVO_FSET(V, W, I, A))
#define UVA_BWRAP		uva_bwrap
#define UVA_SWRAP		uva_swrap

#define UV_I2X(I, F)		((I) << (F))
#define UV_F2X(FP, F)		((int)((double)(FP) * (1 << (F))))
#define UV_X2I(X, F)		(X >> (F))
#define UV_X2F(X, F)		(((double)X) / (1 << (F)))

/** Microvector conversion support **/

#define UV_CONVM(V, W, M, I) 		(((V) >> ((W)*(I))) & M)

/** Library functions **/

extern uvec uv_fmask	(int);
extern uvec uv_fval	(uvec, int);

extern uvec uv_fget	(uvec, int, int);
extern uvec uv_fset	(uvec, int, int, uvec);

extern uvec uvo_fmask	(int);
extern uvec uvo_fval	(uvec, int);
extern uvec uvo_fsign	(uvec, int);
extern uvec uvo_fsext	(uvec, int);	

extern int  uvo_fget	(uvec, int, int);
extern uvec uvo_fset	(uvec, int, int, uvec);

extern uvec uv_and	(uvec, uvec, int);
extern uvec uv_or	(uvec, uvec, int);
extern uvec uv_xor	(uvec, uvec, int);
extern uvec uv_compl	(uvec, int);
extern uvec uv_not	(uvec, int);

extern uvec uv_plus	(uvec, uvec, int);
extern uvec uv_minus	(uvec, uvec, int);
extern uvec uv_lshift	(uvec, int);
extern uvec uv_rshift	(uvec, int);
extern uvec uv_rshifta	(uvec, int);

extern uvec uv_s2vec	(uvec, int);
extern uvec uv_smul	(uvec, uvec, int);

extern uvec uv_sign	(uvec, int);
extern uvec uv_equal	(uvec, uvec, int);
extern uvec uv_mul	(uvec, uvec, int);
extern uvec uv_xmul	(uvec, uvec, int, int);

extern uvec uvo_val	(uvec, int);

extern uvec uvo_and	(uvec, uvec, int);
extern uvec uvo_or	(uvec, uvec, int);
extern uvec uvo_xor	(uvec, uvec, int);
extern uvec uvo_compl	(uvec, int);
extern uvec uvo_not	(uvec, int);

extern uvec uvo_plus	(uvec, uvec, int);
extern uvec uvo_neg	(uvec, int);
extern uvec uvo_minus	(uvec, uvec, int);
extern uvec uvo_lshift	(uvec, int);
extern uvec uvo_rshift	(uvec, int);
extern uvec uvo_rshifta	(uvec, int);

extern uvec uvo_s2vec	(uvec, int);
extern uvec uvo_smul	(uvec, uvec, int);

extern uvec uvo_sign	(uvec, int);
extern uvec uvo_equal	(uvec, uvec, int);
extern uvec uvo_gt	(uvec, uvec, int);
extern uvec uvo_le	(uvec, uvec, int);

extern uvec uvo_mul	(uvec, uvec, int);
extern uvec uvo_xmul	(uvec, uvec, int, int);
extern uvec uvo_xsmul	(uvec, uvec, int, int);
extern uvec uvo_div	(uvec, uvec, int);
extern uvec uvo_sdiv	(uvec, int, int);
extern uvec uvo_xdiv	(uvec, uvec, int, int);
extern uvec uvo_xsdiv	(uvec, int, int, int);

extern uvec uv_cond	(uvec, uvec, int);
extern uvec uv_if	(uvec, uvec, uvec, int);

extern void uvp_set	(uvec *, int, int, uvec);
extern void uva_set2	(uvec *, int, int, int, uvec);

extern uvec uvb_bget	(uvec *, int, int, int, int);
extern uvec uva_bget	(uvec *, int, int, int);
extern void uvb_bset	(uvec *, int, int, int, uvec, int);
extern void uva_bset	(uvec *, int, int, int, uvec);
extern void uva_bwrap	(uvec *, int, int, int);

extern uvec uva_sget	(uvec *, int, int);
extern void uva_sset	(uvec *, int, int, uvec);
extern void uva_swrap	(uvec *, int, int, int);



