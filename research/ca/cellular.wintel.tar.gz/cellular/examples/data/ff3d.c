/* ff3d.c
   Copyright (C) 1998  J Dana Eckart

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* Generate the input data used by ff3d, a 3D firefly simulation.  A single
   command line argument indicates the size of each of three dimensions of
   the cell universe.
*/

#include <stdio.h>
#include <stdlib.h>
#include "my_rand.h"

/* The percentage of cell sites that should hold a firefly. */
#define DENSITY	10

/* The mean flash period/threshold and +- variance. */
#define PERIOD	56
#define P_VAR	2

/* The mean flash delay and +- variance. */
#define DELAY	18
#define D_VAR	1

int main(int argc, char *argv[]) {
	int max_size, x, y, z;

	/* Check usage. */
	if (argc == 1) {
                fprintf(stderr, "%s: size of automaton must be given.\n",
                        argv[0]);
                return 1;
        } else if (argc > 2)
		fprintf(stderr, "%s: extra options ignored.\n", argv[0]);

	max_size = atoi(argv[1]);

	printf("0\n");

	for (x = 0; x < max_size; x++)
	for (y = 0; y < max_size; y++)
	for (z = 0; z < max_size; z++) {
		int firefly = my_random()%100;

		if (firefly < DENSITY) {
			int direction = my_random()%4;
			int period = PERIOD - P_VAR
					+ 2*(my_random()%(1+P_VAR));
			int delay = DELAY - D_VAR
					+ 2*(my_random()%(1+D_VAR));
			int state = my_random()%period;

			printf("[%d, %d, %d] = %d, %d, %d, %d, %d, %d\n",
				x, y, z, 2 /* flash */, period, state, 
				delay, -1 /* time2flash */, direction);
		}
	}
	return 0;
}
