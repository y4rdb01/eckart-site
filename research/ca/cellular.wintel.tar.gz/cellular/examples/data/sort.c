/* sort.c
   Copyright (C) 1992, 1994  J Dana Eckart

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* Generate the input data used by sort.  A single command line argument
   indicates the size of the single dimension of the cell universe.
*/

#include <stdio.h>
#include <stdlib.h>
#include "my_rand.h"

#define MAX_COLORS	256

int main(int argc, char *argv[]) {
	int max_size, x, y;

	/* Check usage. */
	if (argc == 1) {
                fprintf(stderr, "%s: size of automaton must be given.\n",
                        argv[0]);
                return 1;
        } else if (argc > 2)
		fprintf(stderr, "%s: extra options ignored.\n", argv[0]);

	max_size = atoi(argv[1]);

	printf("0\n");

	printf("[0] = 0, 0\n");

	for (x = 1; x < max_size; x++) {
		/* Write cell location. */
		printf("[%d] = ", x);

		/* Write "which" field value. */
		if (x%2)
			printf("1");
		else
			printf("0");

		/* Write "sort" field value. */
		printf(", %ld\n", my_random()%(MAX_COLORS-1) + 1);
	}

	return 0;
}
