/* attr.h
   Copyright (C) 1992  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "boolean.h"

/* The exported declarations for attributes appearing in the symbol table. */

typedef struct {
	boolean assignable; 	/* True iff assignable. */
	int field_name;		/* If and what kind of field (cell or agent). */
	boolean structured;	/* True iff the value is structured. */
	boolean agent;		/* True iff the value is an agent. */
	boolean array;		/* True iff the name is an array alias. */
	boolean index;		/* True iff the name is an index variable. */
	int index_count;	/* The count used to generate unique names
				   for the macro names containing the lower 
				   and upper bound or the index variable range.
				*/
	boolean range_set;	/* True iff the range of an index variable
				   has been set.
				*/
	boolean incomp_range;	/* True iff different range values were
				   inferred for the index variable.
				*/
	int lower;		/* Lower bound of the range for an index. */
	int size;		/* Number of elements in the array or index. */
	char *address;		/* The address (string) to use for access. */
	boolean usr_def;	/* Index variable range given by user? */
	boolean cell_ref;	/* Index variable used in a cell reference? */
	boolean is_float;	/* True iff value represents a float. */
} attr_rec;
