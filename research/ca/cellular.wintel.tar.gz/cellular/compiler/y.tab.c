static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "parse"
/* parse
   Copyright (C) 1992, 1993, 1994, 1995, 1997, 1998, 1999  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "semantic.h"
#include "scanner.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The following prevent warnings/errors for some compilers. */
int yyparse(void);
int yyerror(char*);
#line 40 "y.tab.c"
#define AGENT 257
#define AT 258
#define CONST 259
#define DIMENSIONS 260
#define IF 261
#define THEN 262
#define ELSIF 263
#define ELSE 264
#define EXIT 265
#define END 266
#define FOR 267
#define FORALL 268
#define WHEN 269
#define OTHERWISE 270
#define OF 271
#define ASSIGN 272
#define PLUS 273
#define MINUS 274
#define TIMES 275
#define DIVIDE 276
#define MOD 277
#define EQUAL 278
#define LESSER 279
#define GREATER 280
#define LESSEQ 281
#define GREATEQ 282
#define NOTEQ 283
#define AND 284
#define OR 285
#define NOT 286
#define SUCC 287
#define PRED 288
#define LEFTPAREN 289
#define RIGHTPAREN 290
#define LEFTBRACKET 291
#define RIGHTBRACKET 292
#define COMMA 293
#define DOTS 294
#define DOT 295
#define COLON 296
#define IDENTIFIER 297
#define NUMERICLITERAL 298
#define STRINGLITERAL 299
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    4,    0,    0,    1,    1,    5,    5,    6,   12,    7,
   11,   13,   11,   14,   14,    9,    9,    9,   10,   10,
   17,    2,   18,   18,   18,   22,   26,   18,   27,   28,
   18,   29,   21,   30,   31,   21,   32,   25,   25,   24,
   24,   33,   34,   33,   23,   37,   23,   19,   38,   20,
   35,   36,   36,   16,    3,    3,   39,   39,   39,   39,
   39,   39,   47,   40,   46,   51,   46,   53,   45,   52,
   56,   52,   57,   54,   60,   61,   54,   58,   58,   64,
   62,   65,   62,   66,   62,   68,   59,   63,   63,   71,
   69,   72,   72,   74,   70,   75,   70,   73,   73,   77,
   49,   49,   79,   78,   78,   76,   76,   80,   48,   81,
   81,   82,   85,   41,   83,   83,   87,   86,   88,   84,
   84,   42,   89,   90,   90,   92,   91,   91,   43,   93,
   44,   50,   97,   95,   95,   95,   96,   96,   99,   98,
   98,   94,  101,   94,   67,  102,  106,  104,  104,  103,
  108,  108,  107,  113,  111,  111,  110,  117,  115,  115,
  114,  114,  118,  118,  122,  119,  119,  119,  119,  123,
  100,  121,  121,  125,  125,  124,  124,   55,   55,  126,
  129,  127,  127,  128,  128,    8,  105,  105,  120,  109,
  109,  109,  109,  109,  109,  112,  112,   15,  116,  116,
  116,
};
short yylen[] = {                                         2,
    0,    4,    0,    2,    0,    1,    1,    4,    0,    9,
    1,    0,    3,    3,    0,    2,    1,    1,    1,    1,
    0,    5,    2,    2,    2,    0,    0,    8,    0,    0,
    4,    0,    2,    0,    0,    6,    0,    5,    0,    2,
    0,    2,    0,    4,    6,    0,    4,    2,    0,    3,
    3,    3,    0,    1,    2,    0,    1,    1,    1,    1,
    1,    1,    0,    3,    3,    0,    2,    0,    3,    2,
    0,    2,    0,    4,    0,    0,    5,    2,    0,    0,
    3,    0,    4,    0,    3,    0,    2,    1,    0,    0,
    3,    2,    0,    0,    3,    0,    3,    1,    1,    0,
    4,    0,    0,    4,    1,    3,    0,    0,    3,    3,
    0,    0,    0,    9,    2,    0,    0,    5,    0,    3,
    0,    4,    2,    2,    0,    0,    2,    1,    1,    0,
    6,    3,    0,    4,    1,    0,    3,    0,    0,    4,
    1,    1,    0,    2,    1,    2,    0,    4,    0,    2,
    2,    0,    2,    0,    4,    0,    2,    0,    4,    0,
    1,    2,    1,    2,    0,    3,    1,    3,    2,    0,
    5,    2,    1,    3,    0,    3,    0,    1,    0,    3,
    0,    3,    0,    2,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,
};
short yydefred[] = {                                      0,
    0,    0,    0,    0,    6,    7,  186,    0,   54,    1,
   20,   21,   19,    4,    0,    0,    0,    0,  196,  197,
   18,    8,    0,   17,  198,    0,    0,    0,  129,    0,
    2,   58,   68,    0,   57,   59,   60,   61,   62,   63,
    0,   16,    0,  108,  189,    0,  170,  165,    0,  167,
  112,    0,  145,    0,    0,    0,    0,  161,  163,    0,
    0,    0,    0,   55,    0,    0,    0,    0,    0,    0,
    0,    0,  162,    0,    0,  169,  178,  187,  188,  146,
    0,  190,  192,  193,  194,  195,  191,  150,    0,  153,
    0,  199,  200,  201,  157,    0,  164,    0,  123,    0,
    0,   69,    0,  108,   64,    0,   26,    0,    0,    0,
   22,    0,    9,  130,    0,  168,   80,    0,   84,    0,
   86,  173,    0,  166,    0,    0,    0,  147,  151,  154,
  158,  128,  124,    0,  122,   73,   70,   86,   72,    0,
    0,   67,    0,   25,    0,    0,   49,   24,    0,   23,
   37,   30,    0,    0,    0,  109,    0,   82,    0,    0,
    0,    0,    0,   94,   96,    0,  172,    0,  181,  180,
    0,    0,    0,    0,  127,    0,    0,    0,   65,  142,
    0,    0,    0,   33,    0,    0,    0,    0,   48,    0,
    0,   11,   10,    0,  131,    0,   81,   88,    0,   85,
    0,  171,  174,   87,    0,    0,    0,   91,    0,    0,
    0,    0,  148,  155,  159,    0,    0,   76,  100,    0,
  135,  132,  144,    0,    0,   43,    0,    0,    0,    0,
    0,   50,    0,   31,    0,  110,   83,  176,   99,   98,
   95,   97,   92,  117,  119,  113,  115,  185,    0,  182,
   51,    0,   74,    0,    0,  133,    0,    0,    0,   42,
   35,   40,    0,    0,    0,    0,   13,    0,    0,    0,
  184,   78,   77,  108,  101,    0,   27,    0,    0,    0,
   52,   47,   38,    0,    0,  120,  114,    0,    0,  134,
    0,    0,   44,   36,   14,  118,    0,  105,  106,    0,
   28,   45,  103,    0,  141,  137,    0,  139,  104,    0,
  140,
};
short yydgoto[] = {                                       2,
    3,   10,   31,   17,   32,    5,    6,   48,  174,   12,
  193,  153,  194,  267,   49,   50,   18,  111,  150,  148,
  144,  143,  186,  228,  152,  291,  112,  191,  145,  146,
  280,  190,  229,  259,  175,  231,  187,  188,   34,   35,
   36,   37,   38,   39,   40,  105,   65,   68,  179,  142,
  106,  102,   63,  137,   76,  103,  176,  253,  162,  138,
  254,  120,  197,  157,  199,  159,   51,  163,  198,  207,
  123,  208,  241,  205,  206,  275,  255,  299,  307,   69,
  156,   74,  210,  246,  270,  211,  268,  269,   62,   99,
  133,  134,  154,  181,  222,  290,  276,  306,  310,   52,
  182,   53,   54,   80,   81,  171,   55,   88,   89,   56,
   90,   25,  172,   57,   95,   96,  173,   58,   59,   60,
  124,   72,   71,  161,  125,   77,  170,  250,  212,
};
short yysindex[] = {                                   -210,
 -271,    0, -259, -210,    0,    0,    0, -200,    0,    0,
    0,    0,    0,    0, -256, -207, -209, -165,    0,    0,
    0,    0, -259,    0,    0, -169, -178, -181,    0, -271,
    0,    0,    0, -209,    0,    0,    0,    0,    0,    0,
 -149,    0, -259,    0,    0, -181,    0,    0, -123,    0,
    0, -161,    0, -202,  -64, -155,  -88,    0,    0, -120,
 -159, -209, -151,    0, -124, -237, -119, -131, -181, -129,
 -256, -136,    0,  -92, -271,    0,    0,    0,    0,    0,
 -181,    0,    0,    0,    0,    0,    0,    0, -181,    0,
 -181,    0,    0,    0,    0, -181,    0,  -85,    0,  -87,
 -102,    0, -161,    0,    0,  -62,    0,    0, -259,  -93,
    0,  -53,    0,    0,  -83,    0,    0, -259,    0,  -82,
    0,    0, -105,    0, -161, -209,  -86,    0,    0,    0,
    0,    0,    0, -256,    0,    0,    0,    0,    0,  -61,
 -271,    0, -271,    0,  -93,  -79,    0,    0, -256,    0,
    0,    0,  -78,  -62, -181,    0,    0,    0,    0, -256,
  -72,  -69, -181,    0,    0, -105,    0,  -41,    0,    0,
 -202, -155,  -88,  -68,    0, -161,  -67, -181,    0,    0,
  -77,  -63,  -79,    0,  -65, -232,  -58,  -93,    0,  -47,
  -36,    0,    0, -256,    0,  -83,    0,    0,    0,    0,
  -82,    0,    0,    0, -259, -259, -105,    0, -181,  -33,
  -41,  -60,    0,    0,    0, -256,  -31,    0,    0, -181,
    0,    0,    0, -232,  -29,    0,  -79,  -53, -232, -271,
  -30,    0, -232,    0,  -51,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  -52,    0,
    0, -259,    0, -161,  -28,    0,  -53, -259, -271,    0,
    0,    0,  -58, -256, -232, -256,    0,  -17, -209,  -23,
    0,    0,    0,    0,    0,  -12,    0,  -24,  -79,  -18,
    0,    0,    0,  -51, -209,    0,    0,  -75, -271,    0,
  -16, -256,    0,    0,    0,    0, -181,    0,    0,  -70,
    0,    0,    0, -181,    0,    0,  -28,    0,    0,  -12,
    0,
};
short yyrindex[] = {                                      3,
    0,    0,    0, -133,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  251,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    9,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  123,    0,  312,  271,  234,  197,    0,    0,    0,
 -195,  -14, -226,    0,   -4, -223,    0,    0,    0,    0,
    0,   45,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0, -197,    0,    0,
 -177,    0, -191,    0,    0,    0,    0, -158,    0,    0,
    0,   -9,    0,    0,  331,    0,    0,    0,    0,  -22,
    0,    0,    0,    0,  123, -134,   86,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   19,
   -1,    0,    0,    0,    0, -246,    0,    0,    0,    0,
    0,    0, -170,    0,    0,    0, -107,    0, -107,    0,
    0,    0,    0,    0,    0,  160,    0, -233,    0,    0,
  312,  234,  197,    0,    0, -116,    0,    0,    0,    0,
  372,    0, -246,    0,    0, -112,   10,    0,    0,    0,
    0,    0,    0,    0,    0,  331,    0,    0, -107,    0,
  -22,    0,    0,    0,    0,    0,  160,    0,    0,   -7,
 -233, -148,    0,    0,    0,    0, -183,    0,    0,    0,
    0,    0,    0, -112,    0,    0, -246,   -9, -112,    0,
    0,    0,    0,    0,    1,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -191,  390,    0,   -9,    0,    0,    0,
    0,    0,   10,    0,    2,    0,    0,    0,  -14,    0,
    0,    0,    0,    0,    0,  409,    0,    0, -246,    0,
    0,    0,    0,    1, -134,    0,    0,    0,   -1,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  390,    0,    0,  409,
    0,
};
short yygindex[] = {                                      0,
  270,    0,  -32,    0,   74,    0,    0,  661,  -10,  -19,
    0,    0,    0,    4,   13,   -3,    0,    0, -135,    0,
    0,    0, -172, -208, -213,    0,    0,    0,    0,    0,
    0,    0,   58,    0, -241,   29,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  -98,    0,  140,
    0,    0,    0,    0,  -96,    0,    0,    0, -125,    0,
    0,  135, -145,    0,    0,    0,  -11,    0,  224,  174,
    0,  127,  130,    0,    0,   32,    0,    0,    0,    0,
  145,    0,  146,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   57,    0,   63,    0,    0,    0,  192,
    0,    0,  294,  206,    0,    0,  305,    0,    0,  319,
  239,  -48,    0,  316,  241,    0,    0,  378,  371,    0,
    0,    0,    0,  245,    0,    0,    0,    0,    0,
};
#define YYTABLESIZE 953
short yytable[] = {                                      13,
   15,   64,    3,   42,   22,  140,  139,   91,   56,  184,
  224,   24,  177,  200,  261,  257,   19,   20,  102,   13,
  262,  107,  282,   67,   46,    7,  226,   23,  167,  100,
  116,   71,  116,   29,   70,   19,   20,    7,    9,   13,
    7,    9,   29,  277,  175,   71,   46,   27,    1,    1,
  302,   28,  232,  237,  260,   29,  283,  115,   30,    7,
    9,  125,  110,  125,    7,  125,  179,  119,   71,  125,
  125,   15,  125,    4,   79,  126,  126,    4,  109,  217,
  179,   78,   79,  118,   26,  183,  249,    7,   79,  147,
   16,   19,   20,  168,   41,   75,   75,   43,  158,  126,
  126,  125,   12,   12,   45,   13,  293,   46,   75,   47,
   44,   75,   34,   75,   13,    7,    9,   19,   20,   75,
   75,   66,  179,   91,   86,   86,   12,   12,   56,   56,
   24,   56,   34,   75,   34,   32,   98,   86,  189,  101,
   86,  179,   86,  196,   41,   24,   23,  104,   86,   86,
  179,  204,  113,   41,  121,  179,  119,  273,  114,   93,
  116,   23,   45,    5,    5,   46,  219,   47,   46,  126,
   47,  132,  118,    7,    9,  288,    7,    9,  135,   90,
   90,  164,  165,  235,   89,   89,   92,   93,   94,  136,
   24,  220,  221,  297,  298,  141,  160,  244,  304,  305,
  149,  240,  240,  151,  169,  251,   23,  178,  256,  155,
  160,  185,   24,   82,   83,   84,   85,   86,   87,  202,
  192,  209,  203,  233,  218,  216,  225,   47,   23,  234,
  245,  248,  272,  156,  230,  252,  286,  258,  278,  271,
  264,  266,  287,  274,  285,  289,  292,  294,   13,  301,
   56,   56,  296,   66,   13,  284,   39,   15,  121,   15,
   24,   15,   24,   15,   15,   15,   15,   41,   15,  177,
  152,   56,   56,   14,   56,  102,   23,  102,   23,  102,
   53,  102,  102,  102,  102,  303,  102,  295,   24,  143,
  265,  281,  308,  195,  201,  122,  166,   15,   15,    5,
    5,  175,  175,  175,   23,  175,  175,  175,  175,  175,
  175,  149,  175,  175,  175,  102,  175,  175,  175,  175,
  175,  175,  175,  175,  175,  175,  175,  175,  175,  175,
  111,   90,   90,  243,  175,  242,  175,  175,  309,  175,
  236,  175,  183,  183,  183,  300,  183,  183,  183,  183,
  183,  183,  183,  183,  183,  183,  247,  183,  183,  183,
  183,  183,  183,  183,  183,  183,  183,  183,  183,  183,
  183,  136,  311,  223,  128,  183,  213,  183,  183,  179,
  179,  179,  183,  179,  179,  179,  179,  179,  179,  107,
  179,  179,  179,  129,  179,  179,  179,  179,  179,  179,
  179,  179,  179,  179,  179,  179,  179,  179,  138,  130,
  214,  131,  179,  215,  179,  179,   93,   93,   93,  179,
   93,   93,   93,   93,   93,   93,   73,   93,   93,   93,
   97,   93,   93,   93,   93,   93,   93,   93,   93,   93,
   93,   93,   93,   93,   93,  238,    0,    0,    0,   93,
    0,   93,   93,  160,  160,  160,   93,  160,  160,  160,
  160,  160,  160,    0,  160,  160,  160,    0,  160,  160,
  160,    0,    0,    0,  160,  160,  160,  160,  160,  160,
  160,  160,    0,    0,    0,    0,  160,    0,  160,  160,
  156,  156,  156,  160,  156,  156,  156,  156,  156,  156,
    0,  156,  156,  156,    0,  156,    0,    0,    0,    0,
    0,  156,  156,  156,  156,  156,  156,  156,  156,    0,
    0,    0,    0,  156,    0,  156,  156,  152,  152,  152,
  156,  152,  152,  152,  152,  152,  152,    0,  152,  152,
  152,    0,  152,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  152,  152,    0,    0,    0,    0,
  152,    0,  152,  152,    0,    0,    0,  152,  149,  149,
  149,    0,  149,  149,  149,  149,  149,  149,    0,  149,
  149,  149,    0,  149,    0,    0,    0,  111,    0,  111,
    0,  111,    0,  111,  111,  111,  111,    0,  111,  111,
  111,  149,    0,  149,  149,    0,    0,    0,  149,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
  111,    0,    0,    0,    0,    0,    0,  111,  136,    0,
  136,    0,  136,    0,  136,  136,  136,  136,    0,  136,
    0,    0,    0,    0,    0,    0,  107,    0,  107,    0,
  107,    0,  107,  107,  107,  107,    0,  107,    0,    0,
    0,    8,    0,   11,    0,  138,    0,  138,  136,  138,
    0,  138,  138,  138,  138,   21,  138,   33,    0,    0,
    0,    0,    0,   11,    0,    0,  107,    0,    0,    0,
   61,    0,    0,    0,   33,    0,    0,    0,    0,    0,
    0,    0,    0,   11,    0,  138,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   33,    0,    0,    0,  108,    0,    0,    0,
    0,  117,    0,    0,    0,  127,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   11,
    0,    0,    0,    0,    0,    0,    0,    0,   11,    0,
    0,    0,    0,    0,    0,    0,   33,    0,    0,    0,
    0,    0,    0,    0,   21,    0,    0,    0,    0,    0,
    0,  180,    0,  183,    0,    0,    0,    0,    0,   21,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
  117,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  227,    0,    0,    0,
    0,    0,    0,    0,   21,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,  239,  239,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   21,    0,    0,    0,
    0,    0,    0,    0,  227,    0,    0,    0,    0,  227,
  263,    0,    0,  227,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   11,    0,    0,    0,    0,    0,   11,  279,
    0,    0,    0,    0,   21,  227,   21,    0,    0,   33,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   33,    0,    0,    0,  180,
    0,    0,   21,
};
short yycheck[] = {                                       3,
    0,   34,    0,   23,   15,  104,  103,   56,    0,  145,
  183,   15,  138,  159,  228,  224,  273,  274,    0,   23,
  229,  259,  264,   43,  271,  297,  259,   15,  125,   62,
  264,  258,  266,  257,   46,  273,  274,  297,  298,   43,
  297,  298,  266,  257,    0,  272,  293,  257,  259,  259,
  292,  261,  188,  199,  227,  265,  265,   69,  268,  297,
  298,  257,   66,  259,  297,  261,  258,   71,  295,  265,
  266,  272,  268,    0,  258,  273,  274,    4,   66,  176,
  272,  284,  285,   71,  292,    0,  212,  297,  272,  109,
  291,  273,  274,  126,  260,  273,  274,  267,  118,  297,
  298,  297,  273,  274,  286,  109,  279,  289,  286,  291,
  289,  289,  271,  291,  118,  297,  298,  273,  274,  297,
  298,  271,    0,  172,  273,  274,  297,  298,  263,  264,
  134,  266,  291,  295,  293,  294,  296,  286,  149,  291,
  289,  258,  291,  155,  257,  149,  134,  272,  297,  298,
  267,  163,  272,  266,  291,  272,  160,  254,  290,    0,
  290,  149,  286,  297,  298,  289,  178,  291,  289,  262,
  291,  257,  160,  297,  298,  274,  297,  298,  266,  287,
  288,  287,  288,  194,  292,  293,  275,  276,  277,  292,
  194,  269,  270,  269,  270,  258,    0,  209,  269,  270,
  294,  205,  206,  257,  291,  216,  194,  269,  220,  293,
  293,  291,  216,  278,  279,  280,  281,  282,  283,  292,
  299,  263,  292,  271,  292,  294,  292,  291,  216,  266,
  264,  292,  252,    0,  293,  267,  269,  267,  258,  292,
  271,  293,  266,  272,  262,  258,  271,  266,  252,  266,
    0,  266,  285,  258,  258,  266,  266,  257,  266,  259,
  264,  261,  266,  263,  264,  265,  266,  266,  268,  292,
    0,  263,  264,    4,  266,  257,  264,  259,  266,  261,
  271,  263,  264,  265,  266,  297,  268,  284,  292,  291,
  233,  263,  304,  154,  160,   72,  123,  297,  298,  297,
  298,  257,  258,  259,  292,  261,  262,  263,  264,  265,
  266,    0,  268,  269,  270,  297,  272,  273,  274,  275,
  276,  277,  278,  279,  280,  281,  282,  283,  284,  285,
    0,  287,  288,  207,  290,  206,  292,  293,  307,  295,
  196,  297,  257,  258,  259,  289,  261,  262,  263,  264,
  265,  266,  267,  268,  269,  270,  211,  272,  273,  274,
  275,  276,  277,  278,  279,  280,  281,  282,  283,  284,
  285,    0,  310,  182,   81,  290,  171,  292,  293,  257,
  258,  259,  297,  261,  262,  263,  264,  265,  266,    0,
  268,  269,  270,   89,  272,  273,  274,  275,  276,  277,
  278,  279,  280,  281,  282,  283,  284,  285,    0,   91,
  172,   96,  290,  173,  292,  293,  257,  258,  259,  297,
  261,  262,  263,  264,  265,  266,   49,  268,  269,  270,
   60,  272,  273,  274,  275,  276,  277,  278,  279,  280,
  281,  282,  283,  284,  285,  201,   -1,   -1,   -1,  290,
   -1,  292,  293,  257,  258,  259,  297,  261,  262,  263,
  264,  265,  266,   -1,  268,  269,  270,   -1,  272,  273,
  274,   -1,   -1,   -1,  278,  279,  280,  281,  282,  283,
  284,  285,   -1,   -1,   -1,   -1,  290,   -1,  292,  293,
  257,  258,  259,  297,  261,  262,  263,  264,  265,  266,
   -1,  268,  269,  270,   -1,  272,   -1,   -1,   -1,   -1,
   -1,  278,  279,  280,  281,  282,  283,  284,  285,   -1,
   -1,   -1,   -1,  290,   -1,  292,  293,  257,  258,  259,
  297,  261,  262,  263,  264,  265,  266,   -1,  268,  269,
  270,   -1,  272,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  284,  285,   -1,   -1,   -1,   -1,
  290,   -1,  292,  293,   -1,   -1,   -1,  297,  257,  258,
  259,   -1,  261,  262,  263,  264,  265,  266,   -1,  268,
  269,  270,   -1,  272,   -1,   -1,   -1,  257,   -1,  259,
   -1,  261,   -1,  263,  264,  265,  266,   -1,  268,  269,
  270,  290,   -1,  292,  293,   -1,   -1,   -1,  297,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
  290,   -1,   -1,   -1,   -1,   -1,   -1,  297,  257,   -1,
  259,   -1,  261,   -1,  263,  264,  265,  266,   -1,  268,
   -1,   -1,   -1,   -1,   -1,   -1,  257,   -1,  259,   -1,
  261,   -1,  263,  264,  265,  266,   -1,  268,   -1,   -1,
   -1,    1,   -1,    3,   -1,  257,   -1,  259,  297,  261,
   -1,  263,  264,  265,  266,   15,  268,   17,   -1,   -1,
   -1,   -1,   -1,   23,   -1,   -1,  297,   -1,   -1,   -1,
   30,   -1,   -1,   -1,   34,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   43,   -1,  297,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   62,   -1,   -1,   -1,   66,   -1,   -1,   -1,
   -1,   71,   -1,   -1,   -1,   75,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  109,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  118,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  126,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  134,   -1,   -1,   -1,   -1,   -1,
   -1,  141,   -1,  143,   -1,   -1,   -1,   -1,   -1,  149,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
  160,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  186,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  194,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  205,  206,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  216,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  224,   -1,   -1,   -1,   -1,  229,
  230,   -1,   -1,  233,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,  252,   -1,   -1,   -1,   -1,   -1,  258,  259,
   -1,   -1,   -1,   -1,  264,  265,  266,   -1,   -1,  269,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  285,   -1,   -1,   -1,  289,
   -1,   -1,  292,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 299
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"AGENT","AT","CONST","DIMENSIONS",
"IF","THEN","ELSIF","ELSE","EXIT","END","FOR","FORALL","WHEN","OTHERWISE","OF",
"ASSIGN","PLUS","MINUS","TIMES","DIVIDE","MOD","EQUAL","LESSER","GREATER",
"LESSEQ","GREATEQ","NOTEQ","AND","OR","NOT","SUCC","PRED","LEFTPAREN",
"RIGHTPAREN","LEFTBRACKET","RIGHTBRACKET","COMMA","DOTS","DOT","COLON",
"IDENTIFIER","NUMERICLITERAL","STRINGLITERAL",
};
char *yyrule[] = {
"$accept : program",
"$$1 :",
"program : const_decl_list declare_cells $$1 statement_list",
"program :",
"const_decl_list : const_declare const_decl_list",
"const_decl_list :",
"const_declare : simple_const",
"const_declare : array_const",
"simple_const : CONST identifier ASSIGN const_integer",
"$$2 :",
"array_const : CONST identifier LEFTBRACKET RIGHTBRACKET FOR const_number ASSIGN $$2 const_array_values",
"const_array_values : STRINGLITERAL",
"$$3 :",
"const_array_values : $$3 const_integer rest_const_integer",
"rest_const_integer : COMMA const_integer rest_const_integer",
"rest_const_integer :",
"const_integer : unary_add const_number",
"const_integer : number",
"const_integer : identifier",
"const_number : number",
"const_number : identifier",
"$$4 :",
"declare_cells : const_number $$4 DIMENSIONS OF fields_or_range",
"fields_or_range : number rest_range",
"fields_or_range : unary_add rest_signed_range",
"fields_or_range : identifier const_or_field",
"$$5 :",
"$$6 :",
"fields_or_range : CONST $$5 identifier array_or_list rest_fields agent_fields $$6 END",
"$$7 :",
"$$8 :",
"fields_or_range : $$7 agent_fields $$8 END",
"$$9 :",
"const_or_field : $$9 rest_range",
"$$10 :",
"$$11 :",
"const_or_field : $$10 array_or_list rest_fields agent_fields $$11 END",
"$$12 :",
"agent_fields : AGENT $$12 OF field rest_fields",
"agent_fields :",
"rest_fields : field rest_fields",
"rest_fields :",
"field : identifier array_or_list",
"$$13 :",
"field : CONST $$13 identifier array_or_list",
"array_or_list : LEFTBRACKET RIGHTBRACKET FOR const_number OF range",
"$$14 :",
"array_or_list : $$14 rest_ident_list OF range",
"rest_range : DOTS const_integer",
"$$15 :",
"rest_signed_range : const_number $$15 rest_range",
"range : const_integer DOTS const_integer",
"rest_ident_list : COMMA identifier rest_ident_list",
"rest_ident_list :",
"number : NUMERICLITERAL",
"statement_list : statement statement_list",
"statement_list :",
"statement : assign_or_agent_statement",
"statement : const_declare",
"statement : if_statement",
"statement : forall_statement",
"statement : exit_statement",
"statement : agent_statement",
"$$16 :",
"assign_or_agent_statement : assignable $$16 assign_or_agent",
"assign_or_agent : ASSIGN expr_list rest_assign",
"$$17 :",
"assign_or_agent : $$17 place_agent",
"$$18 :",
"assignable : identifier $$18 alias_or_ident",
"alias_or_ident : LEFTBRACKET declare_or_use",
"$$19 :",
"alias_or_ident : $$19 field_ref_option",
"$$20 :",
"declare_or_use : RIGHTBRACKET $$20 field_ref_option array_decl_option",
"$$21 :",
"$$22 :",
"declare_or_use : $$21 array_index RIGHTBRACKET $$22 field_ref_option",
"array_decl_option : FOR const_number",
"array_decl_option :",
"$$23 :",
"index : identifier $$23 shift_option",
"$$24 :",
"index : unary_add const_number $$24 shift_option",
"$$25 :",
"index : number $$25 shift_option",
"$$26 :",
"array_index : $$26 expression",
"shift_option : do_shifts",
"shift_option :",
"$$27 :",
"do_shifts : $$27 shift rest_shifts",
"rest_shifts : shift rest_shifts",
"rest_shifts :",
"$$28 :",
"shift : SUCC $$28 shift_amount",
"$$29 :",
"shift : PRED $$29 shift_amount",
"shift_amount : number",
"shift_amount : identifier",
"$$30 :",
"rest_assign : WHEN expression $$30 assign_list",
"rest_assign :",
"$$31 :",
"rest_when : WHEN expression $$31 assign_list",
"rest_when : OTHERWISE",
"assign_list : ASSIGN expr_list rest_when",
"assign_list :",
"$$32 :",
"expr_list : $$32 expression rest_expr_list",
"rest_expr_list : COMMA expression rest_expr_list",
"rest_expr_list :",
"$$33 :",
"$$34 :",
"if_statement : IF expression $$33 THEN statement_list elsif_list else $$34 END",
"elsif_list : elsif elsif_list",
"elsif_list :",
"$$35 :",
"elsif : ELSIF expression $$35 THEN statement_list",
"$$36 :",
"else : ELSE $$36 statement_list",
"else :",
"forall_statement : FORALL index_var statement_list END",
"index_var : identifier range_option",
"range_option : COLON agent_or_range",
"range_option :",
"$$37 :",
"agent_or_range : $$37 range",
"agent_or_range : AGENT",
"exit_statement : EXIT",
"$$38 :",
"agent_statement : AGENT LEFTPAREN expr_list RIGHTPAREN $$38 place_agent",
"place_agent : AT associated_cell rest_place",
"$$39 :",
"rest_place : WHEN expression $$39 place_list",
"rest_place : OTHERWISE",
"rest_place :",
"place_list : AT associated_cell place_when",
"place_list :",
"$$40 :",
"place_when : WHEN expression $$40 place_list",
"place_when : OTHERWISE",
"associated_cell : identifier",
"$$41 :",
"associated_cell : $$41 relative_index",
"expression : expression_1",
"expression_1 : expression_2 rest_expr_1",
"$$42 :",
"rest_expr_1 : binary_boolean expression_2 $$42 rest_expr_1",
"rest_expr_1 :",
"expression_2 : expression_3 rest_expr_2",
"rest_expr_2 : binary_relation expression_3",
"rest_expr_2 :",
"expression_3 : expression_4 rest_expr_3",
"$$43 :",
"rest_expr_3 : binary_add expression_4 $$43 rest_expr_3",
"rest_expr_3 :",
"expression_4 : expression_5 rest_expr_4",
"$$44 :",
"rest_expr_4 : binary_mult expression_5 $$44 rest_expr_4",
"rest_expr_4 :",
"expression_5 : expression_6",
"expression_5 : unary_add expression_6",
"expression_6 : primary",
"expression_6 : unary_boolean primary",
"$$45 :",
"primary : identifier $$45 index_or_other",
"primary : number",
"primary : LEFTPAREN expression RIGHTPAREN",
"primary : relative_index field_ref_option",
"$$46 :",
"relative_index : LEFTBRACKET $$46 index rest_index_list RIGHTBRACKET",
"index_or_other : array_option field_ref_option",
"index_or_other : do_shifts",
"array_option : LEFTBRACKET array_index RIGHTBRACKET",
"array_option :",
"rest_index_list : COMMA index rest_index_list",
"rest_index_list :",
"field_ref_option : field_ref",
"field_ref_option :",
"field_ref : DOT identifier name_or_array",
"$$47 :",
"name_or_array : LEFTBRACKET $$47 array_field",
"name_or_array :",
"array_field : array_index RIGHTBRACKET",
"array_field : RIGHTBRACKET",
"identifier : IDENTIFIER",
"binary_boolean : AND",
"binary_boolean : OR",
"unary_boolean : NOT",
"binary_relation : EQUAL",
"binary_relation : NOTEQ",
"binary_relation : LESSER",
"binary_relation : GREATER",
"binary_relation : LESSEQ",
"binary_relation : GREATEQ",
"binary_add : PLUS",
"binary_add : MINUS",
"unary_add : binary_add",
"binary_mult : TIMES",
"binary_mult : DIVIDE",
"binary_mult : MOD",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 423 "parse"

boolean syntax_error;	/* True iff a syntax error was encountered. */

/* The number of dimensions to expect from the "-s" option if present. 
   A value of 0 indicates that the "-s" option wasn't given.
*/
int dims_expected = 0;

/* The size to use for each dimension of the universe. */
int dim_size[MAX_SUPPORTED_DIMENSIONS];

/* The number of cpus to generate code for. */
int cpus = DEFAULT_CPUS;

/* Keep track of the number of trace indices given and their values. */
int trace_count = 0;
int trace_point[MAX_SUPPORTED_DIMENSIONS];

/* Determine if a field was specified for display.  If so, it contains
   the field specified.
*/
int field_given = 0;

/* The number of bits to use when compiling for use with microvectors.  A
   value of 0 indicates that the option was not specified.
*/
int mv_bits = 0;
boolean mv_signed = false;

/* A range check is generated for array indices to make sure they are
   within bounds iff rng_chk is true.  NOT checking is the default.
*/
boolean rng_chk = false;

/* True iff a filter object code file is to be compiled into the CA. */
boolean filter = false;

/* A unique number (probably the process if) to make file names unique. */
int pid = 0;

/* Print out the correct usage. */
void usage(char *command) {
	fprintf(stderr, "usage: %s [-C] [-cpus n] [-mv n[u|s]] [-s (n|n,...,n)]\n",
		command); 
	exit(1);
}

/* Indicates whether or not floating point operations should be used in
   Cellular Automata computations.
*/
boolean use_floats = false;

int main(int argc, char *argv[]) {
	int i = 0;

	/* Check for proper usage and options. */
	while (++i <= argc-1)
		if (strcmp(argv[i], "-C") == 0)
			rng_chk = true;
		else if (strcmp(argv[i], "-F") == 0)
			filter = true;
		else if (strcmp(argv[i], "-cpus") == 0) {
			cpus = atoi(argv[++i]);
			if (cpus < 1) {
				fprintf(stderr, 
					"%s: Number of CPUs must be > 0.\n", 
					argv[0]);
				exit(1);
			}
		}
		else if (strcmp(argv[i], "-mv") == 0) {
			char c;
			int count = sscanf(argv[++i], "%d%c", &mv_bits, &c);
			if (count < 1) {
				fprintf(stderr, 
					"%s: Invalid microvector specification.\n", 
					argv[0]);
				exit(1);
			}
			if (count == 2 && c == 's')
				mv_signed = true;
			else if (count == 2 && c != 'u') {
				fprintf(stderr, 
					"%s: '%c' is an invalid microvector sign indicator.\n", 
					argv[0], c);
				exit(1);
			}
			if (mv_bits < 1) {
				fprintf(stderr, 
					"%s: Number of microvector bits must be > 0.\n", 
					argv[0]);
				exit(1);
			}
		}
		else if (strcmp(argv[i], "-pid") == 0)
			pid = atoi(argv[++i]);
		else if (strcmp(argv[i], "-s") == 0) {
			char *trace_token = strtok(argv[++i], ",");
			
			do {
				dim_size[dims_expected++] = atoi(trace_token);

				if (dim_size[dims_expected-1] < 0) {
					fprintf(stderr, 
						"%s: Dimension size must be > 0.\n", 
						argv[0]);
					exit(1);
				}
			} while ((trace_token = strtok((char*) NULL, ",")) != NULL);
		}
		else if (strcmp(argv[i], "-trace") == 0) {
			char *trace_token = strtok(argv[++i], ",");
			
			do {
				trace_point[trace_count++] = atoi(trace_token);
			} while ((trace_token = strtok((char*) NULL, ",")) != NULL);
		}
		else if (strcmp(argv[i], "-f") == 0) {
			field_given = atoi(argv[++i]);
			if (field_given < 1) {
				fprintf(stderr, 
					"%s: Field must be integer > 0.\n", 
					argv[0]);
				exit(1);
			}
		}
		else if (strcmp(argv[i], "-float") == 0) {
			use_floats = true;
		} else
			usage(argv[0]);

	/* Array index range checking cannot be done with microvectors. */
	if (rng_chk && mv_bits > 0) {
		fprintf(stderr, 
			"%s: Range checking is not available with microvectors.\n",
			argv[0]);
		exit(1);
	}

	/* Setup the default dimension size(s). */
	for (i = 0; i < MAX_SUPPORTED_DIMENSIONS; i++)
		if (dims_expected == 0)
			dim_size[i] = DEFAULT_DIM_SIZE;
		else if (dims_expected == 1)
			dim_size[i] = dim_size[0];

	/* Check the validity of the trace option, if given. */
	if (trace_count > 0) for (i = 0; i < trace_count; i++)
		if (trace_point[i] < 0 || trace_point[i] >= dim_size[i]) {
			fprintf(stderr, 
				"%s: Trace index %d is larger than the dimension size.\n",
				argv[0], trace_point[i]);
			exit(1);
		}

	syntax_error = false;
	start_up();

	/* Read and compile the user's program. */
	startscan();
	yyparse();

	/* If no errors occurred, then finishup. */
	if (!scan_error && !syntax_error && !semantic_error) {
		finish_up();
		return 0;
	}
	/* Indicate an error. */
	else
		return 1;
}

#include "error.h"

int yyerror(char *s) {
	syntax_error = true;
	error_prefix();
	fprintf(stderr, "%s\n", s);
	return true;
}
#line 891 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 85 "parse"
{ begin_rules(); }
break;
case 2:
#line 86 "parse"
{ end_rules(); }
break;
case 8:
#line 99 "parse"
{ declare_simple_const(); }
break;
case 9:
#line 103 "parse"
{ declare_array_const(); }
break;
case 11:
#line 106 "parse"
{ push(yytext); read_from_file(); }
break;
case 12:
#line 107 "parse"
{ push_mark(); }
break;
case 15:
#line 111 "parse"
{ array_value(); }
break;
case 16:
#line 114 "parse"
{ mk_signed_int(); }
break;
case 18:
#line 116 "parse"
{ get_simple_const(); }
break;
case 20:
#line 120 "parse"
{ get_simple_const(); }
break;
case 21:
#line 123 "parse"
{ set_dimensions(); }
break;
case 23:
#line 127 "parse"
{ declare_default_field(); }
break;
case 24:
#line 128 "parse"
{ declare_default_field(); }
break;
case 26:
#line 130 "parse"
{ begin_decl_cells(); set_const_field(); }
break;
case 27:
#line 132 "parse"
{ non_empty(); }
break;
case 29:
#line 133 "parse"
{ begin_decl_cells(); }
break;
case 30:
#line 133 "parse"
{ non_empty(); }
break;
case 32:
#line 136 "parse"
{ get_simple_const(); }
break;
case 33:
#line 137 "parse"
{ declare_default_field(); }
break;
case 34:
#line 138 "parse"
{ begin_decl_cells(); }
break;
case 35:
#line 139 "parse"
{ non_empty(); }
break;
case 37:
#line 142 "parse"
{ set_agent(); end_decl_cells(); begin_decl_agent(); }
break;
case 38:
#line 143 "parse"
{ end_decl_agent(); }
break;
case 39:
#line 144 "parse"
{ end_decl_cells(); }
break;
case 43:
#line 152 "parse"
{ set_const_field(); }
break;
case 45:
#line 156 "parse"
{ declare_array_field(); }
break;
case 46:
#line 157 "parse"
{ push_mark(); swap_top_2(); }
break;
case 47:
#line 158 "parse"
{ declare_fields(); }
break;
case 48:
#line 161 "parse"
{ make_range(); }
break;
case 49:
#line 164 "parse"
{ mk_signed_int(); }
break;
case 51:
#line 167 "parse"
{ make_range(); }
break;
case 54:
#line 174 "parse"
{ process_literal(yytext); }
break;
case 63:
#line 189 "parse"
{ end_lhs(); }
break;
case 66:
#line 193 "parse"
{ copy_agent(); }
break;
case 68:
#line 196 "parse"
{ assignable_base(); }
break;
case 71:
#line 200 "parse"
{ confirm_simple(); }
break;
case 73:
#line 203 "parse"
{ confirm_array(true); }
break;
case 75:
#line 205 "parse"
{ confirm_array(false); }
break;
case 76:
#line 207 "parse"
{ do_array_index(); }
break;
case 78:
#line 210 "parse"
{ declare_array_variable(); }
break;
case 80:
#line 214 "parse"
{ get_simple_const_or_index(); }
break;
case 82:
#line 216 "parse"
{ mk_signed_int(); convert_to_uvector(); }
break;
case 84:
#line 217 "parse"
{ convert_to_uvector(); }
break;
case 86:
#line 220 "parse"
{ start_array_index(); }
break;
case 87:
#line 220 "parse"
{ end_array_index(); }
break;
case 90:
#line 227 "parse"
{ process_literal("0"); convert_to_uvector(); }
break;
case 91:
#line 228 "parse"
{ do_mod_index(); }
break;
case 94:
#line 235 "parse"
{ push("+"); }
break;
case 95:
#line 235 "parse"
{ binary_op(); }
break;
case 96:
#line 236 "parse"
{ push("-"); }
break;
case 97:
#line 236 "parse"
{ binary_op(); }
break;
case 98:
#line 239 "parse"
{ convert_to_uvector(); }
break;
case 99:
#line 240 "parse"
{ get_simple_const_or_index(); }
break;
case 100:
#line 246 "parse"
{ jump_if(); do_assign(); }
break;
case 102:
#line 247 "parse"
{ do_assign(); end_assign(); }
break;
case 103:
#line 250 "parse"
{ jump_elsif(); do_assign(); }
break;
case 105:
#line 252 "parse"
{ start_else(); do_assign(); end_if(); end_assign(); }
break;
case 107:
#line 256 "parse"
{ end_if(); end_assign(); }
break;
case 108:
#line 259 "parse"
{ push_mark(); }
break;
case 112:
#line 266 "parse"
{ jump_if(); }
break;
case 113:
#line 267 "parse"
{ end_if(); }
break;
case 117:
#line 274 "parse"
{ jump_elsif(); }
break;
case 119:
#line 277 "parse"
{ start_else(); }
break;
case 122:
#line 281 "parse"
{ end_forall(); }
break;
case 125:
#line 288 "parse"
{ begin_forall(); implicit_bounds(); }
break;
case 126:
#line 291 "parse"
{ begin_forall(); }
break;
case 127:
#line 291 "parse"
{ set_index_bounds(); }
break;
case 128:
#line 292 "parse"
{ begin_forall_agent(); }
break;
case 129:
#line 295 "parse"
{ exit_forall(); }
break;
case 130:
#line 299 "parse"
{ create_agent(); }
break;
case 133:
#line 305 "parse"
{ jump_if(); put_agent(); }
break;
case 135:
#line 306 "parse"
{ put_agent(); }
break;
case 136:
#line 307 "parse"
{ put_agent(); }
break;
case 138:
#line 311 "parse"
{ start_else(); free_agent(); end_if(); }
break;
case 139:
#line 314 "parse"
{ jump_elsif(); put_agent(); }
break;
case 141:
#line 315 "parse"
{ start_else(); put_agent(); end_if(); }
break;
case 142:
#line 318 "parse"
{ get_cell_variable(); }
break;
case 143:
#line 319 "parse"
{ trace_relative_index(); }
break;
case 144:
#line 319 "parse"
{ now2next(); }
break;
case 147:
#line 329 "parse"
{ binary_op(); }
break;
case 151:
#line 335 "parse"
{ binary_op(); }
break;
case 154:
#line 341 "parse"
{ binary_op(); }
break;
case 158:
#line 347 "parse"
{ binary_op(); }
break;
case 162:
#line 352 "parse"
{ unary_op(); }
break;
case 164:
#line 356 "parse"
{ unary_op(); }
break;
case 165:
#line 359 "parse"
{ get_const_or_variable(); }
break;
case 167:
#line 360 "parse"
{ convert_to_uvector(); }
break;
case 170:
#line 365 "parse"
{ push_mark(); }
break;
case 171:
#line 367 "parse"
{ cell_reference(); }
break;
case 174:
#line 374 "parse"
{ do_array_index(); }
break;
case 181:
#line 389 "parse"
{ push_array_attr(); }
break;
case 183:
#line 390 "parse"
{ field_reference(); }
break;
case 184:
#line 393 "parse"
{ field_array_index(); }
break;
case 185:
#line 394 "parse"
{ field_array_reference(); }
break;
case 186:
#line 397 "parse"
{ push(yytext); }
break;
case 187:
#line 400 "parse"
{ push("&&"); }
break;
case 188:
#line 401 "parse"
{ push("||"); }
break;
case 189:
#line 403 "parse"
{ push("!"); }
break;
case 190:
#line 405 "parse"
{ push("=="); }
break;
case 191:
#line 406 "parse"
{ push("!="); }
break;
case 192:
#line 407 "parse"
{ push("<"); }
break;
case 193:
#line 408 "parse"
{ push(">"); }
break;
case 194:
#line 409 "parse"
{ push("<="); }
break;
case 195:
#line 410 "parse"
{ push(">="); }
break;
case 196:
#line 412 "parse"
{ push("+"); }
break;
case 197:
#line 413 "parse"
{ push("-"); }
break;
case 199:
#line 417 "parse"
{ push("*"); }
break;
case 200:
#line 418 "parse"
{ push("/"); }
break;
case 201:
#line 419 "parse"
{ push("%"); }
break;
#line 1468 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
