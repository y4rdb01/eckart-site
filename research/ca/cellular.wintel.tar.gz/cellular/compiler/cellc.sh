#!sh
#  cellc.sh
#  Copyright (C) 1992, 1993, 1994, 1995, 1997, 1999  J Dana Eckart
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 1, or (at your option)
#  any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with CELLULAR; see the file COPYING.  If not, write to the 
#  Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

LIB=YOUR_LIB
CC="YOUR_CC"
CFLAGS="YOUR_CFLAGS"
CDEFINES="YOUR_CDEFINES"
CLIB="YOUR_CLIB"
WINTEL="YOUR_WINTEL"

TMP_DIR="YOUR_TMP_DIR"

MAX_CPUS=YOUR_MAX_CPUS
DEFAULT_CPUS=YOUR_DEFAULT_CPUS

PID=$$

BASE_FILE_NAME=YOUR_BASE_FILE_NAME
C_FILE=$BASE_FILE_NAME${PID}.c

USAGE="usage: `basename $0` [-o outputfile] [-C] [-F filter] [-cpus n] [-mv n[u|s]] [-s (n|n,...,n)] [-trace n,...,n] [-f n] [-float] filename"

trap "cd $TMP_DIR; rm -f $BASE_FILE_NAME${PID}*" 0
trap "cd $TMP_DIR; rm -f $BASE_FILE_NAME${PID}*; exit" 2

#
# Get options and check usage
#
if (test $# -lt 1)
then
	echo $USAGE
	exit 1
fi

while (test $# -gt 1)
do
	case $1 in
		'-o') 	if (test -n "$OUT_FILE")
                        then
                                echo $USAGE
                                exit 1
			else
				OUT_FILE=$2
				shift
			fi
			;;
		'-C')   if (test -n "$RNG_CHK")
			then
                                echo $USAGE
                                exit 1
			else
				RNG_CHK=$1
			fi
			;;
		'-F')	if (test -n "$FILTER")
                        then
                                echo $USAGE
                                exit 1
                        else
				FILTER=$1
				FILTER_NAME=$2
				shift
			fi
			;;
		'-cpus') if (test -n "$CPUS")
                        then
                                echo $USAGE
                                exit 1
                        else
				CPUS=$2
				shift
			fi
			;;
		'-mv')	if (test -n "$MV")
                        then
                                echo $USAGE
                                exit 1
                        else
				MV=$2
				shift
			fi
			;;
		'-s')	if (test -n "$DIM_SIZE")
                        then
                                echo $USAGE
                                exit 1
                        else
				DIM_SIZE="-s $2"
				shift
			fi
			;;
		'-trace') if (test -n "$TRACE")
                        then
                                echo $USAGE
                                exit 1
                        else
				TRACE="-trace $2"
				shift
			fi
			;;
		'-f')	if (test -n "$FIELD")
                        then
                                echo $USAGE
                                exit 1
                        else
				FIELD="-f $2"
				shift
			fi
			;;
		'-float') if (test -n "$FLOAT")
                        then
                                echo $USAGE
                                exit 1
                        else
				FLOAT="-float"
			fi
			;;
		*) 	echo "Unknown flag, '$1'."
			echo $USAGE
			exit 1
			;;
	esac
	shift
done

FILE=$1

#
# If no cpus specified, then use the default.
#
if (test -z "${CPUS}")
then
	CPUS=${DEFAULT_CPUS}
fi

#
# Check for too many CPUS.
#
if (test ${CPUS} -gt ${MAX_CPUS})
then
	echo "Too many cpus specified; defaulting to the maximum allowed (${MAX_CPUS})."
	CPUS="-cpus ${MAX_CPUS}"
else
	CPUS="-cpus ${CPUS}"
fi

#
# Check for a meaningful value for microvectors.
#
if (test "${MV}")
then
	MV="-mv ${MV}"
fi

#
# Check for incompatible options.
#
if (test "${MV}" -a "${TRACE}")
then
	echo "`basename $0`: The -mv and -trace options are incompatible."
	exit 1
fi

# By default, put the executable in "avcam.out".
#
if (test -z "$OUT_FILE")
then
	OUT_FILE=avcam.out
fi

#
# Perform conversion to C and then do a C compilation.
#
if (test -r $FILE)
then
	if $LIB/cellcpp -pid $PID $RNG_CHK $DIM_SIZE $CPUS $MV $TRACE $FIELD $FILTER $FLOAT < $FILE 
	then
		$CC $CFLAGS $CDEFINES -DUV_INLINE -c \
			-o $TMP_DIR/$BASE_FILE_NAME$PID.o \
			$TMP_DIR/$C_FILE >/dev/null
		$CC $CFLAGS -o $OUT_FILE \
			$TMP_DIR/$BASE_FILE_NAME$PID.o \
			$FILTER_NAME \
			$LIB/*.o $CLIB >/dev/null

		# See if compilation succeeded.
		#
		if (test ! -r $OUT_FILE )
		then
			echo "`basename $0`: compilation of $FILE failed for unknown reason"
		else
			if (test "${WINTEL}" -ne "1")
			then
				# Strip a Unix binary.
				#
				strip $OUT_FILE
			fi
		fi
	else
		echo "`basename $0`: cellcpp on $FILE failed for unknown reason"
	fi
else
	echo "`basename $0`: file $FILE not found"
fi
