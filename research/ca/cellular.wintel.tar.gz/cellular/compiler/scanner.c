/* scanner.c
   Copyright (C) 1992, 1993, 1997  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* This is a hand coded scanner for cellang. */

#include <stdio.h>
#include "scanner.h"
#include "error.h"
#include "io.h"

#define MAX_TOKEN_LENGTH 	256 	/* Maximum size of any token. */

char yytext[MAX_TOKEN_LENGTH];		/* Saved text of a token. */
int yyleng;				/* Length of the saved text. */

int c;

boolean save_c = false;	/* True iff a character should be reused. */

int linenumber; 	/* The line number on which the previous token 
			   appeared.  This allows better trace option
			   line numbering.
			*/
int clinenumber; 	/* Current line number in the input stream. */

boolean scan_error;	/* True iff a scanning error was encountered. */

boolean one_error;	/* Used to limit one scanner error notice per token. */

/* Performs the initialization to begin scanning a new file. */
void startscan(void) {
	clinenumber = linenumber = 1;
	c = ' ';
}

/* Gets the next character.  Responsible for updating "clinenumber". */
int get_char(void) {
	if (!save_c) {
		if (c == '\n') clinenumber++;
		c = getc(stdin);
	}
	else save_c = false;
	return (c);
}

/* Prints out the prefix that appears before all compiler generated
   error messages.  The form of the prefix is:
		"line line_number: "
   where line_number is replaced with the appropriate information.
*/
void error_prefix(void) {
	fprintf(stderr, "line %d: ", linenumber);
}

/* Takes a string format and a string with which to build an
   error message.  The message is automatically prepended with
   the current linenumber.
*/
void lex_error(char *format, char *string) {
	if (one_error) return;
	one_error = true;
	scan_error = true;
	error_prefix();
	if (string)
		fprintf(stderr, format, string);
	else
		fprintf(stderr, format);
	fprintf(stderr, "\n");
}

/* Saves the character c in yytext.  Checks to insure that the maximum
   token length has not been exceeded.
*/
void save(char c) {
	if (yyleng == 256 && !one_error) {
		one_error = true;
		yytext[yyleng] = '\0';
		lex_error("Token '%s' is too long", yytext);
	}
	else yytext[yyleng++] = c;
}

/* Recognizes comments: #[^#"\n"]"\n"
   No text is saved.
*/
void comment(void) {
	c = get_char();
	while (c != '\n') c = get_char();
}

/* Skips comments, blanks, tabs and new lines. */
void skip_white_space(void) {
	while (c >= 0) {
		if (c == '#') comment();
		else if (c <= 32 || c == 127) c = get_char();
		else break;
	}
}

/* Recognizes numeric literals: [0-9]+(_[0-9]+)* 
   Underscores are stripped out.
*/
void integer(void) {
	boolean error;
	error = false;
	while ('0' <= c && c <= '9') {
		save(c);
		c = get_char();
		if (c == '_') {
			c = get_char();
			if (c < '0' || '9' < c) error = true;
		}
	}
	save_c = true;
	yytext[yyleng] = '\0';
	if (error) lex_error("Illegal underscore in '%s'", yytext);
}


/* Recognizes identifiers (and keywords): [A-Za-z][A-Za-z0-9]*(_[A-Za-z0-9]+)*
   Identifiers (and keywords) are converted to lower case.
*/
void identifier(void) {
	boolean error;
	error = false;
	while (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') ||
	       ('0' <= c && c <= '9')) {
		if ('A' <= c && c <= 'Z') c = 'a' + (c - 'A');
		save(c);
		c = get_char();
		if (c == '_') {
			save(c);
			c = get_char();
			if (c == '_') error = true;
		}
	}
	save_c = true;
	yytext[yyleng] = '\0';
	if (error) lex_error("Illegal underscore in '%s'", yytext);
}

/* The record "string_number" associates a reserved word with its token
   number.  The "table" is a collection of these associations.  The 
   function "lookup" uses the table to determine whether or not yytext
   contains a reserved word.  If it does it's token number is returned,
   else the token number of an identifier is returned.
*/

typedef struct {
	char *string;
	int number;
} string_number;

#define MAX_TABLE 14

static string_number table[MAX_TABLE] = {
	{"agent", AGENT},
	{"const", CONST},
	{"dimensions", DIMENSIONS},
	{"else", ELSE},
	{"elsif", ELSIF},
	{"end", END},
	{"exit", EXIT},
	{"for", FOR},
	{"forall", FORALL},
	{"if", IF},
	{"of", OF},
	{"otherwise", OTHERWISE},
	{"then", THEN},
	{"when", WHEN}
};

#include <string.h>

/* Performs a binary search to determine if the identifier is a
   reserved word.
*/
int lookup(void) {
	int upper, middle, lower;
	upper = MAX_TABLE - 1;
	lower = 0;
	while (lower <= upper) {
		int cmp;
		middle = (upper + lower) / 2;
		cmp = strcmp(yytext, table[middle].string);
		if (cmp < 0) upper = middle - 1;
		else if (cmp > 0) lower = middle + 1;
		else return table[middle].number;
	}
	return IDENTIFIER;
}

/* This is the procedure called by the parser generated by bison.  It
   returns integer token numbers that depend upon the token read.  
   White space that occurs between tokens is always skipped.  A legal
   token is always returned, even if several errors occur while scan-
   ning such a token. 
*/
int yylex(void) {
	NumericIsFloat = false;

	linenumber = clinenumber;
	while (1) {	/* Search until you find something. */
		yyleng = 0;
		one_error = false;
		c = get_char();
		skip_white_space();
		if (c < 0) return(c);
		else if ('0' <= c && c <= '9') {
			integer();

			/* Determine whether or not this is a float. */ 
			c = get_char();
			if (c == '.') {
				c = get_char();
				if ('0' <= c && c <= '9') {
					char float_string[MAX_TOKEN_LENGTH];
					sprintf(float_string, "%s.", yytext);
					yyleng = 0;
					integer();
					strcat(float_string, yytext);
					strcpy(yytext, float_string);
					NumericIsFloat = true;
					if (!use_floats)
						lex_error("Use the -float option if floating-point arithmetic is desired", (char*) NULL);
				} else {
					ungetc(c, stdin);
					save_c = true;
				}
			} else
				save_c = true;

			return(NUMERICLITERAL);
		}
		else if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z')) {
			identifier();
			return(lookup());
		}
		else switch(c) {
		case '+':	c = get_char();
				if (c == '%') return(SUCC);
				else {
					save_c = true;
					return(PLUS);
				}
		case '-':	c = get_char();
				if (c == '%') return(PRED);
				else if (c == '>') return(AT);
				else {
					save_c = true;
					return(MINUS);
				}
		case '*':	return(TIMES);
		case '/':	return(DIVIDE);
		case '%':	return(MOD);
		case '&':	return(AND);
		case '|':	return(OR);
		case '!':	c = get_char();
				if (c == '=') return(NOTEQ);
				else {
					save_c = true;
					return(NOT);
				}
		case '=':	return(EQUAL);
		case '<':	c = get_char();
				if (c == '=') return(LESSEQ);
				else {
					save_c = true;
					return(LESSER);
				}
		case '>':	c = get_char();
				if (c == '=') return(GREATEQ);
				else {
					save_c = true;
					return(GREATER);
				}
		case '(':	return(LEFTPAREN);
		case ')':	return(RIGHTPAREN);
		case '[':	return(LEFTBRACKET);
		case ']':	return(RIGHTBRACKET);
		case ':':	save(c);
				c = get_char();
				if (c == '=') return(ASSIGN);
				else {
					save_c = true;
					yytext[yyleng] = '\0';
					return(COLON);
				}
		case ',':	return(COMMA);
		case '.':	c = get_char();
				if (c == '.') return(DOTS);
				else {
					save_c = true;
					return(DOT);
				}
		case '"':	while ((c = get_char()) != '"' && c != '\n') {
					save(c);
				}
				if (c == '\n')
					lex_error("Unterminated filename",
						  (char*) NULL);
				yytext[yyleng] = '\0';
				return(STRINGLITERAL);
		default:	save(c);
				yytext[yyleng] = '\0';
				lex_error("Illegal use of '%s'", yytext);
		}
	}
}
