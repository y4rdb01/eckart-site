/* semantic.h
   Copyright (C) 1992, 1993, 1994, 1995, 1997  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* These are the declarations for all of the semantic actions. */

#include "boolean.h"

/* True iff a semantic error was encountered. */
extern boolean semantic_error;

/* A unique number (probably the process if) to make file names unique. */
extern int pid;

/* The default (maximum) sizes associated with Cellang programs. */
#define MAX_SUPPORTED_DIMENSIONS	256
#define MAX_SUPPORTED_FIELDS		256

#define MAX_STRING_LENGTH	512

/* The number of dimensions to expect from the "-s" option if present.
   A value of 0 indicates that the "-s" option wasn't given.
*/
extern int dims_expected;

/* The size to use for each dimension of the universe. */
extern int dim_size[MAX_SUPPORTED_DIMENSIONS];

/* The number of cpus to generate code for. */
extern int cpus;

/* Keep track of the number of trace indices given and their values. */
extern int trace_count;
extern int trace_point[MAX_SUPPORTED_DIMENSIONS];

/* Determine if a field was specified for display.  If so, it contains
   the field specified.
*/
extern int field_given;

/* The number of bits to use when compiling for use with microvectors.  A
   value of 0 indicates that the option was not specified.
*/
extern int mv_bits;
extern boolean mv_signed;

/* A range check is generated for array indices to make sure they are
   within bounds iff rng_chk is true.  NOT checking is the default.
*/
extern boolean rng_chk;

/* True iff a filter object code file is to be compiled into the CA. */
extern boolean filter;

/* Initialization and cleanup for the compilation */
extern void start_up(void);
extern void finish_up(void);

/* Declare constants. */
extern void declare_simple_const(void);
extern void declare_array_const(void);
extern void read_from_file(void);
extern void array_value(void);

/* Declare the dimensionality and fields of the cells of the universe. */
extern void begin_decl_cells(void);
extern void end_decl_cells(void);
extern void set_const_field(void);
extern void declare_fields(void);
extern void declare_array_field(void);
extern void declare_default_field(void);
extern void make_range(void);
extern void set_dimensions(void);
extern void set_agent(void);
extern void begin_decl_agent(void);
extern void end_decl_agent(void);
extern void non_empty(void);

/* Group the cellular automata rules into a function. */
extern void begin_rules(void);
extern void end_rules(void);

/* Forall statement */
extern void begin_forall_agent(void);
extern void begin_forall(void);
extern void end_forall(void);
extern void exit_forall(void);
extern void set_index_bounds(void);
extern void implicit_bounds(void);

/* Assignment statement */
extern void do_assign(void);
extern void end_assign(void);

/* When statment */
extern void jump_when(void);

/* If-then-elsif-else statment */
extern void jump_if(void);
extern void jump_elsif(void);
extern void start_else(void);
extern void end_if(void);

/* Simple push operations */
extern void push_mark(void);
extern void push(char *);

/* Semantic stack manipulation */
extern void swap_top_2(void);

/* Simple processing */
extern void process_literal(char *);
extern void mk_signed_int(void);
extern void convert_to_uvector(void);

/* Setup variables (left hand side of assignments) */
extern void assignable_base(void);
extern void end_lhs(void);
extern void declare_array_variable(void);
extern void start_array_index(void);
extern void end_array_index(void);
extern void do_array_index(void);
extern void confirm_simple(void);
extern void confirm_array(boolean);

/* Expressions */
extern void get_simple_const(void);
extern void get_simple_const_or_index(void);
extern void get_const_or_variable(void);
extern void binary_op(void);
extern void unary_op(void);
extern void do_mod_index(void);
extern void push_array_attr(void);

/* Getting the value from a neighboring cell. */
extern void cell_reference(void);
extern void field_reference(void);
extern void field_array_reference(void);
extern void field_array_index(void);

/* For the creation of an agent at a specified cell site. */
extern void copy_agent(void);
extern void create_agent(void);
extern void free_agent(void);
extern void put_agent(void);
extern void trace_relative_index(void);
extern void get_cell_variable(void);
extern void now2next(void);

/* Indicates whether or not floating point operations should be used in
   Cellular Automata computations.
*/
extern boolean use_floats;
