/* symtable.c
   Copyright (C) 1992  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* This file implements the symbol table.  Bucket hashing is used,
   associating an attribute with each identifier.  New identifiers 
   are always added to the front of the chain representing the bucket.  
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "attr.h"
#include "symtable.h"
#include "error.h"

#define TableSize	27

typedef struct bucket_fubar {
	char* name;
	attr_rec *attribute;
	struct bucket_fubar *next;
} bucket;

bucket *table[TableSize];

/* Initializes every bucket in the hash table to be empty. */
void initsymboltable(void) {
	int i;
	for (i = 0; i < TableSize; i++) table[i] = NULL;
}

/* Calculates a hash value for the string based upon the first and
   last characters in the string.  If the string contains only one
   character, then it is used as both the first and last character.
*/
int hash(char *string) {
	return ( string[0] + string[strlen(string)-1] ) % TableSize;
}

/* Returns a pointer to the bucket in the hash table corresponding to
   the specified string and name type.  If none is found then NULL is 
   returned.
*/
bucket *findid(char *string, int name_type) {
	bucket *entry;
	entry = table[hash(string)];
	while (entry && (strcmp(string, entry->name)
				|| entry->attribute->field_name != name_type))
		entry = entry->next;
	return entry;
}

/* Returns true iff a string of name type already appears in the symbol 
   table. 
*/
boolean intable(char *string, int name_type) {
	if (findid(string, name_type))
		return true;
	else
		return false;
}

/* Deallocate the various parts of a hash table entry. */
void delete(bucket *entry) {
	/* Remove the old entry. */
	if (entry->attribute->address)
		myfree(entry->attribute->address);
	myfree(entry->attribute);
	myfree(entry);
}

/* Removes the identifier, string, of type name_type, and its associated 
   attribute from the symbol table.
*/
void removeid(char *string, int name_type) {
	if (intable(string, name_type)) {
		bucket *entry = table[hash(string)];

		if (strcmp(string, entry->name) == 0
	                && entry->attribute->field_name == name_type) {

			table[hash(string)] = entry->next;
			delete(entry);
		} else {
			bucket *tmp;

        		while (entry->next->next && 
				(strcmp(string, entry->next->name) || 
					entry->next->attribute->field_name != 
								name_type))
                		entry = entry->next;

			tmp = entry->next;
			entry->next = entry->next->next;
			delete(tmp);
		}
	}
}

/* Enters the identifier, string, into the symbol table along with
   its associated attribute, attr.  A copy of the string is made.
*/
void enterid(char *string, attr_rec attr) {
	bucket *entry;
	entry = findid(string, attr.field_name);
	/* If string is not present, then add it. */
	if (!entry) {
		int index;
		index = hash(string);
		entry = (bucket*) mymalloc(sizeof(bucket));
		entry->name = mymalloc(strlen(string) + 1);
		strcpy(entry->name, string);
		entry->attribute = (attr_rec*) mymalloc(sizeof(attr_rec));
		*(entry->attribute) = attr;
		entry->next = table[index];
		table[index] = entry;
	}
}

/* Returns the attribute associated with the specified string and name type. */
attr_rec *get_attribute(char *string, int name_type) {
	bucket *entry;
	entry = findid(string, name_type);
	if (entry) return entry->attribute;
	else return NULL;
}
