/* view.h
   Copyright (C) 1992, 1993, 1994, 1997, 1998, 1999  J Dana Eckart
  
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with CELLULAR; see the file COPYING.  If not, write to the 
   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <string.h>
#include "boolean.h"

#define MAX_STRING_SIZE	256
#define MAX_MAP_SIZE	256

/* Maximum width of the displayed cell field value or for all fields. */
extern int MAX_FIELD_VALUE_WIDTH;
extern int max_field_value;
extern int MAX_VALUE_WIDTH;
extern int max_value;

/* Maximum cell size for display. */
#define MAX_CELL_SIDE	256

/* Contains the current time. */
extern unsigned long int _time_step;

#if !COMBINED
/* Contains the next time at which to read data. */
extern long int next_time;
#else
/* Get the various time indicators from the automata. */
extern FILE *time_file;
extern unsigned long int report_time_step;
extern unsigned long int next_report_time;
extern long int next_read_time;
extern void get_report_time(FILE*);
#endif

/* Time to pause between time steps, in order to slow things down. */
extern long int pause_time;

/* The cellular universe which contains the colors/characters that
   are and correspond to the cell values which are read.
*/
typedef long int celltype;
extern celltype *cell_vals;
extern float *cell_float_vals;
typedef unsigned char maptype;
extern maptype *cell_map_vals;

/* The following variables are the lower and upper bounds of the
   dimensions to display.
*/
#define MAX_DIMS	256
extern int dim_given;
extern int range_dim_given, range_dim_1_index, range_dim_2_index, range_dim_3_index;
extern int lower[], upper[], range[];

/* Holds the number of character/color map entries given. */
extern long int max_map_entry;

extern void read_cell_block(void);
extern void read_map(char *, boolean);
extern void error(char *, char *);
extern maptype map_value(long int);
extern void exit_signaled(int);
extern void get_string_for_value(char *, celltype, boolean);
extern int file_size(char *);
extern int big_endian();

#if COMBINED

/* Needed for communication of output styles to the CA code. */
extern int output, view, filter;

#if MAX_CPUS > 1

extern void cellang_main(int, int, int, int, int);

extern void create_threads(void);

#if P_THREADS

#include <pthread.h>
extern pthread_mutex_t display_mutex;

#endif

extern unsigned char cpus;

#else

extern void cellang_main(int, int, int, int);

#endif

#endif

#if COMBINED
/* Get the number and names of the cell fields in support of the cell
   field examination window.
*/
extern char field_names[];
extern int field_name_length;
extern int field_count;
extern long int cell_field_value(int, int, int, int);
extern float cell_field_float_value(int, int, int, int);
#endif
extern boolean use_floats;
