/**
 * Simple implementation of the popular MineSweeper game that runs as both
 * an Applet (in the browser) as well as a standalone application.
 */

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.Box.*;

public class MineSweeper extends JApplet {
	private int GridWidth = 20;
	private int GridHeight = 10;
	private int MaxMines = 25;

	private final String GameReady = "Want to play? Click squares to start.";
	private final String GameOver_1 = "You lost. Click here to play again.";
	private final String GameOver_2 = "How did YOU win? Click here to play again.";

	// Primary UI components.
	//
	private MinePatch[][] mineField = new MinePatch[GridWidth][GridHeight];
	private Box gamePanel = createVerticalBox();
	private final JLabel minesRemaining = new JLabel();
	private final JButton gameStatus = new JButton();
	private final JLabel elapsedTime = new JLabel();
	private javax.swing.Timer timer = null;

	/**
         * Create the minefield withOUT any mines.
	 */
	private void createMineField() {
		// Create mine patches
		//
		for (int i = 0; i < GridWidth; i++) {
			for (int j = 0; j < GridHeight; j++) {
				mineField[i][j] = new MinePatch();
			}
		}

		// Let each patch know who its neighbors are.
		//
		for (int i = 0; i < GridWidth; i++) {
			for (int j = 0; j < GridHeight; j++) {
				MinePatch mp = mineField[i][j];
				if (i+1 < GridWidth && j+1 < GridHeight)
					mp.addNeighbor(mineField[i+1][j+1]);
				if (i+1 < GridWidth)
					mp.addNeighbor(mineField[i+1][j]);
				if (i+1 < GridWidth && j-1 >= 0)
					mp.addNeighbor(mineField[i+1][j-1]);
				if (j+1 < GridHeight)
					mp.addNeighbor(mineField[i][j+1]);
				if (j-1 >= 0)
					mp.addNeighbor(mineField[i][j-1]);
				if (i-1 >= 0 && j+1 < GridHeight)
					mp.addNeighbor(mineField[i-1][j+1]);
				if (i-1 >= 0)
					mp.addNeighbor(mineField[i-1][j]);
				if (i-1 >= 0 && j-1 >= 0)
					mp.addNeighbor(mineField[i-1][j-1]);
			}
		}
	}

	/**
         * Populate the minefield with mines.
	 */
	private void populateMineField() {
		// Make sure all the patches are (re)set.
		//
		for (int i = 0; i < GridWidth; i++) {
			for (int j = 0; j < GridHeight; j++) {
				mineField[i][j].reset();
			}
		}

		// Place mines randomly
		//
		Random random = new Random();
		int mineCount = MaxMines;
		while (mineCount > 0) {
			if (mineField[random.nextInt(GridWidth)][random.nextInt(GridHeight)].placeMine()) {
				mineCount--;
			}
		}

		// Redisplay the reset the number of flags too.
		//
		updateStatusBar();
	}

	/**
	 * Add actions for each minefield button
	 */
	private void setupMineFieldActions() {
		for (int i = 0; i < GridWidth; i++) {
		for (int j = 0; j < GridHeight; j++) {
			final MinePatch mp = mineField[i][j];
			mp.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					if (gameStatus.getText() == GameOver_1
						|| gameStatus.getText() == GameOver_2) {
						// Don't play more if they've
						// already lost. Need to reset
						// first.
						//
						return;
					} else if (gameStatus.getText() == GameReady) {
						// Indicate that they're now
						// playing once they've made
						// their first click.
						//
						gameStatus.setText("Playing...");
						startTimer();
					}

					// Flag, Mark, or Expose a patch.
					//
					if ((event.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
						mp.flag();
					} else if ((event.getModifiers() & ActionEvent.CTRL_MASK) == ActionEvent.CTRL_MASK) {
						mp.mark();
					} else {
						if (mp.expose()) {
							// Game Over!
							gameStatus.setText(GameOver_1);
							stopTimer();
						}
					}
					updateStatusBar();
				}
			});
		}}
	}

	/**
	 * Displays the number of flags placed and checks to see if the pesky
	 * human won.
	 */
	private void updateStatusBar() {
		minesRemaining.setText(
			String.valueOf(MaxMines - mineField[0][0].flagCount())
		);

		// Check to see if the human won the game.
		//
		if (mineField[0][0].flagCount() + mineField[0][0].exposedCount() == GridWidth*GridHeight) {
			gameStatus.setText(GameOver_2);
			stopTimer();
		}
	}

	/**
	 * Creates the GUI for MineSweeper. This wasn't included in the
	 * above init() method as the getParameter() calls are problematic
	 * when this is being run as an application.
	 */
	private void createGUI() {
		// Setup the minefield grid
		//
		createMineField();
		populateMineField();
		setupMineFieldActions();
		JPanel minePanel = new JPanel();
		minePanel.setLayout(new GridLayout(GridHeight, GridWidth));
		for (int j = 0; j < GridHeight; j++) {
			for (int i = 0; i < GridWidth; i++) {
				minePanel.add(mineField[i][j]);
			}
		}

		// Setup the instructions at the top of the game.
		//
		Box instructions = createHorizontalBox();
		instructions.add(createGlue());
		instructions.add(new JLabel(
			"shift + click (mark mine with flag !)"
		));
		instructions.add(createGlue());
		instructions.add(new JLabel(
			"ctrl + click (mark as uncertain ?)"
		));
		instructions.add(createGlue());
		instructions.add(new JLabel(
			"click (expose patch)"
		));
		instructions.add(createGlue());


		// Setup the stats (mines left, game status, elapsed time)
		//
		Box stats = createHorizontalBox();
		stats.add(minesRemaining);
		stats.add(createGlue());
		stats.add(gameStatus);
			gameStatus.setBorder(null);
			gameStatus.setBorderPainted(false);
		stats.add(createGlue());
		stats.add(elapsedTime);

		minesRemaining.setText(String.valueOf(MaxMines));
		gameStatus.setHorizontalAlignment(SwingConstants.LEFT);
		gameStatus.setText(GameReady);
		gameStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if (gameStatus.getText() == GameOver_1
					|| gameStatus.getText() == GameOver_2) {

					populateMineField();
					gameStatus.setText(GameReady);
					elapsedTime.setText("0:00");
				}
			}
		});
		elapsedTime.setHorizontalAlignment(SwingConstants.RIGHT);
		elapsedTime.setText("0:00");


		// Put the minefield and stats together
		//
		gamePanel.add(createGlue());
		gamePanel.add(instructions);
		gamePanel.add(createGlue());
		gamePanel.add(minePanel);
		gamePanel.add(createGlue());
		gamePanel.add(stats);
		gamePanel.add(createGlue());
	}

	/**
	 * Starts the timer to see how quick the player is.
	 */
	public void startTimer() {
		timer = new javax.swing.Timer(1000, new ActionListener() {
			private int seconds = 0;
			private int minutes = 0;
			public void actionPerformed(ActionEvent event) {
				seconds++;
				while (seconds >= 60) {
					minutes++;
					seconds -= 60;
				}
				elapsedTime.setText(minutes + ":"
						+ (seconds < 10 ? "0" : "")
						+ seconds);
			}
		});
		timer.start();
	}


	/**
	 * Stops the timer so the player can see how long they took.
	 */
	private void stopTimer() {
		timer.stop();
	}

	/**
	 * Called by the web browser when run as an Applet to perform the
	 * one-time initialization. This method typically contains the code
	 * that would normally go into a constructor. Keep this method short
	 * so that your applet can load quickly.
	 */
	public void init() {
		// Get and use any supplied parameters
		//
		String input = getParameter("gridWidth");
		if (input != null) GridWidth = Integer.parseInt(input);

		input = getParameter("gridHeight");
		if (input != null) GridHeight = Integer.parseInt(input);

		input = getParameter("maxMines");
		if (input != null) MaxMines = Integer.parseInt(input);

		createGUI();

		// Execute a job on the event-dispatching thread.
		//
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					add(gamePanel);
				}
			});
		} catch (Exception ex) {
			System.err.println("Error: Unable to launch applet.");
		}
	}

	/**
	 * Every applet that performs tasks after initialization (except in
	 * direct response to user actions) must override this method, which
	 * starts the execution of the applet. It is good practice to return
	 * quickly from the start method, using a new thread if you need to
	 * perform computationally intensive operations.
	 */
	public void start() {
		// Something might need to go here one day. :-)
	}

	/**
	 * Most applets that override the start method should also override
	 * this one. The stop method should suspend the applet's execution, so
	 * that it doesn't take up system resources when the user isn't
	 * viewing the applet's page.
	 */
	public void stop() {
		// Something might need to go here one day. :-)
	}

	/**
	 * First method called when run as a local program. Leverages the
	 * methods used by web browsers when run as an Applet so as not to
	 * duplicate code.
	 *
	 * @param argv is the standard list of command line arguments
	 */
	public static void main(String[] args) {
		MineSweeper game = new MineSweeper();

		// Get the command line arguments (if any).
		//
		if (args.length > 0) game.GridWidth = Integer.parseInt(args[0]);
		if (args.length > 1) game.GridHeight = Integer.parseInt(args[1]);
		if (args.length > 2) game.MaxMines = Integer.parseInt(args[2]);

		// Setup the game UI.
		//
		game.createGUI();

		JFrame frame = new JFrame();
		frame.add(game.gamePanel);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		game.start();
	}
}
