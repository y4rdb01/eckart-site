/**
 * Implements the patches (buttons) that make up the minefield.
 */
import java.util.*;
import java.awt.*;
import javax.swing.*;

class MinePatch extends JButton {
	// True iff a bomb is located in this patch of the minefield.
	//
	private boolean bomb = false;

	// True iff this patch has been exposed.
	//
	private boolean exposed = false;

	/**
	 * Creates a new minefield element.
	 */
	public MinePatch() {
		reset();
	}

	/**
	 * Set the patch so it's ready for a (new) game.
	 */
	public void reset() {
		bomb = false;
		exposed = false;
		setText(" ");
		setBackground(Color.LIGHT_GRAY);
		flagCount = 0;
		exposedCount = 0;
	}

	/**
	 * Place a mine in this patch.
	 *
	 * @return true iff the patch didn't already hold a mine/bomb.
	 */
	public boolean placeMine() {
		boolean result = bomb;
		bomb = true;
		return !result;
	}

	// List of neighbors (from 3 in the corners up to 8 elsewhere)
	// that "touch" this MinePatch.
	//
	ArrayList<MinePatch> neighborList = new ArrayList<MinePatch>();

	/**
	 * Add a neighbor for the current MinePatch.
	 */
	public void addNeighbor(MinePatch mp) {
		neighborList.add(mp);
	}

	/**
	 * Override to ensure that the patches of the minefield are square.
	 * @return the (square) Dimension of the minefield patch
	 */
	public Dimension getPreferredSize() {
		return new Dimension(43, 43);
	}

	// Keeps track of the current number of flags that have been placed.
	//
	private static int flagCount = 0;

	/**
	 * Returns the current number of placed flags.
	 *
	 * @return the number of flags that have currently been placed.
	 */
	public int flagCount() {
		return flagCount;
	}

	// Keeps track of the current number of exposed patches.
	//
	private static int exposedCount = 0;

	/**
	 * Returns the current number of exposed patches.
	 *
	 * @return the number of patches that have currently been exposed.
	 */
	public int exposedCount() {
		return exposedCount;
	}

	/**
	 * Exposes (uncovers) a patch in the minefield. If it's a bomb the
	 * game is over, otherwise the number of surrounding mines is shown
	 * as a digit count. If the count is 0, then the surrounding patches
	 * are automatically exposed as well.
	 */
	public boolean expose() {
		// No need to waste time re-exposing a patch.
		//
		if (exposed) return bomb;

		// Adjust the flag count
		//
		if (getText() == "!") flagCount--;

		exposedCount++;
		exposed = true;
		setBackground(Color.WHITE);

		if (bomb) {
			setText("*");
		} else {
			// Count the number of neighbors with mines/bombs.
			//
			int count = 0;
			for (MinePatch mp : neighborList) {
				if (mp.bomb) count++;
			}
			
			// Display the appropriate value for the current patch.
			//
			setText(count == 0 ? "-" : String.valueOf(count));

			// If the count = 0 then expose the neighbors too.
			//
			if (count == 0) for (MinePatch mp : neighborList) {
				mp.expose();
			}
		}
		return bomb;
	}

	/**
	 * Place a flag (indicating a mine) on a patch of the minefield, but
	 * don't expose it.
	 */
	public void flag() {
		// Don't flag something that's already been exposed.
		//
		if (exposed) return;

		// Adjust the flag count
		//
		if (getText() != "!") flagCount++;

		setBackground(Color.WHITE);
		setText("!");
	}

	/**
	 * Place a mark (possible mine) on a patch of the minefield, but
	 * don't expose it.
	 */
	public void mark() {
		// Don't mark something that's already been exposed.
		//
		if (exposed) return;

		// Adjust the flag count
		//
		if (getText() == "!") flagCount--;

		setBackground(Color.WHITE);
		setText("?");
	}
}
