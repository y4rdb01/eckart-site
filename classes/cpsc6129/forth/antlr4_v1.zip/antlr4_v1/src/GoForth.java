/*
	This is a simple driver program for the ANTLR4 generated parser.
*/
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class GoForth {
	public static void main(String[] args) throws IOException {
		// Read from standard input.
		ANTLRInputStream input = new ANTLRInputStream(System.in);

		// We need a lexer to tokenize the input.
		// NOTE: The "Forth" prefix comes from the "grammar" name
		// 	 given in the Forth.g4 file (which msut be the same
		//	 as the filename - minus the ".g4" extension).
		ForthLexer lexer = new ForthLexer(input);

		// Buffering tokens allows them to be "put back" for rereading.
		CommonTokenStream tokens = new CommonTokenStream(lexer);

		// The parser recognizes grammar sentences based on the tokens. 
		// NOTE: The "Forth" prefix comes from the "grammar" name
		// 	 given in the *.g4 file.
		ForthParser parser = new ForthParser(tokens);

		// Start parsing with the "expression" rule.
		ParseTree tree = parser.expression();

		// Print out the parse tree.
		System.out.print(tree.toStringTree(parser));
	}
}
