/*
	This is a simple driver class for the ANTLR4 generated parser.
*/
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class GoForth {
	/** The driver which feeds the input to the parser.
	*/
	public static void main(String[] args) throws IOException {
		// Check for parser/lexer flags.
		boolean goForthAlt = false;
		if (args.length > 0 && args[0].equals("-goForthAlt")) {
			goForthAlt = true;
		}

		// Read from standard input.
		ANTLRInputStream input = new ANTLRInputStream(System.in);

		// We need a lexer to tokenize the input.
		// NOTE: The "Forth" prefix comes from the "grammar" name
		// 	 given in the Forth.g4 file (which msut be the same
		//	 as the filename - minus the ".g4" extension).
		ForthLexer lexer = new ForthLexer(input);
		lexer.goForthAlt = goForthAlt;

		// Buffering tokens allows them to be "put back" for rereading.
		CommonTokenStream tokens = new CommonTokenStream(lexer);

		// The parser recognizes grammar sentences based on the tokens. 
		// NOTE: The "Forth" prefix comes from the "grammar" name
		// 	 given in the *.g4 file.
		ForthParser parser = new ForthParser(tokens);

		// Visit the parse tree using the StackInterpreter evaluator.
		StackInterpreter stack = new StackInterpreter();
		stack.enterStart();
		stack.visit(parser.start());
		stack.exitStart();
	}
}
