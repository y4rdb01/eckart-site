/*
	This is a simple driver class for the ANTLR4 generated parser.
*/
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class GoForth {
	/** The driver which feeds the input to the parser.
	*/
	public static void main(String[] args) throws IOException {
		// Print a welcome message for the interpreter.
		System.out.println("Welcome to goForth. Care to multiply?");
		System.out.println();

		// Read from standard input.
		ANTLRInputStream input = new ANTLRInputStream(System.in);

		// We need a lexer to tokenize the input.
		// NOTE: The "Forth" prefix comes from the "grammar" name
		// 	 given in the Forth.g4 file (which msut be the same
		//	 as the filename - minus the ".g4" extension).
		ForthLexer lexer = new ForthLexer(input);

		// Buffering tokens allows them to be "put back" for rereading.
		CommonTokenStream tokens = new CommonTokenStream(lexer);

		// The parser recognizes grammar sentences based on the tokens. 
		// NOTE: The "Forth" prefix comes from the "grammar" name
		// 	 given in the *.g4 file.
		ForthParser parser = new ForthParser(tokens);

		// Start parsing with the "expression" rule.
		ParseTree tree = parser.expression();

		// Create a generic parse tree walker that triggers callbacks
		// to the methods (e.g., enter*, exit*) in this class.
		ParseTreeWalker walker = new ParseTreeWalker();

		// Walk the parse tree to trigger the callbacks.
		walker.walk(new StackInterpreter(), tree);

		// Print a goodbye message from Forth.
		System.out.println();
		System.out.println("Thank you for using goForth.");
	}
}
