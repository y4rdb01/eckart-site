package main.scala

trait FileLoader {

  def getHeader(): List[String]
  def getRows(): List[List[String]]
  def disableHeader(): Unit

}
