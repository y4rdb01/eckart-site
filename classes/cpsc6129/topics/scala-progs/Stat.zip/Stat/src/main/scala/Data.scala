/** A class to hold rows of data and the methods to perfom statistical operations on them
  * Group Project CPSC 6129
  * Mark Ridings and Matthew Mayo
  */

package main.scala

import scala.collection.mutable.ListBuffer

class Data {

  private var header = List[String]()
  private var rows = List[List[String]]()

  def loadData(loader: FileLoader): Unit = {
    header = loader.getHeader()
    rows = loader.getRows()
  }

  def numColumns(): Int = {
    return header.length
  }

  def numRows(): Int = {
    return rows.length
  }

  def getHeader(): List[String] = {
    return header.toList
  }

  def getRow(n: Int): List[String] = {
    return rows(n)
  }

  def isEmpty(): Boolean = {
    rows.length == 0
  }

  def mean(columnName: String): Double = {
    val columnIndex = header.indexOf(columnName)

    val sum = rows.map(_(columnIndex).toDouble).sum

    sum / rows.length
  }

  def median(columnName: String): Double = {
    val columnIndex = header.indexOf(columnName)
    val values = rows.collect({case i: List[String] => i(columnIndex).toDouble }).sorted
    val middle = (values.length / 2) - 1

    if (values.length % 2 == 0)
      (values(middle) + values(middle + 1)) / 2
    else
      values(middle)
  }

  def mode(columnName: String): List[String] = {
    val columnIndex = header.indexOf(columnName)
    var modeList = new ListBuffer[String]()
    var maxInstance = 0

    val values = rows.collect({ case i: List[String] => i(columnIndex)})
    val uniqueItems = values.distinct

    for (item <- uniqueItems) {
      val count = values.count(_ == item)

      if (count > maxInstance) {
        modeList.clear()
        modeList += item
        maxInstance = count
      }
      else if (count == maxInstance)
        modeList += item
    }

    modeList.toList
  }

  def stdev(columnName: String): Double = {
    val columnIndex = header.indexOf(columnName)
    val sampleMean = mean(header(columnIndex))

    val deviationsSquared = rows.map(x => math.pow(x(columnIndex).toDouble - sampleMean,2))
    math.sqrt(deviationsSquared.sum / (deviationsSquared.length - 1))
  }

  // computes Pearson Correaltion Coeffecient
  def correl(columnNameX: String, columnNameY: String): Double = {
    val columnIndexX = header.indexOf(columnNameX)
    val columnIndexY = header.indexOf(columnNameY)
    val xMean = mean(header(columnIndexX))
    val yMean = mean(header(columnIndexY))

    val diffMean = rows.map(x => (x(columnIndexX).toDouble - xMean) * (x(columnIndexY).toDouble - yMean)).sum
    val diffxMeanSq = rows.map(x => math.pow(x(columnIndexX).toDouble - xMean, 2)).sum
    val diffyMeanSq = rows.map(x => math.pow(x(columnIndexY).toDouble - yMean, 2)).sum

    diffMean / ((math.sqrt(diffxMeanSq)*(math.sqrt(diffyMeanSq))))
  }

  // finds the Coeffecient of the Independent Variable in a Regression formula
  def independentVariable(columnNameX: String, columnNameY: String): Double = {
    val columnIndexX = header.indexOf(columnNameX)
    val columnIndexY = header.indexOf(columnNameY)
    val xMean = mean(header(columnIndexX))
    val yMean = mean(header(columnIndexY))

    val diffMean = rows.map(x => (x(columnIndexX).toDouble - xMean) * (x(columnIndexY).toDouble - yMean)).sum
    val diffxMeanSq = rows.map(x => math.pow(x(columnIndexX).toDouble - xMean, 2)).sum

    diffMean / diffxMeanSq
  }

  // finds the y-intercept of a Regression formula
  def yIntercept(columnNameX: String, columnNameY: String): Double = {
    val columnIndexX = header.indexOf(columnNameX)
    val columnIndexY = header.indexOf(columnNameY)
    val xMean = mean(header(columnIndexX))
    val yMean = mean(header(columnIndexY))
    val xCoeff = independentVariable(columnNameX, columnNameY)

    yMean - (xCoeff * xMean)
  }

  def varianceOfError(columnName: String): Double = {
    val columnIndex = header.indexOf(columnName)
    val sampleMean = mean(header(columnIndex))

    val diffMean = rows.map(x => math.pow(x(columnIndex).toDouble - sampleMean, 2)).sum

    diffMean / (rows.length - 2)
  }
  def SSE(columnNameX: String, columnNameY: String): Double = {
    val columnIndexX = header.indexOf(columnNameX)
    val columnIndexY = header.indexOf(columnNameY)
    val yMean = mean(columnNameY)
    val intercept = yIntercept(columnNameX, columnNameY)
    val indCoef = independentVariable(columnNameX, columnNameY)

    rows.map(x => math.pow((intercept + x(columnIndexX).toDouble * indCoef) - x(columnIndexY).toDouble, 2)).sum
  }

  def ANOVA(columnNameX: String, columnNameY: String): Unit = {
    val observations = rows.length
    val columnIndexX = header.indexOf(columnNameX)
    val columnIndexY = header.indexOf(columnNameY)
    val yMean = mean(columnNameY)
    val xMean = mean(columnNameX)
    val meanXY = (rows.map(x => x(columnIndexX).toDouble * x(columnIndexY).toDouble).sum) / observations
    val meanXsq = (rows.map(x => math.pow(x(columnIndexX).toDouble, 2)).sum) / observations
    val diffxMeanSq = rows.map(x => math.pow(x(columnIndexX).toDouble - xMean, 2)).sum
    val rSq = math.pow(correl(columnNameX, columnNameY),2)
    val intercept = yIntercept(columnNameX, columnNameY)
    val indCoef = independentVariable(columnNameX, columnNameY)
    val sse = SSE(columnNameX, columnNameY)
    val sst = rows.map(x => math.pow(x(columnIndexY).toDouble - yMean, 2)).sum
    val mse = sse / (observations - 2)
    val depStdev = math.sqrt(mse / diffxMeanSq)
    val indStdev = math.sqrt(mse * ((1.0 / observations) + (math.pow(xMean, 2) / diffxMeanSq)))
    val bHat = meanXY / meanXsq
    val sumDifXY = rows.map(x => (x(columnIndexX).toDouble - xMean)*(x(columnIndexY).toDouble - yMean)).sum
    val pointEstB1 = sumDifXY / diffxMeanSq
    val tStatB1 = pointEstB1 / (math.sqrt(mse / diffxMeanSq))
    val tStatB0 = intercept / indStdev
    val stdError = math.sqrt(mse)
    val table =
    f"""
        |R Square:       ${rSq}%.2f
        |Standard Error: ${stdError}%.2f
        |Observations:   ${observations}
        |__________________________
        |ANOVA
        |________________________________________________________________
        |${" "}%-15s ${"df"}%5s ${"SS"}%10s ${"MS"}%15s ${"F"}%15s
        |________________________________________________________________
        |${"Regression:"}%-15s ${"1"}%5s\t${sst-sse}%5.2f\t${sst-sse}%5.2f ${(sst-sse)/mse}%15.2f
        |${"Residual:"}%-15s ${observations-2}%5d\t${sse}%5.2f\t${mse}%5.2f
        |${"Total:"}%-15s ${observations-1}%5d\t${sst}%5.2f
        |________________________________________________________________
        |________________________________________________________________
        |${"Coeff"}%22s ${"Std Error"}%13s ${"t Stat"}%10s
        |${"Intercept"}%-15s ${intercept}%5.2f ${indStdev}%12.2f ${tStatB0}%10.2f
        |${columnNameX}%-15s ${indCoef}%5.2f ${depStdev}%12.2f ${tStatB1}%10.2f
        |________________________________________________________________
        |"""".stripMargin

    Console.out.print(table)
  }
}
