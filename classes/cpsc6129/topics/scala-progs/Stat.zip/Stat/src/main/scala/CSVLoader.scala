package main.scala

import scala.collection.mutable.ListBuffer
import scala.io.Source


class CSVLoader (fileName: String) extends FileLoader {

  private val file = Source.fromFile(fileName)
  private var data = ListBuffer.empty[List[String]]
  private var hasHeader = true

  for (line <- file.getLines()) {
    data += line.split(", *").toList.map(_.replaceAll("\"", ""))
  }
  file.close()

  override def getHeader(): List[String] = {
    if (hasHeader)
      data.head.toList
    else
      List.range(0, data(0).length).map(x => x.toString)
  }

  override def getRows(): List[List[String]] = {
    if (hasHeader)
      data.tail.toList
    else
      data.toList
  }

  override def disableHeader(): Unit = hasHeader = false
}
