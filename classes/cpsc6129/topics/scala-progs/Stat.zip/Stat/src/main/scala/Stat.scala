/** Program that performs various statistical operations
  * Group Project for CPSC 6129
  * Mark Ridings and Matthew Mayo
  */

package main.scala

import scala.collection.mutable.Map
import scala.io.Source
import scala.util.control.Breaks._

object Stat {

  val newDataSet = new Data
  var currentDataSet = new Data
  var currentDataSetName = ""
  var lineNumber = 1
  val data = Map[String, Data]()

  // Instantiate a concrete loader based on file name
  def createLoader(fileName: String): FileLoader = {

    if (fileName.endsWith(".csv")) {
      new CSVLoader(fileName)
    }
    else {
      new TXTLoader(fileName)
    }
  }

  def getDataFile(fileName: String) {
    try {
      Console.out.println("Loading file " + fileName)
      
      determineIfHasHeader(fileName)
      
      data += (fileName -> newDataSet)
      currentDataSet = newDataSet
      currentDataSetName = fileName
      Console.out.println("Successfully loaded file -> " + fileName)
      Console.out.println("file " + fileName + " is set to current")
    }
    catch {
      case e: Exception => {
        Console.err.println("Unable to load file -> " + fileName)
        Console.err.println(e.getMessage)
        Console.println("No data loaded into current dataset")
        Console.println("use the 'import' command to load a dataset")
      }
    }
    finally {
      Console.out.flush()
    }
  }

  //loads file appropriately depending on if it has head row or not
  def determineIfHasHeader(fileName: String) {
    breakable {
      while (true) {
        Console.out.println("Does " + fileName + " have a header row? (y/n) ")
        val choice = Console.in.readLine()

        if (choice.toLowerCase() == "y" || choice.toLowerCase() == "yes") {
          newDataSet.loadData(createLoader(fileName))
          break
        }
        else if (choice.toLowerCase() == "n" || choice.toLowerCase() == "no") {
          val loader = createLoader(fileName)
          loader.disableHeader()
          newDataSet.loadData(loader)
          break
        }
      }
    }
  }

  def validColumn(columnName: String): Boolean = {
    currentDataSet.getHeader().indexOf(columnName) != -1
  }

  def main(args: Array[String]): Unit = {

    Console.out.println("Welcome to STAT!")

    if (args.length > 0)
      getDataFile(args(0))
    else {
      Console.out.println("No file found in arguments, so no file loaded")
      Console.out.println("Use the 'import' command to load a dataset")
    }

    Console.out.print("[" + lineNumber + "]> ")

    breakable { for (ln <- Source.stdin.getLines()) {
      val cmd = ln.split(" +")
      if (cmd(0) == "quit") {
        val exit = true
        Console.out.println("Thanks for using Stat! Goodbye")
        break
      }
      if (cmd(0) == "current") {
        Console.out.println(" CURRENT DATASET IS -> " + currentDataSetName)
      }
      else if (cmd(0) == "import") {
        if (cmd.length > 1)
          getDataFile(cmd(1))
        else
          Console.out.println("NO FILE NAME FOUND, FILE NAME REQUIRED WITH IMPORT")
      }
      else if (currentDataSet.isEmpty()) {
        Console.out.println(" CURRENT DATASET IS EMPTY -> Use 'import' or 'use' to set a dataset")
      }
      else if (cmd(0) == "head") {
        Console.out.println(currentDataSet.getHeader())
      }
      else if (cmd(0) == "mean") {
        if (cmd.length > 1 && validColumn(cmd(1)))
          Console.out.println("--> " + currentDataSet.mean(cmd(1)))
        else
          Console.out.println(" MISSING OR UNKNOWN COLUMN ")
      }
      else if (cmd(0) == "median") {
        if (cmd.length > 1 && validColumn(cmd(1)))
          Console.out.println("--> " + currentDataSet.median(cmd(1)))
        else
          Console.out.println(" MISSING OR UNKNOWN COLUMN ")
      }
      else if (cmd(0) == "mode") {
        if (cmd.length > 1 && validColumn(cmd(1)))
          Console.out.println("--> " + currentDataSet.mode(cmd(1)))
        else
          Console.out.println(" MISSING OR UNKNOWN COLUMN ")
      }
      else if (cmd(0) == "stdev") {
        if (cmd.length > 1 && validColumn(cmd(1)))
          Console.out.println("--> " + currentDataSet.stdev(cmd(1)))
        else
          Console.out.println(" MISSING OR UNKNOWN COLUMN ")
      }
      else if (cmd(0) == "correl") {
        if (cmd.length > 2 && validColumn(cmd(1)) && validColumn(cmd(2))) {
          Console.out.println("--> " + currentDataSet.correl(cmd(1), cmd(2)))
        }
        else
          Console.out.println(" MISSING OR UNKNOWN COLUMN")
      }
      else if (cmd(0) == "anova") {
        if (cmd.length > 2 && validColumn(cmd(1)) && validColumn(cmd(2))) {
          currentDataSet.ANOVA(cmd(1), cmd(2))
        }
        else
          Console.out.println(" MISSING OR UNKNOWN COLUMN")
      }
      else {
        Console.out.println(" UNKNOWN COMMAND -> " + cmd(0))
      }

      lineNumber += 1
      Console.print("[" + lineNumber + "]> ")

    } }

  }


}
