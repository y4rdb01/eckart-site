package test.scala

import main.scala.{TXTLoader, CSVLoader, Data}
import org.scalatest.{Matchers, FunSuite}

import java.io.IOException

class DataSuite extends FunSuite with Matchers {

  val csvData = new Data
  val txtData = new Data
  val noHeaderData = new Data
  val noHeaderText = new Data
  val cardinals = new Data

  test ("Successfully opens a csv file") {

    try {
      val loader = new CSVLoader("testData/testData.csv")
      csvData.loadData(loader)
    }
    catch {
      case e: IOException => {
        fail("File failed to load: " + e.toString())
      }
    }
  }

  test ("Successfully opens a text file") {
    try {
      val loader = new TXTLoader("testData/testData")
      txtData.loadData(loader)
    }
    catch {
      case e: IOException => {
        fail ("File failed to load: " + e.toString())
      }
    }
  }

  test ("Successfully add a header row to a csv file") {
    assert(csvData.numColumns() == 5, " | Header is wrong size")
    assert(csvData.getHeader() == List("A", "B", "C", "D", "E"), " | Headers don't match")
  }

  test ("Successfully add a header row to a text file") {
    assert(txtData.numColumns() == 4, " | Header is wrong size")
    assert(txtData.getHeader() == List("Name","Age", "Score", "Grade"), " | Headers don't match")
  }

  test("Successfully add rows to a csv file") {
    assert(csvData.numRows == 4, " | Number of rows is wrong")
    assert(csvData.getRow(0) == List("45","34","11","13","17"), " | First Rows don't match")
    assert(csvData.getRow(1) == List("3","4","6","4","2"), " | Second Rows don't match")
    assert(csvData.getRow(2) == List("100","12","11","17","19"), " | Third Rows don't match")
  }

  test("Successfully add rows to text file") {
    assert(txtData.numRows == 3, " | Number of rows is wrong")
    assert(txtData.getRow(0) == List("Mark", "40", "98", "A"))
    assert(txtData.getRow(1) == List("Mike", "38", "76", "C"))
    assert(txtData.getRow(2) == List("Matt", "37", "66", "D"))
  }

  test("Successfully load csv file without a header row") {
    try {
      val loader = new CSVLoader("testData/testData.csv")
      loader.disableHeader()
      noHeaderData.loadData(loader)
    }
    catch {
      case e: IOException => {
        fail("File failed to load " + e.toString())
      }
    }

    assert(noHeaderData.getHeader() == List("0", "1", "2", "3", "4"))
    assert(noHeaderData.getRow(0) == List("A", "B", "C", "D", "E"), " | Should be first row")
  }

  test("Successfully load text file without a header row") {
    try {
      val loader = new TXTLoader("testData/testData")
      loader.disableHeader()
      noHeaderText.loadData(loader)
    }
    catch {
      case e: IOException => {
        fail("File failed to load " + e.toString())
      }
    }

    assert(noHeaderText.getHeader() == List("0", "1", "2", "3"))
    assert(noHeaderText.getRow(0) == List("Name","Age", "Score", "Grade"), " | Should be first row")
  }

  test("Successfully compute the mean of a column") {
    val loader = new CSVLoader("testData/cardinals.csv")
    cardinals.loadData(loader)

    cardinals.mean("HR") should equal (7.43 +- 0.01)
  }

  test("Successfully compute the median of a column") {
    cardinals.median("HR") should equal (5.5 +- 0.01)
  }

  test("Successfully compute the mode of a column") {
    assert(cardinals.mode("HR") == List("3"))
    assert(csvData.mode("C") == List("11", "6"))
  }

  test("Successfully compute the sample standard deviation of a column") {
    cardinals.stdev("HR") should equal (7.035 +- 0.001)
  }

  test("Successfully compute the correlation coefficient of two columns") {
    cardinals.correl("HR", "RBI") should equal (.912 +- 0.001)
  }

  test("Successfully compute the coefficient of the independent variable") {
    cardinals.independentVariable("HR", "PA") should equal (22.799 +- 0.001)
  }
  test("Successfully compute the y-intercept of the regression formula") {
    cardinals.yIntercept("HR", "PA") should equal (223.848 +- 0.001)
  }

  test("Successfully compute the variance of the errors") {
    cardinals.varianceOfError("PA") should equal (42981.363 +- 0.001)
  }

}
