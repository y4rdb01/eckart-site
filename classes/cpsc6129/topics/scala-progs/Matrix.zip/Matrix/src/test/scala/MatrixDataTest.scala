package test.scala

import java.io.IOException
import main.scala.MatrixData
import org.scalatest.{FunSuite, Matchers}

import scala.collection.mutable.ListBuffer


class MatrixDataTest extends FunSuite with Matchers {

  private val fileNameA = "testData/testMatrixA"
  private val fileNameB = "testData/testMatrixB"
  private val fileNameC = "testData/testMatrixC"
  private val fileNameD = "testData/testMatrixD"
  private val fileNameE = "testData/testMatrixE"
  private val fileNameF = "testData/testMatrixF"
  private val fileNameAplusB = "testData/testMatrixAplusB"
  private val fileNameAminusB = "testData/testMatrixAminusB"
  private val fileNameAtimes5 = "testData/testMatrixAtimes5"
  private val augmentedFile = "testData/testAugmented"
  private val testInverse = "testData/testInverse"
  private val fileReduce = "testData/testReduce"
  private val noInverse = "testData/testNoInverse"
  private val badSizeFile = "testData/testBadSizeMatrix"
  private val fileMultA = "testData/testMultA"
  private val fileMultB = "testData/testMultB"
  private val fileMultAnswer = "testData/testMultAnswer"
  private val fileMult4A = "testData/testMult4A"
  private val fileMult4B = "testData/testMult4B"
  private val fileMult4Ans = "testData/testMult4Answer"
  private val fileInd4 = "testData/test4Identity"

  test ("Successfully load a Matrix file into a Matrix object") {

    val expected = "1.00 2.00 5.00\n3.00 5.00 2.00\n6.00 5.00 3.00\n"

    try {

      val A = new MatrixData()
      A.load(fileNameA)

      assert(A.toString() == expected)
    }
    catch {
      case e: IOException => {
        fail("file failed to load: " + e.toString())
      }
      case a: Exception => {
        fail("other exception: " + a.toString)
      }
    }
  }

  test ("You can successfully create a new Matrix object from a ListBufferObject") {
    var matrixAsList = ListBuffer.empty[List[Double]]
    matrixAsList += List(2, 3, 5, 4)
    matrixAsList += List(-1, 3, 5, 7)
    matrixAsList += List(-9, 4, 3, 0)

    val A = new MatrixData(matrixAsList)

    assert(A.numColumns() == 4)
    assert(A.numRows() == 3)
    assert(A.getRow(2) == List(-9, 4, 3, 0))
    assert(A.getColumn(1) == List(3, 3, 4))
  }

  test ("You can not load a matrix file into an already instantiated Matrix") {
    var matrixAsList = ListBuffer.empty[List[Double]]
    matrixAsList += List(2, 3, 5, 4)
    matrixAsList += List(-1, 3, 5, 7)
    matrixAsList += List(-9, 4, 3, 0)

    val A = new MatrixData(matrixAsList)

    try {
      A.load(fileNameA)
      fail("This should have thrown exception")
    }
    catch {
      case e: InstantiationException => {
        assert(true)
      }
      case i: Exception => {
        fail("Wrong exception -> " + i.toString)
      }
    }
  }

  test ("You can successfully access a specific element in the Matrix") {
    val A = new MatrixData()
    A.load(fileNameA)
    A.getCell(1, 2) should equal (2.0 +- 0.001)
  }

  test ("You can successfully access a specific row in the Matrix" ) {
    val A = new MatrixData()
    A.load(fileNameA)
    assert(A.getRow(2) == List(6.0, 5.0, 3.0))
  }

  test ("You can successfully access a specific column in the Matrix") {
    val A = new MatrixData()
    A.load(fileNameA)
    assert (A.getColumn(1) == List(2.0, 5.0, 5.0))
  }

  test ("You can successfully get the number of rows") {
    val A = new MatrixData()
    A.load(fileNameC)
    assert (A.numRows() == 3)
  }

  test ("You can successfully get the number of columns") {
    val A = new MatrixData()
    A.load(fileNameC)
    assert (A.numColumns() == 4)
  }

  test ("Successfully add two matrices") {
    val A = new MatrixData()
    val B = new MatrixData()
    val C = new MatrixData()
    A.load(fileNameA)
    B.load(fileNameB)
    C.load(fileNameAplusB)

    assert(A + B == C)
  }

  test ("Throw exception if trying to add matrices of different sizes") {
    val A = new MatrixData()
    val B = new MatrixData()
    A.load(fileNameA)
    B.load(fileNameD)

    try {
      A + B
      fail ("should have thrown exception")
    }
    catch {
      case e: IllegalArgumentException => {
        assert (true)
      }
      case i: Exception => {
        fail("Wrong exception was thrown")
      }
    }
  }

  test ("Successfully subtract two matrices") {
    val A = new MatrixData()
    val B = new MatrixData()
    val C = new MatrixData()
    A.load(fileNameA)
    B.load(fileNameB)
    C.load(fileNameAminusB)

    assert(A - B == C)
  }

  test ("Throw exception if trying to sub matrices of different sizes") {
    val A = new MatrixData()
    val B = new MatrixData()
    A.load(fileNameA)
    B.load(fileNameD)

    try {
      A - B
      fail ("should have thrown exception")
    }
    catch {
      case e: IllegalArgumentException => {
        assert (true)
      }
      case i: Exception => {
        fail("Wrong exception was thrown")
      }
    }
  }

  test ("Successfully conduct scalar multiplication") {
    val A = new MatrixData()
    val B = new MatrixData()
    A.load(fileNameA)
    B.load(fileNameAtimes5)

    assert(A * 5 == B)
  }

  test ("Successfully swap rows in the matrix") {
    val A = new MatrixData()
    A.load(fileNameA)
    A.swapRows(0, 2)

    assert(A.getRow(0) == List(6.0, 5.0, 3.0))
    assert(A.getRow(2) == List(1.0, 2.0, 5.0))

  }

  test ("Successfully multiply a row by a scalar") {
    val A = new MatrixData()
    A.load(fileNameA)
    A.multiplyRowBy(0, 2)
    A.multiplyRowBy(2, 1.0/3.0)

    assert(A.getRow(0) == List(2.0, 4.0, 10.0))
    A.getRow(2)(0) should equal (2.0 +- 0.01)
    A.getRow(2)(1) should equal (1.67 +- 0.01)
    A.getRow(2)(2) should equal (1.0 +- 0.01)
  }

  test ("Successfully add two rows together and return the new row") {
    val A = new MatrixData()
    A.load(fileNameA)
    val newRow = A.addRows(0, 2)

    assert(newRow == List(7.0, 7.0, 8.0))
  }

  test ("Use the Gauss-Jordan method to reduce a matrix") {
    val A = new MatrixData()
    val E = new MatrixData()
    val R = new MatrixData()

    R.load(fileReduce)
    A.load(fileNameD)
    A.reduce()

    A.getRow(0)(0) should equal (1.0 +- 0.01)
    A.getRow(0)(1) should equal (0.0 +- 0.01)
    A.getRow(0)(2) should equal (2.0 +- 0.01)

    A.getRow(1)(0) should equal (0.0 +- 0.01)
    A.getRow(1)(1) should equal (1.0 +- 0.01)
    A.getRow(1)(2) should equal (1.0 +- 0.01)

    E.load(fileNameE)
    E.reduce()

    E.getRow(0)(0) should equal (1.0 +- 0.01)
    E.getRow(0)(1) should equal (0.0 +- 0.01)
    E.getRow(0)(2) should equal (0.0 +- 0.01)
    E.getRow(0)(3) should equal (1.0 +- 0.01)

    E.getRow(1)(0) should equal (0.0 +- 0.01)
    E.getRow(1)(1) should equal (1.0 +- 0.01)
    E.getRow(1)(2) should equal (0.0 +- 0.01)
    E.getRow(1)(3) should equal (4.0 +- 0.01)

    E.getRow(2)(0) should equal (0.0 +- 0.01)
    E.getRow(2)(1) should equal (0.0 +- 0.01)
    E.getRow(2)(2) should equal (1.0 +- 0.01)
    E.getRow(2)(3) should equal (-2.0 +- 0.01)

    assert(E == R)
  }

  test ("Throw exception when trying to reduce wrong size matrix") {
    val A = new MatrixData()
    A.load(badSizeFile)

    try {
      A.reduce()
      fail ("Should have thrown exception")
    }
    catch {
      case e: Exception => {
        assert (true)
      }
    }
  }

  test ("Make an augmented matrix") {
    val A = new MatrixData()
    val C = new MatrixData()
    A.load(fileNameA)
    C.load(augmentedFile)

    val B = A.returnAugmented()

    assert(B == C)
  }

  test ("Find the inverse of a n x n matrix") {
    val A = new MatrixData()
    val B = new MatrixData()

    A.load(fileNameF)
    B.load(testInverse)

    val I = A.inverse()

    assert (I == B)
  }

  test ("Throw Exception if inverse does not exist") {
    val A = new MatrixData()
    A.load(noInverse)

    try {
      A.inverse()
      fail("Should have thrown exception")
    }
    catch {
      case e: Exception => {
        assert (true)
      }
    }
  }

  test ("Throw Exception trying to find inverse of non square matrix") {
    val A = new MatrixData
    A.load(fileNameA)

    try {
      A.inverse()
      fail("Should have thrown an exception, not n x n")
    }
    catch {
      case e: Exception => {
        assert (true)
      }
    }
  }

  test ("Throw Exception if trying to multiply two matrices of the wrong size") {
    val A = new MatrixData()
    val B = new MatrixData()
    A.load(fileNameA)
    B.load(fileNameD)

    try {
      A * B
      fail("should have thrown exception")
    }
    catch {
      case e: IllegalArgumentException => {
        assert(true)
      }
      case i: Exception => {
        fail("threw wrong exception")
      }
    }
  }

  test ("Successfully multiply two matrices") {
    val A = new MatrixData()
    val B = new MatrixData()
    val C = new MatrixData()
    val X = new MatrixData()
    val Y = new MatrixData()
    val Z = new MatrixData()
    val I = new MatrixData()
    val AA = new MatrixData()

    A.load(fileMultA)
    B.load(fileMultB)
    C.load(fileMultAnswer)
    X.load(fileMult4A)
    Y.load(fileMult4B)
    Z.load(fileMult4Ans)
    I.load(fileInd4)

    assert (A * B == C)
    assert (X * Y == Z)
    assert (X * X.inverse() == I)
  }
}


