
/** A Matrix class that hold matrix data and logic for performing operations
 *  Group Project CPSC 6129
 *  Mark Ridings and Matthew Mayo
 */

package main.scala

import scala.collection.mutable.ListBuffer
import scala.io.Source
import java.lang.IllegalArgumentException

class MatrixData (data: ListBuffer[List[Double]]) {

  def this() {
    this(ListBuffer.empty[List[Double]])
  }

  // load data information from a Matrix file (matrix file must be comma seperated)
  def load(fileName: String): Unit = {

    if (!data.isEmpty)
      throw new InstantiationException("Matrix has all ready been initialized")

    val file = Source.fromFile(fileName)

    for (line <- file.getLines())
      data += line.trim.split(", *").toList.map(x => x.toDouble)
  }

  override def toString(): String = {
    var m = ""
    data.foreach(row => { row.foreach(i => m += f"$i%.2f "); m = m.trim; m += "\n" } )
    m
  }

  def getCell(row: Int, column: Int): Double = {
    data(row)(column)
  }

  def getRow(row: Int): List[Double] = {
    data(row)
  }

  def getColumn(column: Int): List[Double] = {
    data.map(x => x(column)).toList
  }

  def numRows(): Int = {
    data.length
  }

  def numColumns(): Int = {
    data(0).length
  }

  def swapRows(row1: Int, row2: Int): Unit = {
    val aux = getRow(row1)
    data(row1) = data(row2)
    data(row2) = aux
  }

  def multiplyRowBy(row: Int, num: Double): Unit = {
    data(row) = data(row).map(x => x * num)
  }

  def addRows(row1: Int, row2: Int): List[Double] = {
    (data(row1), data(row2)).zipped.map(_ + _)
  }

  // reduce a matrix to row echelon form, or throw an exception if it can't
  def reduce(): Unit = {

    if (numRows() > numColumns())
      throw new Exception("Can not reduce a matrix of size -> " + numRows() + " x " + numColumns())

    for (currentRowNum <- 0 until data.length) {
      if (getCell(currentRowNum, currentRowNum) == 0)
        if (currentRowNum == data.length - 1)
          throw new Exception("Matrix can not be put in row echelon form")
        else
          swapRows(currentRowNum, currentRowNum+1)

      multiplyRowBy(currentRowNum, 1.0 / data(currentRowNum)(currentRowNum))

      for (otherRowNum <- 0 until data.length)
        if (otherRowNum != currentRowNum) {
          val aux = getRow(currentRowNum).map(x => x * data(otherRowNum)(currentRowNum))
          data(otherRowNum) = (data(otherRowNum), aux).zipped.map(_ - _)
        }
    }
  }

  // creates an augmented matrix (matrix with identity add to its right side
  def returnAugmented():MatrixData = {
    if (numColumns() != numRows())
      throw new Exception("Matrix must be n x n")

    var newMatrix = ListBuffer.empty[List[Double]]

    for (rowNumber <- 0 until numRows())
      newMatrix += getRow(rowNumber):::List.range(0, numColumns()).map(x => if (x == rowNumber) 1.toDouble else 0.toDouble)

    new MatrixData(newMatrix)
  }

  // get the right side of the matrix
  private def getBackOfMatrix():MatrixData = {

    val newMatrix = data.map(x => x.slice(numColumns() / 2, numColumns()))

    new MatrixData(newMatrix)
  }

  def inverse():MatrixData = {
    val aux = returnAugmented()

    try {
      aux.reduce()
    }
    catch {
      case e: Exception => {
        throw new Exception("Matrix does not have inverse")
      }
    }
    aux.getBackOfMatrix()
  }

  def ==(that: MatrixData): Boolean = {
    if ( (this.numRows() != that.numRows()) || (this.numColumns() != that.numColumns()) )
      return false

    for (i <- 0 until this.numRows())
      if ((this.getRow(i), that.getRow(i)).zipped.map((x, y) => if (x-y > 0.01) 1 else 0).sum !=0)
        return false

    true
  }

  def +(that: MatrixData): MatrixData = {
    if ( (this.numRows() != that.numRows()) || (this.numColumns() != that.numColumns()) )
      throw new IllegalArgumentException("Matrices must have same number of lengths and rows")

    var newMatrix = ListBuffer.empty[List[Double]]

    for (i <- 0 until this.numRows())
      newMatrix += (this.getRow(i), that.getRow(i)).zipped.map(_ + _)

    new MatrixData(newMatrix)
  }

  def -(that: MatrixData): MatrixData = {
    if ( (this.numRows() != that.numRows()) || (this.numColumns() != that.numColumns()) )
      throw new IllegalArgumentException("Matrices must have same number of lengths and rows")

    var newMatrix = ListBuffer.empty[List[Double]]

    for (i <- 0 until this.numRows())
      newMatrix += (this.getRow(i), that.getRow(i)).zipped.map(_ - _)

    new MatrixData(newMatrix)
  }

  def *(that: MatrixData):MatrixData = {
    if (this.numColumns() != that.numRows())
      throw new IllegalArgumentException("Unable to multiply matrices of that size")

    var newRow = ListBuffer.empty[Double]
    var newMatrix = ListBuffer.empty[List[Double]]

    for (row <- 0 until this.numRows()) {
      for (column <- 0 until that.numColumns())
        newRow += (this.getRow(row), that.getColumn(column)).zipped.map(_ * _).sum
      newMatrix += newRow.toList
      newRow.clear()
    }

    new MatrixData(newMatrix)
  }

  def *(that: Double): MatrixData = {

    var newMatrix = ListBuffer.empty[List[Double]]

    for (i <- 0 until this.numRows())
      newMatrix += this.getRow(i).map(x => x * that)

    new MatrixData(newMatrix)
  }

}
