/** A program for performing Matrix Arithmetic
  * Group Project CPSC 6129
  * Mark Ridings and Matthew Mayo
  */

package main.scala

import scala.collection.mutable.Map
import java.io.IOException

import scala.io.Source
import scala.util.control.Breaks._

object Matrix {

  private val matrices:Map[String, MatrixData] = Map()
  private var lineNumber = 1

  private def loadArgFiles(args: Array[String]): Unit ={

    for (arg <- args) {
      val aux = new MatrixData()

      try {
        aux.load(arg)
        matrices += (getMatrixName(arg) -> aux)
        Console.out.println("File " + arg + " loaded as Matrix: " + getMatrixName(arg))
      }
      catch {
        case io: IOException => {
          Console.out.println("Unable to load filename -> " + arg)
          Console.out.println("Msg -> " + io)
        }
        case ie: InstantiationException => {
          Console.out.println("Unable to load filename -> " + arg)
          Console.out.println("Msg -> " + ie)
        }
        case e: Exception => {
          Console.out.println("Unable to load filename -> " + arg)
          Console.out.println("Msg -> " + e)
        }
      }
    }
  }

  private def getMatrixName(fileName: String): String = {

    // if file name has extension, name should not include extension
    if (fileName.indexOf(".") == -1)
      fileName
    else
      fileName.slice(0, fileName.indexOf("."))
  }

  private def renameMatrix(currentName: String, newName: String): Unit = {

    if (!matrices.contains(currentName))
      throw new Exception("Matrix -> " + currentName + " not found")
    else if (matrices.contains(newName))
      throw new Exception("Matrix " + newName + " already exists please reenter command with a different name ")
    else {
      val aux = matrices(currentName)
      matrices -= currentName
      matrices += (newName -> aux)
      Console.out.println("Matrix -> " + currentName + " renamed to -> " + newName)
    }

  }

  private def isDouble(n: String): Boolean = {
    try {
      n.toDouble
      true
    }
    catch {
      case e: Exception => {
        false
      }
    }
  }

  private def parseCmd(matrixName: String): MatrixData = {

    //Determine if trying to find an inverse and if matrix exists in Map
    if (matrixName.endsWith("-"))
      if (matrices contains matrixName.slice(0, matrixName.length() - 1))
        matrices(matrixName.slice(0, matrixName.length() - 1)).inverse()
      else
        throw new Exception("Matrix " + matrixName.slice(0, matrixName.length()) + " not found")
    else
      if (matrices contains matrixName)
        matrices(matrixName)
      else
        throw new Exception("Matrix " + matrixName.slice(0, matrixName.length()) + " not found")
  }

  def main(args: Array[String]): Unit = {

    Console.println("Welcome to Matrix!")
    if (args.length > 0)
      loadArgFiles(args)
    else
      Console.out.println("No file names found on loading.  Use 'import' command to load a matrix")

    Console.out.print("["+lineNumber+"]"+"> ")

    // start the REPL
    breakable {
      // keep reading input lines until quit is found
      for (ln <- Source.stdin.getLines()) {
        val cmd = ln.split(" +")

        if (cmd.length > 0)
          if (cmd(0) == "quit")
            break;
          else if (cmd(0) == "import") {
            if (cmd.length == 2)
              loadArgFiles(cmd.slice(1, 2))
            else
              Console.out.println("Import only takes 1 argument, that of a matrix filename")
          }
          else if (cmd(0) == "rename") {
            if (cmd.length == 3)
              try {
                renameMatrix(cmd(1), cmd(2))
              }
              catch {
                case e: Exception => {
                  Console.println(e.getMessage())
                }
              }
            else
              Console.out.println("rename requires two arguments, currentName and newName")
          }
          else if (cmd(0) == "+") {
            if (cmd.length == 3) {
              try {
                val firstMatrix = parseCmd(cmd(1))
                val secondMatrix = parseCmd(cmd(2))
                Console.out.println(firstMatrix + secondMatrix)
              }
              catch {
                case e: Exception => {
                  Console.out.println(e.getMessage())
                }
              }
            }
            else
              Console.out.println("Addition requires two matrices")
          }
          else if (cmd(0) == "-") {
            if (cmd.length == 3) {
              try {
                val firstMatrix = parseCmd(cmd(1))
                val secondMatrix = parseCmd(cmd(2))
                Console.out.println(firstMatrix - secondMatrix)
              }
              catch {
                case e: Exception => {
                  Console.out.println(e.getMessage())
                }
              }
            }
            else
              Console.out.println("Subtraction requires two matrices")
          }
          else if (cmd(0) == "*") {
            if (cmd.length == 3) {
              try {
                if (isDouble(cmd(1)))
                  Console.out.println(parseCmd(cmd(2)) * cmd(1).toDouble)
                else
                  Console.out.println(parseCmd(cmd(1)) * parseCmd(cmd(2)))
              }
              catch {
                case e: Exception => {
                  Console.out.println(e.getMessage())
                }
              }
            }
            else
              Console.out.println("Multiplication requires two matrices or a scalar and a matrix")
          }
          else if (cmd.length == 1) {
            try {
              Console.out.println(parseCmd(cmd(0)))
            }
            catch {
              case e: Exception => {
                Console.out.println(e.getMessage())
              }
            }
          }
          else {
            Console.out.println("Command -> " + cmd(0) + " not understood")
          }

        lineNumber += 1
        Console.out.print("["+lineNumber+"]"+"> ")

      } }

    Console.out.println("Thank you for using Matrix!")
  }

}
