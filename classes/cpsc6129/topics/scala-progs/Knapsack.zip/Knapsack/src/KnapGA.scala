/**
  *	Provides best found solution to knapsack problem using a genetic algorithm.
  *	Problem parameters are set via collected user input. Results output to
  * <output_file> in same directory. Outputs graph of optimal fitness by 
  * generation.
  *	
  *	Compile with: scalac KnapGA.scala
  *	Execute with: scala KnapGA <output_file>
  *   
  *	@author <A HREF="mailto:mayo_matthew@columbusstate.edu">Matthew Mayo and Mark Ridings</A>
  *	@version $Revision: 0.1 $ $Date: 2014/11/13 $
  */

import java.io._
import scala.collection.mutable.ArrayBuffer


/**
  * A simple structure to hold input data passed between classes.
  *
  * @param items Number of items in knapsack problem
  * @param popSize Number of populations per generation for genetic breeding
  * @param maxGens Maximum number of generations for genetic breeding
  * @param capacity Capacity of knapsack, in weight
  * @param probCross Probability of crossover (vs. cloning) during breeding
  * @param values Array of knapsack problem item values
  * @param weights Array of knapsack problem item weights
  * @param writer Output file writer for solution summary
  * @param genBestFit Java ArrayList of generational best fitness scores
  */
class knapStruct(val items:Int, val popSize:Int, val maxGens:Int,
	val capacity:Int, val probCross: Double, val values: Array[Int], 
	val weights: Array[Int], val writer: PrintWriter,
	var genBestFit: java.util.ArrayList[java.lang.Double]) { }


/**
  * A simple structure to hold data passed to PopulationItem.
  *
  * @param prevChromos Array of previous generation's chromosomes by population
  * @param prevFitness Array of previous generation's fitnesses by population
  * @param prevMeanFitness Mean fitness score of previous generation
  */
class popStruct(val prevChromos: Array[String], 
	val prevFitness: Array[Double], val prevMeanFitness: Double) { }


/** 
  * A single population item in a generation.
  *	Creates 'items' number of chromosomes, computes their fitness score. 
  *
  * @param inputData Structure holding user input data
  * @param popData Structure holding data passed from Generation
  * @param genCount Current generation
  */
class PopulationItem(val inputData: knapStruct, val popData: popStruct,
	var genCount: Int) {

	// Build chromosome, assess its fitness score.
	val chromosome: String = buildChromosome()
	val fitness: Double = getFitness(chromosome)

	/**
	  * PopulationElement toString.
	  *
	  * @return String representation of PopulationElement object
	  */
	override def toString: String =	
		return chromosome + " - " + fitness

	/** 
	  * Build a chromosome, one gene at a time.
	  *
	  * @return Chromosome string
	  */
	def buildChromosome(): String = {

		// Check if this is first generation. If so, random populations.
		if (genCount == 1) {
			var chromo: StringBuilder = new StringBuilder(inputData.items)
			var gene: Char = '0'
			for (i <- 0 to (inputData.items - 1)) {
				gene = '0'
				var rand: Double = Math.random
				if (rand > 0.5)
					gene = '1'
				chromo.append(gene)
			}
			return chromo.toString
		}

		// If not first generation, breed via crossover or cloning.
		else {

			// Select a pair of chromosomes to use for breeding.
			val chromo1 = selectChromosome
			val chromo2 = selectChromosome

			var rand: Double = Math.random

			/** Compare random num to probCross to determine if breeding will
				occur via crossover or cloning; proceed accordingly. */

			// Perform crossover.
			if (rand < inputData.probCross) {
				var crossPoint: Int = 
					(Math.floor(Math.random * (inputData.items - 1))).toInt
				val newChromo: String = chromo1.substring(0, crossPoint) + 
					chromo2.substring(crossPoint)
				return newChromo
			}

			// Perform cloning.
			else {
				val chromo = selectChromosome
				return chromo
			}
		}
	}

	/** 
	  * Select a chromosome for breeding.
	  *
	  * @return Chromosome string
	  */
	def selectChromosome(): String = {
		var i: Int = 0
		var rand: Int = (Math.floor(Math.random * inputData.items)).toInt
		while (true) {
			if (popData.prevFitness(rand) >= popData.prevMeanFitness)
				return popData.prevChromos(rand)
			else
				rand = (Math.floor(Math.random * inputData.items)).toInt
		}
		return popData.prevChromos(rand)
	}

	/** 
	  * Get chromosome's fitness score.
	  *
	  * @param chromo Chromosome string
	  * @return Fitness score of chromosome
	  */
	def getFitness(chromo: String): Double = {
		var totalWeight: Double = 0
		var totalValue: Double = 0
		var fitnessScore: Double = 0
		var difference: Double = 0
		var gene: Char = '0'
		for (i <- 0 to inputData.items - 1) {
			gene = chromo.charAt(i)
			if (gene == '1') {
				totalWeight = totalWeight + inputData.weights(i)
				totalValue = totalValue + inputData.values(i)
			}
		}
		difference = inputData.capacity - totalWeight
		if (difference >= 0)
			fitnessScore = totalValue
		return fitnessScore
	}
}


/** 
  * A single generation in a genetic algorithm.
  * Creates 'popSize' number of PopulationItems.
  * 
  * @param inputData Structure holding user input data
  * @param popData Structure holding data passed from Generation
  * @param genCount Current generation
  */
class Generation(val inputData: knapStruct, val popData: popStruct,
	var genCount: Int) {

	var population: Array[PopulationItem] = 
		new Array[PopulationItem](inputData.popSize)
	var crossoverCount: Int = 0
	var cloneCount: Int = 0
	var bestFitness: Double = 0
	var totalFitness: Double = 0
	var meanFitness: Double = 0
	var bestChromosome: String = ""
	var prevChromos: Array[String] = new Array[String](inputData.popSize)
	var prevFitness: Array[Double] = new Array[Double](inputData.popSize)

	/** 
	  * Generation toString. 
	  *
	  * @return String representation of Generation object
	  */
	override def toString: String = {
		var logUnderscore: StringBuilder = new StringBuilder()
		for (i <- 0 to Math.log10(genCount).toInt)
			logUnderscore.append("=")
		return "\nGeneration " + genCount + "\n===========" + 
			logUnderscore.toString
	}

	/** 
	  * Creates a population item. 
	  */
	def makePopulation {
		for (i <- 0 to (inputData.popSize - 1)) {

			// Get arrays of previous populations and fitness.
			if (i > 0) {
				prevChromos(i - 1) = population(i - 1).chromosome
				prevFitness(i - 1) = population(i - 1).fitness
			}

			population(i) = new PopulationItem(inputData, popData, genCount)
			inputData.writer.write(population(i).toString + "\n")
			totalFitness = totalFitness + population(i).fitness

			if (population(i).fitness > bestFitness) {
				bestFitness = population(i).fitness
				bestChromosome = population(i).chromosome
			}

			if (i == inputData.popSize - 1) {
				prevChromos(i) = population(i).chromosome
				prevFitness(i) = population(i).fitness
			}
		}
		meanFitness = totalFitness / inputData.popSize
	}
}


/** 
  * Sets up Knapsack problem.
  *	Creates maxGens number of Generations, and reports back to user on 
  *	generations. 
  * 
  * @param inputData Structure holding user input data
  */
class Knapsack(val inputData: knapStruct) {

	var generations: Array[Generation] = 
		new Array[Generation](inputData.maxGens)
	var prevChromosFinal: Array[String] = new Array[String](inputData.popSize)
	var prevFitnessFinal: Array[Double] = new Array[Double](inputData.popSize)

	var bestChromosFinal: String = ""
	var bestFitnessFinal: Double = 0

	/** 
	  * Knapsack toString. 
	  *
	  * @return String representation of Knapsack object.
	  */
	override def toString: String = {
		return "Knapsack Problem Summary\n========================" +
			"\nNumber of items: " + inputData.items + "\nPopulation size: " + 
			inputData.popSize + "\nMaximum number of generations: " +
			inputData.maxGens + "\nKnapsack capacity: " + inputData.capacity + 
			"\nCrossover probability: " + inputData.probCross
	}

	/** 
	  * Create and store successive generations. 
	  */
	def breed {

		var genCount: Int = 0
		var prevMeanFitness: Double = 0
		var prevChromos: Array[String] = new Array[String](inputData.popSize)
		var prevFitness: Array[Double] = new Array[Double](inputData.popSize)

		for (i <- 0 to (inputData.maxGens - 1)) {
			genCount = genCount + 1
			
			// Stuff needed for breeding further populations.
			if (genCount > 1) {
				prevMeanFitness = generations(i - 1).meanFitness
				Array.copy(generations(i - 1).prevChromos, 0, prevChromos, 0, 
					inputData.popSize)
				Array.copy(generations(i - 1).prevFitness, 0, prevFitness, 0, 
					inputData.popSize)
			}

			// Create struct of data to pass to PopulationItem via Generation.
			val popData = new popStruct(prevChromosFinal, prevFitnessFinal, 
				prevMeanFitness)
			generations(i) = new Generation(inputData, popData, genCount)

			inputData.writer.write(generations(i).toString + "\n")
			generations(i).makePopulation
			inputData.writer.write("\nOptimal solution of generation: " +
				generations(i).bestChromosome + "\n")
			inputData.writer.write("Optimal fitness of generation: " + 
				generations(i).bestFitness + "\n")
			inputData.writer.write("Mean fitness of generation: " + 
				generations(i).meanFitness + "\n")

			// Copy running previous generation data arrays to final array.
			Array.copy(generations(i).prevChromos, 0, prevChromosFinal, 0, 
				inputData.popSize)
			Array.copy(generations(i).prevFitness, 0, prevFitnessFinal, 0,
				inputData.popSize)

			// Add overall optimal fitness of generation to Java ArrayList.
			inputData.genBestFit.add(bestFitnessFinal)

			// Track optimal overall solution.
			if (generations(i).bestFitness > bestFitnessFinal) { 
				bestFitnessFinal = generations(i).bestFitness
				bestChromosFinal = generations(i).bestChromosome
			}
		}
	}

	/**
	  * Summarize results.
	  */
	def summarize {
		inputData.writer.write("\nSummary\n=======")
		inputData.writer.write("\nOptimal set: {")
		for (i <- 0 to (inputData.items - 1)) {
			if (bestChromosFinal.charAt(i) == '1')
				inputData.writer.write(" " + (i + 1))
		}
		inputData.writer.write(" }")
		inputData.writer.write("\nOptimal solution overall: " + bestChromosFinal)
		inputData.writer.write("\nOptimal fitness overall: " + bestFitnessFinal)
	}

	/**
	  * Graph results using a Java graph class.
	  */
	def graphResults {
		val graph: SimpleGraph = new SimpleGraph(inputData.genBestFit, 
			"Optimal Fitness by Generation")
	}
}


/**
  * Driver of Knapsack class.
  *	Collects user input, instantiates Knapsack object, calls functions which
  *	create Generation and PopulationItems objects and do the rest of work. 
  */
object KnapGA {

	/**
	  * Initiates user input solicitation, instantiates Knapsack object, passes
	  *	collected knapsack problem parameter data. 
	  *
	  * @params args Summary output file name
	  */
	def main(args: Array[String]) {

		/** Java ArrayList for holding best fitness score of generation for
			passing to Java graphing class. */
		var genBestFit: java.util.ArrayList[java.lang.Double] = 
			new java.util.ArrayList[java.lang.Double]()

		// Check command line args.
		if (args.length < 1) {
			println("Usage: scala KnapGA <output_filename>")
			System.exit(1)
		}

		// Collect user input.
		try {
			
			print("Enter number of items: ")
			val items: Int = scala.io.StdIn.readLine.toInt

			var valuesBuf = ArrayBuffer[Int]()
			var weightsBuf = ArrayBuffer[Int]()
			for (i <- 0 to (items - 1)) {
				print("Enter the value of item " + (i + 1) + ": ");
				valuesBuf += scala.io.StdIn.readLine.toInt
				print("Enter the weight of item " + (i + 1) + ": ");
				weightsBuf += scala.io.StdIn.readLine.toInt
		  	}
			var weights = weightsBuf.toArray
			var values = valuesBuf.toArray

			print("Enter knapsack capacity: ")
			val capacity: Int = scala.io.StdIn.readLine.toInt

			print("Enter population size: ")
			val popSize: Int = scala.io.StdIn.readLine.toInt

			print("Enter maximum number of generations: ")
			val maxGens: Int = scala.io.StdIn.readLine.toInt

			print("Enter the crossover probability: ")
			val probCross: Double = scala.io.StdIn.readLine.toDouble

			// Output file.
			val writer = new PrintWriter(new File(args(0)))

			// Create struct of input data to pass between objects.
			val inputData = new knapStruct(items, popSize, maxGens, capacity, 
				probCross, values, weights, writer, genBestFit)

			// Create Knapsack object, pass in collected data.
			val knap = new Knapsack(inputData)
			
			// Breed successive generations.
			writer.write(knap.toString + "\n")
			knap.breed
			knap.summarize
			writer.close()

			// Graph results via a pre-existing Java graph class.
			knap.graphResults
		}
		catch {
			case e:Exception => println("Input error: Please enter a number.")
		}
	}
}

