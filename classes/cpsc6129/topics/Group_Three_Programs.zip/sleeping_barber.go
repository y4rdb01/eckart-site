//====================================================================================================
// Sleeping Barber
// CPSC 6129 Go Programming Language 
// Authors: (Group 3) Vanessa Cooper
//                    Devin Garner
// Date: October 6, 2014
// Description:
// The Sleeping Barber problem is a classic synchronization problem 
// credited to Edsger Dijkstra.  The scenario is that there is one barber
// in a shop with one barber chair and a number of chairs for customers
// in the waiting room. If there are no customers, then the barber sits in 
// his chair and sleeps.  If a customer arrives, he wakes the barber or sits 
// in a waiting chair if the barber is cutting someone’s hair. If there are no
// waiting chairs available then the customer leaves.
//
// Criteria
//    Customers arrive at random intervals from 10 to 30 milliseconds
//    There are only 3 chairs in the waiting room
//    There is only one barber and one barber chair
//    When the barber chair is empty, the customer wakes the barber and receives a haircut
//    If the barber chair is occupied, customers take a seat in the waiting room
//    If there are no seats in the waiting room, the customers leave
//    Haircuts take 20 milliseconds
//    Customers leave after a haircut
//    Determine how many haircuts the barber can perform in 10 seconds
// 
//====================================================================================================

//==========================================
// Package Declarations
//==========================================
package main

//==========================================
// Imports
//==========================================
import (
   "fmt"
   "time"
   "math/rand"
)

//==========================================
// Declarations
//==========================================
const waiting_room_seats int = 3 //maximum number of customers allowed to wait
var   open_shop          bool    //Is the simulation running?
var   num_haircuts       int 

type  Customer struct {          //Create a customer type to use in concurrent
   val int                       //channels
}

var waitQ  = []*Customer{}

//==========================================
// main
//==========================================
func main( ) {

   num_customers := make(chan *Customer)
   done := make(chan bool, 1)

   go businessDay(done)
   go createCustomers(num_customers)
   go addCustomers(num_customers)
   go cutHair( )
   <-done
   fmt.Printf("Number of Haircuts = %d\n", num_haircuts)
}


//==========================================
// businessDay: Simulation time for when the 
// barber can cut hair
//==========================================
func businessDay(done chan bool) {
   fmt.Println("The barber shop is now open for business")
   open_shop = true
   time.Sleep(time.Second * 10)
   fmt.Println("The barber shop is now closed.")
   open_shop = false
   done <- true
}

//==========================================
// createCustomers: Generate a new customer
// base on the specified delay
//==========================================
func createCustomers(num_customers chan *Customer) {
   for (open_shop == true) {
      delay := rand.Intn(30 - 10) + 10
      time.Sleep(time.Millisecond * time.Duration(delay))
      num_customers <- &Customer{}
   }
}

//==========================================
// addCustomers: Function to add customers 
// to the queue 
//==========================================
func addCustomers(num_customers <-chan *Customer) {
   for (open_shop == true) {
      customer := <- num_customers
      if(len(waitQ) < waiting_room_seats) { //add customer to the wait queue if not full
         waitQ = append(waitQ, customer)
         fmt.Printf("Number of customers waiting %d\n", len(waitQ))
      } else {
         fmt.Println("Waitng room is currently full ....")
      }   
   }
}

//==========================================
// cutHair: Function to simulate the barber 
// 
//==========================================
func cutHair( ) {
   for(open_shop == true) {
      customer_count := len(waitQ)
      if(customer_count > 0) {
         waitQ = waitQ[1:]
      }
      time.Sleep(time.Millisecond * 20)
      num_haircuts++
   }
}

