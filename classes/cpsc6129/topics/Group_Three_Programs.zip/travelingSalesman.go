//====================================================================================================
// Traveling Salesman
// CPSC 6129 Go Programming Language 
// Authors: (Group 3) Vanessa Cooper
//                    Devin Garner
// Date: October 10, 2014
// Description:
//   Given a list of cities and the distances between each pair of cities, what is the shortest route found through the 2-opt algorithm which visits each city exactly once and returns to the origin city?
//   Note: Finding the shortest path is an NP-Hard problem, meaning there is no known algorithm which can do it quickly for a large data set. This is a simplified version of the problem because the 2-opt algorithm is not guaranteed to find the absolute shortest possible path, but should find a reasonably short path in a relatively short amount of time.
//
// Criteria
//   The distance between the cities will be represented by an undirected graph: the distance will not change based on the direction of travel.
//   The output of the program cannot include repeats to the same city multiple times.
// 
//====================================================================================================

//==========================================
// Package Declaration
//==========================================
package main

//==========================================
// Import external libraries
//==========================================
import (
   "math";
   "fmt"
)

//==========================================
// Data Type Definitions
//==========================================
type City struct {
	Name string
	LatitudeInDegrees float64
	LongitudeInDegrees float64
}

type Road struct {
	StartCity City
	EndCity City
	DistanceInMiles float64
}

type Tour []Road;
type Atlas [][]Road;

//==========================================
// main: entry point to application
//==========================================
func main( ) {

	//==========================================
	// Test Data
	//==========================================
	USCapitals := []City{
		City{"Alabama, Montgomery", 32.361538, -86.279118},
		City{"Alaska, Juneau", 58.301935, -134.419740},
		City{"Arizona, Phoenix", 33.448457, -112.073844},
		City{"Arkansas, Little Rock", 34.736009, -92.331122},
		City{"California, Sacramento", 38.555605, -121.468926},
		City{"Colorado, Denver", 39.7391667, -104.984167},
		City{"Connecticut, Hartford", 41.767, -72.677},
		City{"Delaware, Dover", 39.161921, -75.526755},
		City{"Florida, Tallahassee", 30.4518, -84.27277},
		City{"Georgia, Atlanta", 33.76, -84.39},
		City{"Hawaii, Honolulu", 21.30895, -157.826182},
		City{"Idaho, Boise", 43.613739, -116.237651},
		City{"Illinois, Springfield", 39.783250, -89.650373},
		City{"Indiana, Indianapolis", 39.790942, -86.147685},
		City{"Iowa, Des Moines", 41.590939, -93.620866},
		City{"Kansas, Topeka", 39.04, -95.69},
		City{"Kentucky, Frankfort", 38.197274, -84.86311},
		City{"Louisiana, Baton Rouge", 30.45809, -91.140229},
		City{"Maine, Augusta", 44.323535, -69.765261},
		City{"Maryland, Annapolis", 38.972945, -76.501157},
		City{"Massachusetts, Boston", 42.2352, -71.0275},
		City{"Michigan, Lansing", 42.7335, -84.5467},
		City{"Minnesota, Saint Paul", 44.95, -93.094},
		City{"Mississippi, Jackson", 32.320, -90.207},
		City{"Missouri, Jefferson City", 38.572954, -92.189283},
		City{"Montana, Helana", 46.595805, -112.027031},
		City{"Nebraska, Lincoln", 40.809868, -96.675345},
		City{"Nevada, Carson City", 39.160949, -119.753877},
		City{"New Hampshire, Concord", 43.220093, -71.549127},
		City{"New Jersey, Trenton", 40.221741, -74.756138},
		City{"New Mexico, Santa Fe", 35.667231, -105.964575},
		City{"New York, Albany", 42.659829, -73.781339},
		City{"North Carolina, Raleigh", 35.771, -78.638},
		City{"North Dakota, Bismarck", 48.813343, -100.779004},
		City{"Ohio, Columbus", 39.962245, -83.000647},
		City{"Oklahoma, Oklahoma City", 35.482309, -97.534994},
		City{"Oregon, Salem", 44.931109, -123.029159},
		City{"Pennsylvania, Harrisburg", 40.269789, -76.875613},
		City{"Rhode Island, Providence", 41.82355, -71.422132},
		City{"South Carolina, Columbia", 34.000, -81.035},
		City{"South Dakota, Pierre", 44.367966, -100.336378},
		City{"Tennessee, Nashville", 36.165, -86.784},
		City{"Texas, Austin", 30.266667, -97.75},
		City{"Utah, Salt Lake City", 40.7547, -111.892622},
		City{"Vermont, Montpelier", 44.26639, -72.57194},
		City{"Virginia, Richmond", 37.54, -77.46},
		City{"Washington, Olympia", 47.042418, -122.893077},
		City{"West Virginia, Charleston", 38.349497, -81.633294},
		City{"Wisconsin, Madison", 43.074722, -89.384444},
		City{"Wyoming, Cheyenne", 41.145548, -104.802042},
	}
	
	//pre-calculate & cache distances between each combination of cities
	atlas := make(Atlas, len(USCapitals));
	for idx1 := 0; idx1 < len(USCapitals); idx1++ {
		atlas[idx1] = make([]Road, len(USCapitals));
		for idx2 := 0; idx2 < len(USCapitals); idx2++ {
			atlas[idx1][idx2] = Road{USCapitals[idx1], USCapitals[idx2], calculateHaversineDistance(USCapitals[idx1], USCapitals[idx2])};
		}
	}
	
	tour := solveTravelingSalesmanProblemWithTwoOpt(atlas);
	printTour(tour);
}

//==========================================
// convertCityIndicesToTour: convert array of integers representing city indices and convert to tour
//==========================================
func convertCityIndicesToTour(indices []int32, atlas Atlas) Tour {
	if (len(indices) <= 1) {
		panic("invalid input to convertCityIndicesToTour");
	}
	
	//allocate a dynamically sized array
	result := make(Tour, len(indices));

	for idx := 0; idx < len(indices)-1; idx++ {
		result[idx] = atlas[indices[idx]][indices[idx+1]];
	}
	result[len(indices)-1] = atlas[indices[len(indices)-1]][indices[0]];
	
	return result;
}

//==========================================
// makeRangedArray: convert two integers to an array which enumerates all numbers within range
//==========================================
func makeRangedArray(start int32, end int32) []int32 {
	//allocate a dynamically sized array
	result := make([]int32, end-start+1);

	for i := int32(0); i <= end-start; i++ {
        result[i] = i+start;
    }	
	
	return result;
}

//==========================================
// solveTravelingSalesmanProblemWithTwoOpt: #1) take naiive tour through all cities, #2) perform twoOpt on each possible range of inner route, if improvement is made keep this as best tour and goto #2, if no improvement is made return tour
//==========================================
func solveTravelingSalesmanProblemWithTwoOpt(atlas Atlas) Tour {
	cityCount := len(atlas);
	
	result := makeRangedArray(0, int32(cityCount-1));
	
	bestDistance := calculateTotalDistance(convertCityIndicesToTour(result, atlas));
	
	improvementMade := true;
	for improvementMade {
		improvementMade = false;

		for i := 1; i < cityCount-2; i++ {
			
			for k := i + 1; k < cityCount-1; k++ {
				newTour := twoOptSwap(result, i, k);

				newDistance := calculateTotalDistance(convertCityIndicesToTour(newTour, atlas));
				if (newDistance < bestDistance) {
					result = newTour;
					bestDistance = newDistance;
					improvementMade = true;
					break;
				}
			}
			
			if (improvementMade) {
				break;
			}
		}
	}
	
	return convertCityIndicesToTour(result, atlas);
}

//==========================================
// twoOptSwap: takes an existing tour, a range of roads in the middle of the tour, and reverses the traveling order of that range of roads
//==========================================
func twoOptSwap(cityIndicesForTour []int32, swapStart int, swapEnd int) []int32 {
	if (len(cityIndicesForTour) <= swapStart || len(cityIndicesForTour) <= swapEnd || len(cityIndicesForTour) <= 2) {
		panic("invalid input to twoOptSwap");
	}

	//allocate a dynamically sized array
	result := make([]int32, len(cityIndicesForTour));
	
	
	//copy roads verbatim before swap range
	for idx := 0; idx < swapStart; idx++ {
		result[idx] = cityIndicesForTour[idx];
	}

	//copy roads in reverse order within swap range
	for idx := swapStart; idx <= swapEnd; idx++ {
		result[idx] = cityIndicesForTour[swapEnd-(idx-swapStart)];
	}

	//copy roads verbatim after swap range
	for idx := swapEnd+1; idx < len(cityIndicesForTour); idx++ {
		result[idx] = cityIndicesForTour[idx];
	}
	
	return result;
}

//==========================================
// printTour: output list of roads and distanaces in tour to the screen
//==========================================
func printTour(tour Tour) {
	fmt.Printf("Total Distance in Miles: %v\n", calculateTotalDistance(tour));
	for _,road := range tour {
		fmt.Printf("From %s to %s : %v miles\n", road.StartCity.Name, road.EndCity.Name, road.DistanceInMiles);
	}
}

//==========================================
// calculateTotalDistance: aggregates the distance of each road in the tour to calculate the total distance
//==========================================
func calculateTotalDistance(tour Tour) float64 {
	sum := float64(0);
	for _,road := range tour {
		sum += road.DistanceInMiles;
	}
	
	return sum;
}

const AVERAGE_RADIUS_OF_EARTH_IN_MILES int = 3961;
	
//==========================================
// calculateHaversineDistance: estimate miles for direct flight between two lattitudeDegree/longitudeDegree pairs
//==========================================
func calculateHaversineDistance(startCity City, endCity City) float64 {
	
	// convert coordinates to radians
	var startCityLatitudeInRadians float64 = convertDegreesToRadians(startCity.LatitudeInDegrees);
	var startCityLongitudeInRadians float64 = convertDegreesToRadians(startCity.LongitudeInDegrees);
	var endCityLatitudeInRadians float64 = convertDegreesToRadians(endCity.LatitudeInDegrees);
	var endCityLongitudeInRadians float64 = convertDegreesToRadians(endCity.LongitudeInDegrees);
	
	// find the differences between the coordinates
	var lattitudeDelta float64 = endCityLatitudeInRadians - startCityLatitudeInRadians;
	var longitudeDelta float64 = endCityLongitudeInRadians - startCityLongitudeInRadians;
	
	var haversine float64 = math.Pow(math.Sin(lattitudeDelta/2),2) + math.Cos(startCityLatitudeInRadians) * math.Cos(endCityLatitudeInRadians) * math.Pow(math.Sin(longitudeDelta/2),2);
	var distanceInRadians float64 = 2 * math.Atan2(math.Sqrt(haversine),math.Sqrt(1-haversine));
	var distanceInMiles float64 = distanceInRadians * float64(AVERAGE_RADIUS_OF_EARTH_IN_MILES);
	
	// round the results down to the nearest 1/100
	return float64(int(100 * distanceInMiles + 5) / 100);
}

//==========================================
// convertDegreesToRadians: mathematical equation using PI
//==========================================
func convertDegreesToRadians(degrees float64) float64 {
	return degrees * math.Pi/180;
}