//====================================================================================================
// Loan Amortization Calculator
// CPSC 6129 Go Programming Language 
// Authors: (Group 3) Vanessa Cooper
//                    Devin Garner
// Date: November 17, 2014
// Description:
//   A loan amortization schedule is a table of loan payments showing both the principal and interest payments needed so that the loan will be paid off at the end of its terms.
//
// Criteria
//  User should be asked for the following inputs
//    Loan amount
//    Start date
//      
//    Optional Inputs (2 of 3 required). The user can leave out ANY one of the following and the missing value should be calculated:
//      Loan term in years or months
//      Interest rate (yearly)
//      Monthly payment
//
//  Based on the input, the program should print out the loan schedule for the term showing the monthly payments, the principal, interest, and the balance of the loan.
// 
//====================================================================================================

//==========================================
// Package Declaration
//==========================================
package main

//==========================================
// Import external libraries
//==========================================
import (
   "math";
   "fmt";
   "bufio";
   "os";
   "strconv";
   "strings";
   "time"
)

//==========================================
// main: entry point to application
//==========================================
func main( ) {

    fmt.Print("Loan Amortization Calculator\n");
	
	reader := bufio.NewReader(os.Stdin);

	var e error;
	var loanAmount float64;
    for {
		fmt.Print("Loan Amount:");
		loanAmountAsString, _ := reader.ReadString('\n');
		loanAmountAsString = strings.Replace(loanAmountAsString, "\r\n", "", -1)
		loanAmount, e = strconv.ParseFloat(strings.Replace(strings.Replace(loanAmountAsString, "$", "", -1), ",", "", -1), 64);
		if (e == nil) {
			break;
		}

		fmt.Print("Invalid input. Example format: $150,000.00\n");
	}

	var startDate time.Time;
    for {
		fmt.Print("Start Date:");
		startDateAsString, _ := reader.ReadString('\n');
		startDateAsString = strings.Replace(startDateAsString, "\r\n", "", -1)
		//note: 1st parameter to parse is the desired format. You must use the exact timestamp of 01/02 03:04:05PM '06 -0700 and format it the way you'd like
		startDate, e = time.Parse("01/02/2006", startDateAsString);
		if (e == nil) {
			break;
		}

		fmt.Print("Invalid input. Example format: 11/02/2014\n");
	}

	var isYearly bool;
    for {
		fmt.Print("(Y)early or (M)onthly:");
		yearlyOrMonthly, _ := reader.ReadString('\n');
		yearlyOrMonthly = strings.Replace(yearlyOrMonthly, "\r\n", "", -1)
		if (strings.EqualFold(yearlyOrMonthly, "y")) {
			isYearly = true;
			break;
		} else if (strings.EqualFold(yearlyOrMonthly, "m")) {
			isYearly = false;
			break;
		}
		
		fmt.Print("Invalid input. Please enter Y or M.\n");
	}

	var termInMonths int64;
    for {
		if (isYearly) {
			fmt.Print("Term(in years) [optional]:");
		} else {
			fmt.Print("Term(in months) [optional]:");
		}
		
		termAsString, _ := reader.ReadString('\n');
		termAsString = strings.Replace(termAsString, "\r\n", "", -1)
		if (termAsString == "") {
			break;
		}
		
		var term int64;
		term, e = strconv.ParseInt(termAsString, 10, 0);
		if (e == nil) {
			if (isYearly) {
				termInMonths = term * 12;
			} else {
				termInMonths = term;
			}
			
			break;
		}		
		
		fmt.Print("Invalid input. Please enter an integer. \n");
	}

	var apr float64;
    for {
		if (termInMonths > 0) {
			fmt.Print("APR [optional]:");
		} else {
			fmt.Print("APR:");
		}
		
		aprAsString, _ := reader.ReadString('\n');
		aprAsString = strings.Replace(aprAsString, "\r\n", "", -1)
		if (aprAsString == "" && termInMonths > 0) {
			break;
		}
		
		apr, e = strconv.ParseFloat(strings.Replace(aprAsString, "%", "", -1), 64);
		if (e == nil) {
			if (strings.Contains(aprAsString, "%")) {
				apr = apr / 100;
			}
			
			break;
		}		
		
		fmt.Print("Invalid input. Example format: 3.5% \n");
	}

	var monthlyPayment float64;
	if ((termInMonths > 0) && (apr > 0)) {
	} else {
		for {
			fmt.Print("Monthly Payment: ");
			
			monthlyPaymentAsString, _ := reader.ReadString('\n');
			monthlyPaymentAsString = strings.Replace(monthlyPaymentAsString, "\r\n", "", -1)
			monthlyPayment, e = strconv.ParseFloat(strings.Replace(strings.Replace(monthlyPaymentAsString, "$", "", -1), ",", "", -1), 64);
			if (e == nil) {
				break;
			}		
			
			fmt.Print("Invalid input. Example format: $1350.00 \n");
		}
	}
	
	if (termInMonths == 0) {	
		termInMonths = calculateTermInMonths(loanAmount, monthlyPayment, apr);
	} else if (apr == 0) {
		apr = calculateApr(loanAmount, monthlyPayment, termInMonths);
	} else if (monthlyPayment == 0) {
		monthlyPayment = calculateMonthlyPayment(loanAmount, apr, termInMonths);
	}
	
	outputAmortizationChart(loanAmount, apr, termInMonths, monthlyPayment, isYearly, startDate);
}

//==========================================
// outputAmortizationChart: print amortization chart
//==========================================
func outputAmortizationChart(loanAmount float64, apr float64, termInMonths int64, monthlyPayment float64, isYearly bool, startDate time.Time) {
	fmt.Print("Date\t\tInterest\t\tPrincipal\t\tBalance\n");
	
	var payment float64;
	var percentageRate float64;
	
	if (isYearly) {
		payment = monthlyPayment * 12;
		percentageRate = apr;
	} else {
		payment = monthlyPayment;
		percentageRate = apr / 12;
	}

	date := startDate;
	
	totalInterest := float64(0);
	totalPrincipal := float64(0);
	totalPayments := float64(0);
	balance := loanAmount;
	for (balance > 0) {
		if (payment > balance) {
			payment = balance;
		}
	
		if (isYearly) {
			date = date.AddDate(1, 0, 0);
		} else {
			date = date.AddDate(0, 1, 0);
		}
		
		balance -= payment;
		totalPayments = totalPayments + payment;		

		interest := percentageRate * balance;

		principal := payment - interest;
		totalPrincipal = totalPrincipal + principal;

		balance += interest;
		totalInterest = totalInterest + interest;
		
		fmt.Printf("%v\t\t%.2f\t\t%.2f\t\t%.2f\n", date.Format("1/02/2006"), interest, principal, balance);
	}
	
	fmt.Print("\n\nTotal Interest\tTotal Principal\tTotal Payments\n");
	fmt.Printf("%.2f\t%.2f\t%.2f\n", totalInterest, totalPrincipal, totalPayments);	
}

//==========================================
// calculateMonthlyPayment: determine monthly payment for loan given amount, apr, & numberOfPayments
//==========================================
func calculateMonthlyPayment(loanAmount float64, apr float64, termInMonths int64) float64 {
	monthlyPercentageRate := apr / 12;
	aggregateInterest := math.Pow(1 + monthlyPercentageRate, float64(termInMonths));
	return (monthlyPercentageRate * loanAmount * aggregateInterest) / (aggregateInterest - 1)
}

//==========================================
// calculateApr: determine interest rate for loan given amount, payment, & numberOfPayments. There is algebraic equation for this, it must be found by testing different interest rates through trial & error.
//==========================================
func calculateApr(loanAmount float64, monthlyPayment float64, termInMonths int64) float64 {
	lastAprAdjustment := -.1;
	roundedMonthlyPayment := int64(monthlyPayment*100)/100;
	possibleApr := (monthlyPayment * float64(termInMonths) / loanAmount) - 1;
	for {
		possibleMonthlyPayment := int64(calculateMonthlyPayment(loanAmount, possibleApr, termInMonths)*100)/100;
		if (possibleMonthlyPayment == roundedMonthlyPayment) {
			return possibleApr;
		} else if (possibleMonthlyPayment < roundedMonthlyPayment) {
			if (lastAprAdjustment < 0) {
				lastAprAdjustment = lastAprAdjustment * -.5;
			}
		} else {
			if (lastAprAdjustment > 0) {
				lastAprAdjustment = lastAprAdjustment * -.5;
			}
		}
		possibleApr = possibleApr + lastAprAdjustment;
	}
}

//==========================================
// calculateTermInMonths: iterate over each payment to calculate the number of payments required to repay loan
//==========================================
func calculateTermInMonths(loanAmount float64, monthlyPayment float64, apr float64) int64 {
	result := 0;
	
	monthlyPercentageRate := apr / 12;
	balance := loanAmount;
	for (balance > 0) {
		balance -= monthlyPayment;
		balance += monthlyPercentageRate * balance;
		result++;
	}
	
	return int64(result);
}